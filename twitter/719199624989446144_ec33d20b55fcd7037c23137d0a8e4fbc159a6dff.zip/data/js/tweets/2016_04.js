Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/SbEJiRNTeT",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717525568&oldid=717525279",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725577929137217536",
  "text" : "Alguien desde RedIRIS ha editado 'User:Andrea Vicente&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SbEJiRNTeT",
  "id" : 725577929137217536,
  "created_at" : "2016-04-28 06:50:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/oyRCU5JoRt",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717525318&oldid=717525096",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725577401628024832",
  "text" : "Alguien desde RedIRIS ha editado 'User:Larakalako&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oyRCU5JoRt",
  "id" : 725577401628024832,
  "created_at" : "2016-04-28 06:48:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/HUFyhyTGLa",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717525279&oldid=710657200",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725577327850209281",
  "text" : "Alguien desde RedIRIS ha editado 'User:Andrea Vicente&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HUFyhyTGLa",
  "id" : 725577327850209281,
  "created_at" : "2016-04-28 06:48:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/WXlbsybX4t",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717525096&oldid=717522580",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725576961989435392",
  "text" : "Alguien desde RedIRIS ha editado 'User:Larakalako&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WXlbsybX4t",
  "id" : 725576961989435392,
  "created_at" : "2016-04-28 06:46:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/Q92hRxEMLH",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717522580&oldid=717522185",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725571444747423744",
  "text" : "Alguien desde RedIRIS ha editado 'User:Larakalako&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Q92hRxEMLH",
  "id" : 725571444747423744,
  "created_at" : "2016-04-28 06:24:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/LeZoJjHuJ7",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717522185&oldid=717521950",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725570708491870209",
  "text" : "Alguien desde RedIRIS ha editado 'User:Larakalako&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LeZoJjHuJ7",
  "id" : 725570708491870209,
  "created_at" : "2016-04-28 06:21:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/FYvRVyN3yB",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717521950&oldid=717521669",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725570308854390784",
  "text" : "Alguien desde RedIRIS ha editado 'User:Larakalako&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FYvRVyN3yB",
  "id" : 725570308854390784,
  "created_at" : "2016-04-28 06:20:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/K3hRXwIpy1",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717521669&oldid=717521588",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725569779034148864",
  "text" : "Alguien desde RedIRIS ha editado 'User:Larakalako&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/K3hRXwIpy1",
  "id" : 725569779034148864,
  "created_at" : "2016-04-28 06:18:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/1sYj1Ja9Kt",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717521588&oldid=710656930",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725569604857241600",
  "text" : "Alguien desde RedIRIS ha editado 'User:Larakalako&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1sYj1Ja9Kt",
  "id" : 725569604857241600,
  "created_at" : "2016-04-28 06:17:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/DouF3HhKe4",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717520627&oldid=710657591",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725567826422018048",
  "text" : "Alguien desde RedIRIS ha editado 'User:Clara.santamaria&amp;#x2F;sandbox' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DouF3HhKe4",
  "id" : 725567826422018048,
  "created_at" : "2016-04-28 06:10:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/g3cLdnx1D1",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717195486&oldid=717195431",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724877975649435648",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/g3cLdnx1D1",
  "id" : 724877975649435648,
  "created_at" : "2016-04-26 08:29:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/5uaF6GFzIr",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717195431&oldid=717195380",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724877835148611585",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5uaF6GFzIr",
  "id" : 724877835148611585,
  "created_at" : "2016-04-26 08:28:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/jOCcTPJqmM",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717195380&oldid=717194589",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724877706756808704",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jOCcTPJqmM",
  "id" : 724877706756808704,
  "created_at" : "2016-04-26 08:28:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/4uAl2Ekp5U",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717194589&oldid=717193531",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724875663262515200",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4uAl2Ekp5U",
  "id" : 724875663262515200,
  "created_at" : "2016-04-26 08:20:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/UHy6XF9TrK",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717193531&oldid=717193340",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724872828839976960",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UHy6XF9TrK",
  "id" : 724872828839976960,
  "created_at" : "2016-04-26 08:08:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/3DcEM0ip2F",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717193340&oldid=717192863",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724872578960089088",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3DcEM0ip2F",
  "id" : 724872578960089088,
  "created_at" : "2016-04-26 08:07:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/L86Di4ueIM",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717192863&oldid=717191939",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724871980722298880",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/L86Di4ueIM",
  "id" : 724871980722298880,
  "created_at" : "2016-04-26 08:05:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/Ul3Z5TABjb",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717191939&oldid=717186192",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724869220308254720",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ul3Z5TABjb",
  "id" : 724869220308254720,
  "created_at" : "2016-04-26 07:54:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/1KjZa9i6rT",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717186277&oldid=716722405",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724853819591512064",
  "text" : "Alguien desde RedIRIS ha editado 'User:GoizanePe&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1KjZa9i6rT",
  "id" : 724853819591512064,
  "created_at" : "2016-04-26 06:53:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/CIrcqZD6Kl",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717186192&oldid=710662891",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724853565521539072",
  "text" : "Alguien desde RedIRIS ha editado 'User:Beafidalgo&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CIrcqZD6Kl",
  "id" : 724853565521539072,
  "created_at" : "2016-04-26 06:52:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ODPdoMdR1V",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717184726&oldid=711333202",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724849500456628225",
  "text" : "Alguien desde RedIRIS ha editado 'User:Mikelele94&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ODPdoMdR1V",
  "id" : 724849500456628225,
  "created_at" : "2016-04-26 06:36:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/yAcXios4uh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90688815&oldid=89650263",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724651741166329856",
  "text" : "Alguien desde RedIRIS ha editado 'Distribuci\u00F3n de Pareto' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/yAcXios4uh",
  "id" : 724651741166329856,
  "created_at" : "2016-04-25 17:30:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/qPHgfVDY6d",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90682530&oldid=90682526",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724558272469041152",
  "text" : "Alguien desde RedIRIS ha editado 'Agencias de la Uni\u00F3n Europea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qPHgfVDY6d",
  "id" : 724558272469041152,
  "created_at" : "2016-04-25 11:18:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/MHl8tVH9CN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90682526&oldid=89597834",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724558087567380480",
  "text" : "Alguien desde RedIRIS ha editado 'Agencias de la Uni\u00F3n Europea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MHl8tVH9CN",
  "id" : 724558087567380480,
  "created_at" : "2016-04-25 11:18:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/I72OeAf9o0",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=16837446&oldid=16826501&rcid=28457334",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724526242670776321",
  "text" : "Alguien desde CSIC ha editado 'Pythium' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/I72OeAf9o0",
  "id" : 724526242670776321,
  "created_at" : "2016-04-25 09:11:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/iE1MKXUMLD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90681286&oldid=90681271",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724522833540468736",
  "text" : "Alguien desde RedIRIS ha editado 'En la tuya o en la m\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iE1MKXUMLD",
  "id" : 724522833540468736,
  "created_at" : "2016-04-25 08:57:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/03wQSK3Jf3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90681271&oldid=90681256",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724522647292391424",
  "text" : "Alguien desde RedIRIS ha editado 'En la tuya o en la m\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/03wQSK3Jf3",
  "id" : 724522647292391424,
  "created_at" : "2016-04-25 08:57:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/AWHSqeDONq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90681256&oldid=90647876",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724522260174876672",
  "text" : "Alguien desde RedIRIS ha editado 'En la tuya o en la m\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AWHSqeDONq",
  "id" : 724522260174876672,
  "created_at" : "2016-04-25 08:55:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/F8kU7v6t7H",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717015499&oldid=711167977",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724485449478230016",
  "text" : "Alguien desde RedIRIS ha editado 'User:Nargiza.ablikimova' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/F8kU7v6t7H",
  "id" : 724485449478230016,
  "created_at" : "2016-04-25 06:29:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/YF17AJvIPH",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717014667&oldid=717014636",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724482776502771712",
  "text" : "Alguien desde RedIRIS ha editado 'User:Mario cabella14&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YF17AJvIPH",
  "id" : 724482776502771712,
  "created_at" : "2016-04-25 06:18:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/QtKfN67lvX",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=717014636&oldid=714683738",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724482656667373570",
  "text" : "Alguien desde RedIRIS ha editado 'User:Mario cabella14&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QtKfN67lvX",
  "id" : 724482656667373570,
  "created_at" : "2016-04-25 06:18:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/GLATy9sKIo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90623933&oldid=88231242",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723432669627867136",
  "text" : "Alguien desde RedIRIS ha editado 'Petra (Baleares)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GLATy9sKIo",
  "id" : 723432669627867136,
  "created_at" : "2016-04-22 08:46:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/qeqOwrQgqo",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716528777&oldid=716013359",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723396078033195008",
  "text" : "Alguien desde RedIRIS ha editado 'User:Aneabasolo&amp;#x2F;sandbox' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qeqOwrQgqo",
  "id" : 723396078033195008,
  "created_at" : "2016-04-22 06:20:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/JBFiHEWXvh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90604812&oldid=90496623",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723077811913801728",
  "text" : "Alguien desde RedIRIS ha editado 'Carga el\u00E9ctrica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JBFiHEWXvh",
  "id" : 723077811913801728,
  "created_at" : "2016-04-21 09:15:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/jKx61Ri5Xs",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716343042&oldid=716342912",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723033940076953600",
  "text" : "Alguien desde RedIRIS ha editado 'User:Aitor.erdoiza&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jKx61Ri5Xs",
  "id" : 723033940076953600,
  "created_at" : "2016-04-21 06:21:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/6eLIG0bxgg",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716342912&oldid=716001362",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723033706965942272",
  "text" : "Alguien desde RedIRIS ha editado 'User:Aitor.erdoiza&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6eLIG0bxgg",
  "id" : 723033706965942272,
  "created_at" : "2016-04-21 06:20:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/HaPEl1bPEO",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716001362&oldid=716001322",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722324756012392449",
  "text" : "Alguien desde RedIRIS ha editado 'User:Aitor.erdoiza&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HaPEl1bPEO",
  "id" : 722324756012392449,
  "created_at" : "2016-04-19 07:23:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/5Yz2GLqgfm",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716001322&oldid=716001290",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722324642346700800",
  "text" : "Alguien desde RedIRIS ha editado 'User:Aitor.erdoiza&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5Yz2GLqgfm",
  "id" : 722324642346700800,
  "created_at" : "2016-04-19 07:23:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/EDlhJ0OM0U",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716001290&oldid=716000581",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722324541326942208",
  "text" : "Alguien desde RedIRIS ha editado 'User:Aitor.erdoiza&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EDlhJ0OM0U",
  "id" : 722324541326942208,
  "created_at" : "2016-04-19 07:22:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/PD0Kf9Lt22",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716001139&oldid=716001063",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722324105542955008",
  "text" : "Alguien desde RedIRIS ha editado 'User:Jonmedina10&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PD0Kf9Lt22",
  "id" : 722324105542955008,
  "created_at" : "2016-04-19 07:21:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/3OKLjuIaxZ",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716001063&oldid=716001005",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722323889750204416",
  "text" : "Alguien desde RedIRIS ha editado 'User:Jonmedina10&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3OKLjuIaxZ",
  "id" : 722323889750204416,
  "created_at" : "2016-04-19 07:20:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/5OpdBmcUIo",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716001005&oldid=716000846",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722323685416243200",
  "text" : "Alguien desde RedIRIS ha editado 'User:Jonmedina10&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5OpdBmcUIo",
  "id" : 722323685416243200,
  "created_at" : "2016-04-19 07:19:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/MReXbeJTZp",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716000846&oldid=713469521",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722323114454073344",
  "text" : "Alguien desde RedIRIS ha editado 'User:Jonmedina10&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MReXbeJTZp",
  "id" : 722323114454073344,
  "created_at" : "2016-04-19 07:17:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/HYUWCWVUi3",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=716000581&oldid=710663673",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722322286137708545",
  "text" : "Alguien desde RedIRIS ha editado 'User:Aitor.erdoiza&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HYUWCWVUi3",
  "id" : 722322286137708545,
  "created_at" : "2016-04-19 07:13:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/1eulSjNX6t",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=715192782&oldid=715192676",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720520615845871617",
  "text" : "Alguien desde RedIRIS ha editado 'User:Mikelele94&amp;#x2F;Infobox' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1eulSjNX6t",
  "id" : 720520615845871617,
  "created_at" : "2016-04-14 07:54:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/3rmiTLoSgw",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=715192676&oldid=715185326",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720520314057265153",
  "text" : "Alguien desde RedIRIS ha editado 'User:Mikelele94&amp;#x2F;Infobox' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3rmiTLoSgw",
  "id" : 720520314057265153,
  "created_at" : "2016-04-14 07:53:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/usstZZujn2",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=715186590&oldid=710493028",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720502840322613248",
  "text" : "Alguien desde RedIRIS ha editado 'User:Pinillos.asier' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/usstZZujn2",
  "id" : 720502840322613248,
  "created_at" : "2016-04-14 06:43:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/KHyFD9yqh6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90414563&oldid=80129959",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719823071574650880",
  "text" : "Alguien desde RedIRIS ha editado 'Comarcas de Mallorca' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KHyFD9yqh6",
  "id" : 719823071574650880,
  "created_at" : "2016-04-12 09:42:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ZrSdgGbYWl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90413746&oldid=90413739",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719795784967921664",
  "text" : "Alguien desde CSIC ha editado 'Anexo:Audiencias de Gran Hermano VIP (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZrSdgGbYWl",
  "id" : 719795784967921664,
  "created_at" : "2016-04-12 07:54:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/QYStFcaxw2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=90413739&oldid=90403849",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719795587395239936",
  "text" : "Alguien desde CSIC ha editado 'Anexo:Audiencias de Gran Hermano VIP (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QYStFcaxw2",
  "id" : 719795587395239936,
  "created_at" : "2016-04-12 07:53:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]