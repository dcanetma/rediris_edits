Grailbird.data.tweets_2017_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/LBnV4uwQ1s",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98682714&oldid=98448781",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857625003399032833",
  "text" : "Alguien desde RedIRIS ha editado 'Oskar Schindler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LBnV4uwQ1s",
  "id" : 857625003399032833,
  "created_at" : "2017-04-27 15:58:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/3b7vf74oX4",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=479087050&oldid=447545591&rcid=508438823",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857202125834792960",
  "text" : "Alguien desde RedIRIS ha editado 'Q3064851' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3b7vf74oX4",
  "id" : 857202125834792960,
  "created_at" : "2017-04-26 11:58:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/PNK3W5Jhbv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98649163&oldid=93034896",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857165013626355712",
  "text" : "Alguien desde RedIRIS ha editado 'Villalobar' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PNK3W5Jhbv",
  "id" : 857165013626355712,
  "created_at" : "2017-04-26 09:30:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/6WkRhhbujH",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=777286227&oldid=777177025",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857155638375452672",
  "text" : "Alguien desde CSIC ha editado 'Critical Mass (cycling)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6WkRhhbujH",
  "id" : 857155638375452672,
  "created_at" : "2017-04-26 08:53:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/0FGY1mjzDE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98648341&oldid=97620613",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857143023553179649",
  "text" : "Alguien desde RedIRIS ha editado 'Dimensiones culturales' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0FGY1mjzDE",
  "id" : 857143023553179649,
  "created_at" : "2017-04-26 08:03:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/ggJwc8m590",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=479030177&oldid=475470190&rcid=508374484",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857119926296997888",
  "text" : "Alguien desde RedIRIS ha editado 'Q3179598' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ggJwc8m590",
  "id" : 857119926296997888,
  "created_at" : "2017-04-26 06:31:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/cFXs6xQZEY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625512&oldid=98625488",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856828901938663424",
  "text" : "Alguien desde RedIRIS ha editado 'Petardo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cFXs6xQZEY",
  "id" : 856828901938663424,
  "created_at" : "2017-04-25 11:15:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/eyZVzLSnfA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625488&oldid=98625280",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856828527190167555",
  "text" : "Alguien desde RedIRIS ha editado 'Petardo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eyZVzLSnfA",
  "id" : 856828527190167555,
  "created_at" : "2017-04-25 11:13:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/KjBGpZeODY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625408&oldid=96907209",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856827682734186497",
  "text" : "Alguien desde RedIRIS ha editado 'Chapapote' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KjBGpZeODY",
  "id" : 856827682734186497,
  "created_at" : "2017-04-25 11:10:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/eXxXuHVQfU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625280&oldid=95967278",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856826085509652482",
  "text" : "Alguien desde RedIRIS ha editado 'Petardo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eXxXuHVQfU",
  "id" : 856826085509652482,
  "created_at" : "2017-04-25 11:03:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/n3dGawvZjr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625137&oldid=98625130",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856824144717127681",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/n3dGawvZjr",
  "id" : 856824144717127681,
  "created_at" : "2017-04-25 10:56:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/2bpKZDWfbH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625130&oldid=98625114",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856823926214754305",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2bpKZDWfbH",
  "id" : 856823926214754305,
  "created_at" : "2017-04-25 10:55:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/ss5ekOscC2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625114&oldid=98625099",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856823714700283904",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ss5ekOscC2",
  "id" : 856823714700283904,
  "created_at" : "2017-04-25 10:54:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/73GOW2yXNh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625099&oldid=98625095",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856823502279757824",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/73GOW2yXNh",
  "id" : 856823502279757824,
  "created_at" : "2017-04-25 10:53:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/cC3VUj5v3h",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625095&oldid=98625081",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856823411699572740",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cC3VUj5v3h",
  "id" : 856823411699572740,
  "created_at" : "2017-04-25 10:53:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/HXtWoLwzSu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625081&oldid=98625063",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856823165636444164",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HXtWoLwzSu",
  "id" : 856823165636444164,
  "created_at" : "2017-04-25 10:52:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/HqlxUKKOvd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625063&oldid=98625049",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856822931753709568",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HqlxUKKOvd",
  "id" : 856822931753709568,
  "created_at" : "2017-04-25 10:51:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/QXBlIqNASM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625049&oldid=98625034",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856822765290221569",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QXBlIqNASM",
  "id" : 856822765290221569,
  "created_at" : "2017-04-25 10:50:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/WMqWYrtAkl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98625034&oldid=98624893",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856822495504191489",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WMqWYrtAkl",
  "id" : 856822495504191489,
  "created_at" : "2017-04-25 10:49:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/2w876SEogB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98624893&oldid=98612515",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856819966288461824",
  "text" : "Alguien desde RedIRIS ha editado 'Escala sismol\u00F3gica de Richter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2w876SEogB",
  "id" : 856819966288461824,
  "created_at" : "2017-04-25 10:39:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/SnlZavJSmr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98623374&oldid=88643486",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856807416574464000",
  "text" : "Alguien desde CSIC ha editado 'Baco (Leonardo)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SnlZavJSmr",
  "id" : 856807416574464000,
  "created_at" : "2017-04-25 09:49:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/qq3NsRrfQw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98623300&oldid=98623281",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856806443361718272",
  "text" : "Alguien desde RedIRIS ha editado 'Raoul C\u00E9dric Lo\u00E9' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qq3NsRrfQw",
  "id" : 856806443361718272,
  "created_at" : "2017-04-25 09:45:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/NqeQ0zzjHI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98623281&oldid=96847482",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856806220300201985",
  "text" : "Alguien desde RedIRIS ha editado 'Raoul C\u00E9dric Lo\u00E9' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NqeQ0zzjHI",
  "id" : 856806220300201985,
  "created_at" : "2017-04-25 09:44:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/BcaSmFTeXA",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18382713&oldid=18066385&rcid=42537770",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856803071162281984",
  "text" : "Alguien desde RedIRIS ha editado 'Arkano' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BcaSmFTeXA",
  "id" : 856803071162281984,
  "created_at" : "2017-04-25 09:32:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/HLWXQ2R1nW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98622127&oldid=98549951",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856779048143421442",
  "text" : "Alguien desde RedIRIS ha editado 'Guerra de Corea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HLWXQ2R1nW",
  "id" : 856779048143421442,
  "created_at" : "2017-04-25 07:56:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/gr7oLBFQ9s",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98597682&oldid=98275341",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856444043957608448",
  "text" : "Alguien desde RedIRIS ha editado 'Billions' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gr7oLBFQ9s",
  "id" : 856444043957608448,
  "created_at" : "2017-04-24 09:45:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/tfD79uGPE4",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=776680064&oldid=776164380",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "855811560161280000",
  "text" : "Alguien desde RedIRIS ha editado 'Mount St Bernard Abbey' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tfD79uGPE4",
  "id" : 855811560161280000,
  "created_at" : "2017-04-22 15:52:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/n7RCcLSjsD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98532472&oldid=94390324",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "855395148376756224",
  "text" : "Alguien desde CSIC ha editado 'Pecadores (programa de televisi\u00F3n)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/n7RCcLSjsD",
  "id" : 855395148376756224,
  "created_at" : "2017-04-21 12:17:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/5fZTinKf8E",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98502787&oldid=96536826",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "855008125170180097",
  "text" : "Alguien desde CSIC ha editado 'Alejandra Vanessa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5fZTinKf8E",
  "id" : 855008125170180097,
  "created_at" : "2017-04-20 10:39:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/UN9yRxawRf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98501040&oldid=98501021",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854968930393354240",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UN9yRxawRf",
  "id" : 854968930393354240,
  "created_at" : "2017-04-20 08:04:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/20Y7uF883Q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98501021&oldid=98500993",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854968479107219456",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/20Y7uF883Q",
  "id" : 854968479107219456,
  "created_at" : "2017-04-20 08:02:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/oRjdFFvnYO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98500993&oldid=98500987",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854967936980844544",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oRjdFFvnYO",
  "id" : 854967936980844544,
  "created_at" : "2017-04-20 08:00:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/rQJAocsVTF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98500987&oldid=98500968",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854967815417327616",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rQJAocsVTF",
  "id" : 854967815417327616,
  "created_at" : "2017-04-20 07:59:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/PUSAXFtoFq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98500968&oldid=98497333",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854967167598678016",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PUSAXFtoFq",
  "id" : 854967167598678016,
  "created_at" : "2017-04-20 07:57:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/PWuBUZ3E1S",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98481949&oldid=97750522",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854735218212835334",
  "text" : "Alguien desde RedIRIS ha editado 'Histidina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PWuBUZ3E1S",
  "id" : 854735218212835334,
  "created_at" : "2017-04-19 16:35:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/L5cbxpbtgR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98447810&oldid=92479043",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854266960762347520",
  "text" : "Alguien desde RedIRIS ha editado 'Acetato de litio' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/L5cbxpbtgR",
  "id" : 854266960762347520,
  "created_at" : "2017-04-18 09:34:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/dg0htniOLq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98446695&oldid=93623221",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854242442320551936",
  "text" : "Alguien desde RedIRIS ha editado 'Interfer\u00F3metro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dg0htniOLq",
  "id" : 854242442320551936,
  "created_at" : "2017-04-18 07:57:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/ZXYLM4Z7sz",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18341144&oldid=18341137&rcid=40902803",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852168850661679104",
  "text" : "Alguien desde CSIC ha editado 'Llista de colles castelleres' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZXYLM4Z7sz",
  "id" : 852168850661679104,
  "created_at" : "2017-04-12 14:37:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/BFzJBj1ozL",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18341137&oldid=18341118&rcid=40902755",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852168397756542977",
  "text" : "Alguien desde CSIC ha editado 'Llista de colles castelleres' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BFzJBj1ozL",
  "id" : 852168397756542977,
  "created_at" : "2017-04-12 14:35:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/6sPfL5T5SE",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18341118&oldid=18335800&rcid=40862312",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852165930327166976",
  "text" : "Alguien desde CSIC ha editado 'Llista de colles castelleres' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6sPfL5T5SE",
  "id" : 852165930327166976,
  "created_at" : "2017-04-12 14:26:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/QjXn7AMqYQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98296337&oldid=98296306",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852068517797089280",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QjXn7AMqYQ",
  "id" : 852068517797089280,
  "created_at" : "2017-04-12 07:58:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/86Y0ko1wF0",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98296306&oldid=98287022",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852067607192776704",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/86Y0ko1wF0",
  "id" : 852067607192776704,
  "created_at" : "2017-04-12 07:55:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/L22KJlnAT6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98276492&oldid=92417632",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851779522408140800",
  "text" : "Alguien desde CSIC ha editado 'Miguel Caba\u00F1as Bravo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/L22KJlnAT6",
  "id" : 851779522408140800,
  "created_at" : "2017-04-11 12:50:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/OjvjOGPtBj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98275231&oldid=97675415",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851751039741157377",
  "text" : "Alguien desde CSIC ha editado 'Conjetura de Goldbach' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OjvjOGPtBj",
  "id" : 851751039741157377,
  "created_at" : "2017-04-11 10:57:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/BybNdhoOhu",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18338011&oldid=18284641&rcid=40615922",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851749819605544960",
  "text" : "Alguien desde CSIC ha editado 'La febre d&amp;#39;or' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BybNdhoOhu",
  "id" : 851749819605544960,
  "created_at" : "2017-04-11 10:52:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/EQjJzfI3xi",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98253509&oldid=91059820",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851408014057906176",
  "text" : "Alguien desde CSIC ha editado 'Parque de San Isidro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EQjJzfI3xi",
  "id" : 851408014057906176,
  "created_at" : "2017-04-10 12:14:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/SFvp8pYI7C",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98253448&oldid=95026547",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851406711562829824",
  "text" : "Alguien desde CSIC ha editado 'Cementerio de los Ingleses (Madrid)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SFvp8pYI7C",
  "id" : 851406711562829824,
  "created_at" : "2017-04-10 12:09:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/YgM5VT6jYp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98252729&oldid=91065474",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851389628884168705",
  "text" : "Alguien desde RedIRIS ha editado 'Cabieces' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YgM5VT6jYp",
  "id" : 851389628884168705,
  "created_at" : "2017-04-10 11:01:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/N0xHd6sIRe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98252252&oldid=98250260",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851378019440766976",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/N0xHd6sIRe",
  "id" : 851378019440766976,
  "created_at" : "2017-04-10 10:15:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/EwGyTJl9mo",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=774714115&oldid=774701997",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851325339380973568",
  "text" : "Alguien desde RedIRIS ha editado 'Pau Gasol' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EwGyTJl9mo",
  "id" : 851325339380973568,
  "created_at" : "2017-04-10 06:45:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/JEtxPXNIn3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=98194945&rcid=155388785",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "850337304241688577",
  "text" : "Alguien desde RedIRIS ha editado 'Discusi\u00F3n:Erripaga\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JEtxPXNIn3",
  "id" : 850337304241688577,
  "created_at" : "2017-04-07 13:19:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/fjcmC8u9Jw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98189902&oldid=98079575",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "850268127879249922",
  "text" : "Alguien desde RedIRIS ha editado 'Grupo ULMA' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fjcmC8u9Jw",
  "id" : 850268127879249922,
  "created_at" : "2017-04-07 08:44:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/z57v6tASJR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98136023&oldid=97490734",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849654877269700608",
  "text" : "Alguien desde RedIRIS ha editado 'Fontes linguae vasconum' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/z57v6tASJR",
  "id" : 849654877269700608,
  "created_at" : "2017-04-05 16:08:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/l0O6V1udqi",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98129266&oldid=98129258",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849550478090350594",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/l0O6V1udqi",
  "id" : 849550478090350594,
  "created_at" : "2017-04-05 09:13:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/dyVdcurH8c",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98129258&oldid=98117333",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849550227258449920",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dyVdcurH8c",
  "id" : 849550227258449920,
  "created_at" : "2017-04-05 09:12:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/jx1cykKslX",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18322515&oldid=18312990&rcid=39828844",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849547983834279937",
  "text" : "Alguien desde RedIRIS ha editado 'Campanet' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jx1cykKslX",
  "id" : 849547983834279937,
  "created_at" : "2017-04-05 09:03:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/WKSS95s3xp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98083656&oldid=61088746",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848932968601145344",
  "text" : "Alguien desde RedIRIS ha editado 'Maxi San Miguel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WKSS95s3xp",
  "id" : 848932968601145344,
  "created_at" : "2017-04-03 16:19:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/eFg4m5ZHxM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98083627&oldid=87132549",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848932578837102594",
  "text" : "Alguien desde RedIRIS ha editado 'Comisi\u00F3n Rogers' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eFg4m5ZHxM",
  "id" : 848932578837102594,
  "created_at" : "2017-04-03 16:17:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/GgwExQtast",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98083600&oldid=95884375",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848932228990160903",
  "text" : "Alguien desde RedIRIS ha editado 'Richard Feynman' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GgwExQtast",
  "id" : 848932228990160903,
  "created_at" : "2017-04-03 16:16:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/4xkO9eTJYu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98078070&oldid=97887066",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848851303354834944",
  "text" : "Alguien desde RedIRIS ha editado 'Jos\u00E9 Mar\u00EDa Aznar' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4xkO9eTJYu",
  "id" : 848851303354834944,
  "created_at" : "2017-04-03 10:54:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/rvHxctfLcm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98023849&oldid=97957064",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848129836941967360",
  "text" : "Alguien desde CSIC ha editado 'Tundra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rvHxctfLcm",
  "id" : 848129836941967360,
  "created_at" : "2017-04-01 11:08:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]