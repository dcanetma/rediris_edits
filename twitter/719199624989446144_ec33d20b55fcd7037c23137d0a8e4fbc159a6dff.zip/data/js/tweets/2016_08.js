Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/q0S3EepTW1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93307895&oldid=92083854",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771026063568896005",
  "text" : "Alguien desde RedIRIS ha editado 'Joan Baldov\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/q0S3EepTW1",
  "id" : 771026063568896005,
  "created_at" : "2016-08-31 16:45:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/RXmUJB03gU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93306159&oldid=93306125",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771004907495231488",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RXmUJB03gU",
  "id" : 771004907495231488,
  "created_at" : "2016-08-31 15:21:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/a355bralMx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93306125&oldid=93305560",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771004410231218177",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/a355bralMx",
  "id" : 771004410231218177,
  "created_at" : "2016-08-31 15:19:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/XJwzlZEkrT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93305560&oldid=93305449",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770996379674083329",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XJwzlZEkrT",
  "id" : 770996379674083329,
  "created_at" : "2016-08-31 14:47:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/fSjQ46B0Iy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93305449&oldid=93305402",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770995327033872389",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fSjQ46B0Iy",
  "id" : 770995327033872389,
  "created_at" : "2016-08-31 14:43:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/wxNIRHgFIG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93305402&oldid=93305372",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770994774690164736",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wxNIRHgFIG",
  "id" : 770994774690164736,
  "created_at" : "2016-08-31 14:40:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/NWwgQBUOAK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93305372&oldid=93304815",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770994390059933697",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NWwgQBUOAK",
  "id" : 770994390059933697,
  "created_at" : "2016-08-31 14:39:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/oJVXbGLc5H",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93304600&oldid=93304591",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770984140112072704",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oJVXbGLc5H",
  "id" : 770984140112072704,
  "created_at" : "2016-08-31 13:58:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/5cBrl4OKU8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93304591&oldid=93304535",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770984031731195904",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5cBrl4OKU8",
  "id" : 770984031731195904,
  "created_at" : "2016-08-31 13:58:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/wjjUrIc4Oy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93304535&oldid=93304450",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770983240039628800",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wjjUrIc4Oy",
  "id" : 770983240039628800,
  "created_at" : "2016-08-31 13:55:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/dC1TGzNjyT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93304450&oldid=93304385",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770982075377786880",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dC1TGzNjyT",
  "id" : 770982075377786880,
  "created_at" : "2016-08-31 13:50:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/QAxAzcj2Fm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93304385&oldid=93304110",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770980835663159296",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QAxAzcj2Fm",
  "id" : 770980835663159296,
  "created_at" : "2016-08-31 13:45:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/vxiJsHYEy6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93304110&oldid=92823676",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770975974469017600",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vxiJsHYEy6",
  "id" : 770975974469017600,
  "created_at" : "2016-08-31 13:26:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/0OtalNf10r",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=93300508&rcid=129735095",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770895973916798977",
  "text" : "Alguien desde RedIRIS ha editado 'Cohete h\u00EDbrido' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0OtalNf10r",
  "id" : 770895973916798977,
  "created_at" : "2016-08-31 08:08:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/UeDuxijbVe",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=736160078&oldid=693047137",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768840037639258113",
  "text" : "Alguien desde RedIRIS ha editado 'Cichoric acid' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UeDuxijbVe",
  "id" : 768840037639258113,
  "created_at" : "2016-08-25 15:58:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/u8LQjdILgn",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=128718647&oldid=128718640&rcid=203835750",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765893172459364352",
  "text" : "Alguien desde CSIC ha editado 'Michel Azama' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/u8LQjdILgn",
  "id" : 765893172459364352,
  "created_at" : "2016-08-17 12:48:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/JFewVXaDhd",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=128718640&oldid=124635333&rcid=203835729",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765893094831230976",
  "text" : "Alguien desde CSIC ha editado 'Michel Azama' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JFewVXaDhd",
  "id" : 765893094831230976,
  "created_at" : "2016-08-17 12:48:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/dFWiC98dyl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92975053&oldid=91815792",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765479940485746688",
  "text" : "Alguien desde CSIC ha editado 'Apoyo mutuo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dFWiC98dyl",
  "id" : 765479940485746688,
  "created_at" : "2016-08-16 09:26:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/sxwPIakvyT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92823676&oldid=89215589",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762626935402930177",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sxwPIakvyT",
  "id" : 762626935402930177,
  "created_at" : "2016-08-08 12:30:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/9thsQDrn1P",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92745916&oldid=92678901",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761570167063183360",
  "text" : "Alguien desde RedIRIS ha editado 'Sistema de la Reserva Federal' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9thsQDrn1P",
  "id" : 761570167063183360,
  "created_at" : "2016-08-05 14:30:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/4ylHCe3eKf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92739939&oldid=92629933",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761483616069246976",
  "text" : "Alguien desde RedIRIS ha editado 'Grupo Local' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4ylHCe3eKf",
  "id" : 761483616069246976,
  "created_at" : "2016-08-05 08:46:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/XRShX3Ovey",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92655637&oldid=84836331",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760461886831882242",
  "text" : "Alguien desde CSIC ha editado 'Luis de Oteyza' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XRShX3Ovey",
  "id" : 760461886831882242,
  "created_at" : "2016-08-02 13:06:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]