Grailbird.data.tweets_2018_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/SSbZeH5Dvh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105882673&oldid=102418973",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968770050537771008",
  "text" : "Alguien desde RedIRIS ha editado 'Espalaci\u00F3n de rayos c\u00F3smicos' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SSbZeH5Dvh",
  "id" : 968770050537771008,
  "created_at" : "2018-02-28 08:49:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/1Y6GZZK8hW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105836130&oldid=105836112",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968069449889742848",
  "text" : "Alguien desde RedIRIS ha editado 'Cerceda (Madrid)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1Y6GZZK8hW",
  "id" : 968069449889742848,
  "created_at" : "2018-02-26 10:25:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/vGdA9XzIH5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105836109&oldid=105836040",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968068829908697088",
  "text" : "Alguien desde RedIRIS ha editado 'Cerceda (Madrid)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vGdA9XzIH5",
  "id" : 968068829908697088,
  "created_at" : "2018-02-26 10:22:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/lenoXpXL2L",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105836037&oldid=105836036",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968067021433901056",
  "text" : "Alguien desde RedIRIS ha editado 'Cerceda (Madrid)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lenoXpXL2L",
  "id" : 968067021433901056,
  "created_at" : "2018-02-26 10:15:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Lg54da3rmm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105836036&oldid=103484297",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968066900747079680",
  "text" : "Alguien desde RedIRIS ha editado 'Cerceda (Madrid)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Lg54da3rmm",
  "id" : 968066900747079680,
  "created_at" : "2018-02-26 10:15:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/dpA6saOfh4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105835879&oldid=105835875",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968062958898176000",
  "text" : "Alguien desde RedIRIS ha editado 'Descubrimiento de Am\u00E9rica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dpA6saOfh4",
  "id" : 968062958898176000,
  "created_at" : "2018-02-26 09:59:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kT1mEhxD73",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105835867&oldid=105835856",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968062676663447552",
  "text" : "Alguien desde RedIRIS ha editado 'Descubrimiento de Am\u00E9rica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kT1mEhxD73",
  "id" : 968062676663447552,
  "created_at" : "2018-02-26 09:58:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/BW0KvLMIho",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105835856&oldid=105835854",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968062454512193538",
  "text" : "Alguien desde RedIRIS ha editado 'Descubrimiento de Am\u00E9rica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BW0KvLMIho",
  "id" : 968062454512193538,
  "created_at" : "2018-02-26 09:57:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/GfCzVy8W5q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105835854&oldid=105751081",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968062389886377984",
  "text" : "Alguien desde RedIRIS ha editado 'Descubrimiento de Am\u00E9rica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GfCzVy8W5q",
  "id" : 968062389886377984,
  "created_at" : "2018-02-26 09:57:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/2REc75LwWp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105772137&oldid=105772133",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966937141937934336",
  "text" : "Alguien desde RedIRIS ha editado 'Euzko Gaztedi Indarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2REc75LwWp",
  "id" : 966937141937934336,
  "created_at" : "2018-02-23 07:25:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/82P7JMU5aD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105772133&oldid=105772130",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966936990389297152",
  "text" : "Alguien desde RedIRIS ha editado 'Euzko Gaztedi Indarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/82P7JMU5aD",
  "id" : 966936990389297152,
  "created_at" : "2018-02-23 07:25:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/68kHpvlOCC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105772130&oldid=105285502",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966936907312697344",
  "text" : "Alguien desde RedIRIS ha editado 'Euzko Gaztedi Indarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/68kHpvlOCC",
  "id" : 966936907312697344,
  "created_at" : "2018-02-23 07:24:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Roy6MHxJYA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105753022&oldid=105753009",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966633877107347457",
  "text" : "Alguien desde CSIC ha editado 'Salvador Giner' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Roy6MHxJYA",
  "id" : 966633877107347457,
  "created_at" : "2018-02-22 11:20:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/DCHEtmCEiH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105753009&oldid=104022220",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966633425926086660",
  "text" : "Alguien desde CSIC ha editado 'Salvador Giner' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DCHEtmCEiH",
  "id" : 966633425926086660,
  "created_at" : "2018-02-22 11:19:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/TvP6arYIjR",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=636389123&oldid=625469064&rcid=671800229",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966627792656977920",
  "text" : "Alguien desde RedIRIS ha editado 'Q14036692' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TvP6arYIjR",
  "id" : 966627792656977920,
  "created_at" : "2018-02-22 10:56:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/iLuGrMkqeY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105752061&oldid=105752033",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966609073620897792",
  "text" : "Alguien desde RedIRIS ha editado 'Gestamp Automoci\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iLuGrMkqeY",
  "id" : 966609073620897792,
  "created_at" : "2018-02-22 09:42:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/uBT1DYsRqj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105752029&oldid=105752006",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966608438620053504",
  "text" : "Alguien desde RedIRIS ha editado 'Gestamp Automoci\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uBT1DYsRqj",
  "id" : 966608438620053504,
  "created_at" : "2018-02-22 09:39:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/qTzq8emgiX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105752006&oldid=105220991",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966607980207726592",
  "text" : "Alguien desde RedIRIS ha editado 'Gestamp Automoci\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qTzq8emgiX",
  "id" : 966607980207726592,
  "created_at" : "2018-02-22 09:37:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/E9RHMLBD8L",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105707751&oldid=104911881",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965926663157624832",
  "text" : "Alguien desde RedIRIS ha editado 'Equus quagga quagga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/E9RHMLBD8L",
  "id" : 965926663157624832,
  "created_at" : "2018-02-20 12:30:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lOa65TwnHi",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105706562&oldid=105626013",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965897618579709952",
  "text" : "Alguien desde RedIRIS ha editado 'Gaztelugatxe' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lOa65TwnHi",
  "id" : 965897618579709952,
  "created_at" : "2018-02-20 10:35:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/P0uV9VXGwM",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=826658871&oldid=826658667",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965885521913409537",
  "text" : "Alguien desde RedIRIS ha editado 'List of countries by GDP (PPP) per hour worked' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/P0uV9VXGwM",
  "id" : 965885521913409537,
  "created_at" : "2018-02-20 09:47:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/c1VeYddvpn",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=826658667&oldid=826658620",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965885048409948160",
  "text" : "Alguien desde RedIRIS ha editado 'List of countries by GDP (PPP) per hour worked' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/c1VeYddvpn",
  "id" : 965885048409948160,
  "created_at" : "2018-02-20 09:45:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/IQ8sw1kMpS",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=826658620&oldid=826658572",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965884949327949824",
  "text" : "Alguien desde RedIRIS ha editado 'List of countries by GDP (PPP) per hour worked' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IQ8sw1kMpS",
  "id" : 965884949327949824,
  "created_at" : "2018-02-20 09:44:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/St8365QvNe",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=826658572&oldid=826658469",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965884829639303168",
  "text" : "Alguien desde RedIRIS ha editado 'List of countries by GDP (PPP) per hour worked' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/St8365QvNe",
  "id" : 965884829639303168,
  "created_at" : "2018-02-20 09:44:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/webMwRBDOV",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=826658469&oldid=821093523",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965884611590017024",
  "text" : "Alguien desde RedIRIS ha editado 'List of countries by GDP (PPP) per hour worked' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/webMwRBDOV",
  "id" : 965884611590017024,
  "created_at" : "2018-02-20 09:43:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/oBNUG0nwPH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105704964&oldid=103222446",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965853833380417536",
  "text" : "Alguien desde RedIRIS ha editado 'Hersheypark' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oBNUG0nwPH",
  "id" : 965853833380417536,
  "created_at" : "2018-02-20 07:41:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/L0sxWRXUgf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105623966&oldid=105623609",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "964454490547130371",
  "text" : "Alguien desde RedIRIS ha editado 'Embuchado' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/L0sxWRXUgf",
  "id" : 964454490547130371,
  "created_at" : "2018-02-16 11:00:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/3XLdSiBDYX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105623609&oldid=105623577",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "964445332246429702",
  "text" : "Alguien desde RedIRIS ha editado 'Embuchado' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3XLdSiBDYX",
  "id" : 964445332246429702,
  "created_at" : "2018-02-16 10:24:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/NzTUXnteS7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105600961&oldid=105575606",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "964047616794353664",
  "text" : "Alguien desde RedIRIS ha editado '1998' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NzTUXnteS7",
  "id" : 964047616794353664,
  "created_at" : "2018-02-15 08:03:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/RQxPGyEmEl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105600890&oldid=105600880",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "964045321587306496",
  "text" : "Alguien desde RedIRIS ha editado '1996' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RQxPGyEmEl",
  "id" : 964045321587306496,
  "created_at" : "2018-02-15 07:54:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/alpFIZmuM2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105600880&oldid=105549298",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "964045034835279872",
  "text" : "Alguien desde RedIRIS ha editado '1996' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/alpFIZmuM2",
  "id" : 964045034835279872,
  "created_at" : "2018-02-15 07:53:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/zjsADxYbOv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105583687&oldid=105583647",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963775301401661440",
  "text" : "Alguien desde CSIC ha editado 'Zona b\u00E9ntica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zjsADxYbOv",
  "id" : 963775301401661440,
  "created_at" : "2018-02-14 14:01:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/fVUnJAvElE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105583647&oldid=104502195",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963774198870142977",
  "text" : "Alguien desde CSIC ha editado 'Zona b\u00E9ntica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fVUnJAvElE",
  "id" : 963774198870142977,
  "created_at" : "2018-02-14 13:57:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/r1sUu7QZ0o",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105564867&oldid=105563283",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963447994409537536",
  "text" : "Alguien desde RedIRIS ha editado 'Instituto de Agrobiotecnolog\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/r1sUu7QZ0o",
  "id" : 963447994409537536,
  "created_at" : "2018-02-13 16:21:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/WkaZPwxyan",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105564792&oldid=105563456",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963447188524294145",
  "text" : "Alguien desde RedIRIS ha editado 'Arr\u00F3niz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WkaZPwxyan",
  "id" : 963447188524294145,
  "created_at" : "2018-02-13 16:18:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Q7hymNIyXQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105563419&oldid=105563391",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963430353494069248",
  "text" : "Alguien desde RedIRIS ha editado 'Arr\u00F3niz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Q7hymNIyXQ",
  "id" : 963430353494069248,
  "created_at" : "2018-02-13 15:11:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/qlq03qcfvW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105563391&oldid=104900854",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963430041722990592",
  "text" : "Alguien desde RedIRIS ha editado 'Arr\u00F3niz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qlq03qcfvW",
  "id" : 963430041722990592,
  "created_at" : "2018-02-13 15:09:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/43kP1rNlOB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105563283&oldid=105562856",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963428726817067009",
  "text" : "Alguien desde RedIRIS ha editado 'Instituto de Agrobiotecnolog\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/43kP1rNlOB",
  "id" : 963428726817067009,
  "created_at" : "2018-02-13 15:04:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/GIA2NZ8X3p",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105562856&oldid=98510216",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963422976904482816",
  "text" : "Alguien desde RedIRIS ha editado 'Instituto de Agrobiotecnolog\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GIA2NZ8X3p",
  "id" : 963422976904482816,
  "created_at" : "2018-02-13 14:41:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/nMqpm2Czyq",
      "expanded_url" : "https:\/\/it.wikipedia.org\/w\/index.php?diff=94632430&oldid=92497548&rcid=235789033",
      "display_url" : "it.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963339515258658817",
  "text" : "Alguien desde CSIC ha editado 'Assiriologia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/nMqpm2Czyq",
  "id" : 963339515258658817,
  "created_at" : "2018-02-13 09:10:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/gAEwIGDFU2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105541793&oldid=105541788",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963076309713932289",
  "text" : "Alguien desde RedIRIS ha editado 'Temporada 2018 de F\u00F3rmula 1' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gAEwIGDFU2",
  "id" : 963076309713932289,
  "created_at" : "2018-02-12 15:44:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Xc6Vs2MjpY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105541788&oldid=105541025",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963076188649459712",
  "text" : "Alguien desde RedIRIS ha editado 'Temporada 2018 de F\u00F3rmula 1' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Xc6Vs2MjpY",
  "id" : 963076188649459712,
  "created_at" : "2018-02-12 15:43:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/WOoTjTOqQ7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=105541760&rcid=182218587",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963075740743946241",
  "text" : "Alguien desde RedIRIS ha editado 'Mercedes F1 W09' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WOoTjTOqQ7",
  "id" : 963075740743946241,
  "created_at" : "2018-02-12 15:42:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/kHhdpOjcZI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=105541676&rcid=182218446",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963074772040077312",
  "text" : "Alguien desde RedIRIS ha editado 'McLaren MCL33' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kHhdpOjcZI",
  "id" : 963074772040077312,
  "created_at" : "2018-02-12 15:38:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/iAdqh3Oh2Z",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=145412749&oldid=145412659&rcid=357039290",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963003823894691840",
  "text" : "Alguien desde RedIRIS ha editado 'Chez tonton, Pastis \u00D4 Ma\u00EEtre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iAdqh3Oh2Z",
  "id" : 963003823894691840,
  "created_at" : "2018-02-12 10:56:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/UVzvS5WDoP",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=145412659&oldid=144276498&rcid=357039071",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963003202403753984",
  "text" : "Alguien desde RedIRIS ha editado 'Chez tonton, Pastis \u00D4 Ma\u00EEtre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UVzvS5WDoP",
  "id" : 963003202403753984,
  "created_at" : "2018-02-12 10:53:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/OlZkyv0Jql",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19643490&oldid=19643475&rcid=75971492",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "961939700067037184",
  "text" : "Alguien desde RedIRIS ha editado 'Miquel Pou Vicens' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OlZkyv0Jql",
  "id" : 961939700067037184,
  "created_at" : "2018-02-09 12:27:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Ii5Fwgt7um",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105480028&oldid=105004441",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "961939324710346754",
  "text" : "Alguien desde RedIRIS ha editado 'Tulsa (banda)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ii5Fwgt7um",
  "id" : 961939324710346754,
  "created_at" : "2018-02-09 12:26:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/W0vvNGHOQn",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19643475&oldid=17691494&rcid=75971461",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "961937783928578048",
  "text" : "Alguien desde RedIRIS ha editado 'Miquel Pou Vicens' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/W0vvNGHOQn",
  "id" : 961937783928578048,
  "created_at" : "2018-02-09 12:20:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/KUJnGZZDUe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105461114&oldid=101178479",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "961616013954572289",
  "text" : "Alguien desde CSIC ha editado 'Anexo:Desastres medioambientales' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KUJnGZZDUe",
  "id" : 961616013954572289,
  "created_at" : "2018-02-08 15:01:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/yvnhcV8i9r",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?oldid=824311469&rcid=1026337356",
      "display_url" : "en.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960911839671586816",
  "text" : "Alguien desde CSIC ha editado 'User talk:161.111.151.16' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/yvnhcV8i9r",
  "id" : 960911839671586816,
  "created_at" : "2018-02-06 16:23:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/bAAK5mEm6q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105417175&oldid=103150376",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960880393095434240",
  "text" : "Alguien desde RedIRIS ha editado 'Hemimetabolismo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bAAK5mEm6q",
  "id" : 960880393095434240,
  "created_at" : "2018-02-06 14:18:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/qM8bgfT6om",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105414154&oldid=105221262",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960819700539314176",
  "text" : "Alguien desde RedIRIS ha editado 'Gald\u00E1cano' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qM8bgfT6om",
  "id" : 960819700539314176,
  "created_at" : "2018-02-06 10:17:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Qp6mgrrnEo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105413543&oldid=104901548",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960806326388559872",
  "text" : "Alguien desde CSIC ha editado 'Albi (Tarn)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Qp6mgrrnEo",
  "id" : 960806326388559872,
  "created_at" : "2018-02-06 09:24:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/h1hcgYRH2h",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=824162677&oldid=820978664",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960575433166196736",
  "text" : "Alguien desde CSIC ha editado 'Lie derivative' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/h1hcgYRH2h",
  "id" : 960575433166196736,
  "created_at" : "2018-02-05 18:06:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/jm49ChA4KY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105396159&oldid=105377742",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960548254080491521",
  "text" : "Alguien desde RedIRIS ha editado 'Usuario discusi\u00F3n:Geom' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jm49ChA4KY",
  "id" : 960548254080491521,
  "created_at" : "2018-02-05 16:18:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/xBFBw6vS5u",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=105395672&rcid=181900980",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960543412306022401",
  "text" : "Alguien desde RedIRIS ha editado 'Sergio heredia zarco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xBFBw6vS5u",
  "id" : 960543412306022401,
  "created_at" : "2018-02-05 15:59:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/SqJ6SwMVQa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105331813&oldid=105331782",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "959381419050008576",
  "text" : "Alguien desde RedIRIS ha editado 'Camino hamiltoniano' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SqJ6SwMVQa",
  "id" : 959381419050008576,
  "created_at" : "2018-02-02 11:02:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/b0GDAG36wy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105331782&oldid=105296427",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "959380908712386560",
  "text" : "Alguien desde RedIRIS ha editado 'Camino hamiltoniano' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/b0GDAG36wy",
  "id" : 959380908712386560,
  "created_at" : "2018-02-02 11:00:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]