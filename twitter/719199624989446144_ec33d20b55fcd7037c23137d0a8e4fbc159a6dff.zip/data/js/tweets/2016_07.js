Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/yR11rbT2aX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92542248&oldid=92542244",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758247255736520704",
  "text" : "Alguien desde RedIRIS ha editado 'Ex&amp;#39;s &amp;amp; Oh&amp;#39;s' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/yR11rbT2aX",
  "id" : 758247255736520704,
  "created_at" : "2016-07-27 10:26:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/XRiqqZr18P",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92542244&oldid=92207533",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758247162534821888",
  "text" : "Alguien desde RedIRIS ha editado 'Ex&amp;#39;s &amp;amp; Oh&amp;#39;s' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XRiqqZr18P",
  "id" : 758247162534821888,
  "created_at" : "2016-07-27 10:26:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/JiHZKSWmCE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92436485&oldid=87551751",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756417541803798528",
  "text" : "Alguien desde RedIRIS ha editado 'Eskuak&amp;#x2F;Ukabilak' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JiHZKSWmCE",
  "id" : 756417541803798528,
  "created_at" : "2016-07-22 09:16:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/A7VpQ1FV3S",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92372507&oldid=91573805",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755361017035649025",
  "text" : "Alguien desde CSIC ha editado 'Alfonso Uss\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A7VpQ1FV3S",
  "id" : 755361017035649025,
  "created_at" : "2016-07-19 11:17:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/qx90dUxIwn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=92372276&rcid=125843669",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755355706153394177",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Castillejo y Chico de Guzm\u00E1n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qx90dUxIwn",
  "id" : 755355706153394177,
  "created_at" : "2016-07-19 10:56:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/csoyrN7NQA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92347837&oldid=82067585",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754970262907588608",
  "text" : "Alguien desde CSIC ha editado 'Factor de transcripci\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/csoyrN7NQA",
  "id" : 754970262907588608,
  "created_at" : "2016-07-18 09:25:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/aOrDeEjqe7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92293347&oldid=92251484",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753904305946714112",
  "text" : "Alguien desde CSIC ha editado 'S\u00E1lvame diario' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aOrDeEjqe7",
  "id" : 753904305946714112,
  "created_at" : "2016-07-15 10:49:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/LvQ42Md45N",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92251639&oldid=89442830",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753148225490681856",
  "text" : "Alguien desde RedIRIS ha editado 'Nate Grey' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LvQ42Md45N",
  "id" : 753148225490681856,
  "created_at" : "2016-07-13 08:45:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/WeMEHtDwMN",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17204901&oldid=17204891&rcid=29965259",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753137162112077824",
  "text" : "Alguien desde CSIC ha editado 'Agrupaci\u00F3 Excursionista Muntanya' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WeMEHtDwMN",
  "id" : 753137162112077824,
  "created_at" : "2016-07-13 08:01:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Ephm4zDRqO",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17204891&oldid=15696009&rcid=29965236",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753137013356896257",
  "text" : "Alguien desde CSIC ha editado 'Agrupaci\u00F3 Excursionista Muntanya' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ephm4zDRqO",
  "id" : 753137013356896257,
  "created_at" : "2016-07-13 08:00:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/XlBBfrWHBg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92251191&oldid=92251062",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753129797417574400",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XlBBfrWHBg",
  "id" : 753129797417574400,
  "created_at" : "2016-07-13 07:31:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/5fOmavzhSy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92232181&oldid=92232178",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752807350239723522",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5fOmavzhSy",
  "id" : 752807350239723522,
  "created_at" : "2016-07-12 10:10:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/AmGiqV2yPt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92232178&oldid=92232164",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752807249635147776",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AmGiqV2yPt",
  "id" : 752807249635147776,
  "created_at" : "2016-07-12 10:10:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/EjyifpysK0",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92232164&oldid=92232156",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752806809916809217",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EjyifpysK0",
  "id" : 752806809916809217,
  "created_at" : "2016-07-12 10:08:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/v5SGayGcp2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92232156&oldid=92157741",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752806469649698816",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/v5SGayGcp2",
  "id" : 752806469649698816,
  "created_at" : "2016-07-12 10:07:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/rx3XZW9Ehg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92231209&oldid=92231207",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752772949376196608",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rx3XZW9Ehg",
  "id" : 752772949376196608,
  "created_at" : "2016-07-12 07:53:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/P5M6ifohCX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92231207&oldid=92231192",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752772784946835456",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/P5M6ifohCX",
  "id" : 752772784946835456,
  "created_at" : "2016-07-12 07:53:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/p0dogKQWmQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92231192&oldid=92231189",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752772455513657344",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/p0dogKQWmQ",
  "id" : 752772455513657344,
  "created_at" : "2016-07-12 07:51:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/GDobsRCw6B",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92231189&oldid=92231184",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752772240916279296",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GDobsRCw6B",
  "id" : 752772240916279296,
  "created_at" : "2016-07-12 07:51:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/wGOLZHnrGZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92231184&oldid=92231101",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752772035852509184",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wGOLZHnrGZ",
  "id" : 752772035852509184,
  "created_at" : "2016-07-12 07:50:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/XckzEv2nrn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92212894&oldid=91890628",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752445432421310464",
  "text" : "Alguien desde CSIC ha editado 'Holodomor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XckzEv2nrn",
  "id" : 752445432421310464,
  "created_at" : "2016-07-11 10:12:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QJgYoAUHyx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92211893&oldid=92211556",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752409515048435713",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QJgYoAUHyx",
  "id" : 752409515048435713,
  "created_at" : "2016-07-11 07:49:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/kX1HjxPH5n",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92157741&oldid=92157738",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751333571177095168",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kX1HjxPH5n",
  "id" : 751333571177095168,
  "created_at" : "2016-07-08 08:34:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/A1WjHzICop",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92157738&oldid=91907609",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751333502642159616",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A1WjHzICop",
  "id" : 751333502642159616,
  "created_at" : "2016-07-08 08:34:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/pxoy8NSwXm",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17168538&oldid=15911555&rcid=29833378",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751305831161991169",
  "text" : "Alguien desde RedIRIS ha editado 'Bacar\u00E0' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pxoy8NSwXm",
  "id" : 751305831161991169,
  "created_at" : "2016-07-08 06:44:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/6uKQU2aW4Q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92141590&oldid=92141584",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751046514022252548",
  "text" : "Alguien desde CSIC ha editado 'Robin S\u00F6derling' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6uKQU2aW4Q",
  "id" : 751046514022252548,
  "created_at" : "2016-07-07 13:33:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/NyMc6aUap0",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92141584&oldid=92141579",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751046405112946688",
  "text" : "Alguien desde CSIC ha editado 'Robin S\u00F6derling' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NyMc6aUap0",
  "id" : 751046405112946688,
  "created_at" : "2016-07-07 13:33:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/pJWBTm8oAx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92141579&oldid=92141574",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751046256840044545",
  "text" : "Alguien desde CSIC ha editado 'Robin S\u00F6derling' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pJWBTm8oAx",
  "id" : 751046256840044545,
  "created_at" : "2016-07-07 13:32:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/05M1ogIesf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92141574&oldid=92141556",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751046123792560128",
  "text" : "Alguien desde CSIC ha editado 'Robin S\u00F6derling' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/05M1ogIesf",
  "id" : 751046123792560128,
  "created_at" : "2016-07-07 13:32:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/F38c1Z3HDD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92141556&oldid=90531619",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751045599978463232",
  "text" : "Alguien desde CSIC ha editado 'Robin S\u00F6derling' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/F38c1Z3HDD",
  "id" : 751045599978463232,
  "created_at" : "2016-07-07 13:29:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/6BtESoWdwJ",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17161992&oldid=17161989&rcid=29795995",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750985143607787520",
  "text" : "Alguien desde RedIRIS ha editado 'Truman Capote' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6BtESoWdwJ",
  "id" : 750985143607787520,
  "created_at" : "2016-07-07 09:29:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/v7BwtIXuG5",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17161989&oldid=15431538&rcid=29795981",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750984946857209856",
  "text" : "Alguien desde RedIRIS ha editado 'Truman Capote' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/v7BwtIXuG5",
  "id" : 750984946857209856,
  "created_at" : "2016-07-07 09:28:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/wTgvA1MNQg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92119315&oldid=92119308",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750633233709137920",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wTgvA1MNQg",
  "id" : 750633233709137920,
  "created_at" : "2016-07-06 10:11:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/JPFuaDnAAl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92103451&oldid=92103305",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750358792022421504",
  "text" : "Alguien desde RedIRIS ha editado 'GMV' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JPFuaDnAAl",
  "id" : 750358792022421504,
  "created_at" : "2016-07-05 16:00:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/6pRBQwsqTj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92103305&oldid=92103188",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750357093983645700",
  "text" : "Alguien desde RedIRIS ha editado 'GMV' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6pRBQwsqTj",
  "id" : 750357093983645700,
  "created_at" : "2016-07-05 15:54:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/JT5Sv5rj7S",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92103188&oldid=78142068",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750355713336176640",
  "text" : "Alguien desde RedIRIS ha editado 'GMV' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JT5Sv5rj7S",
  "id" : 750355713336176640,
  "created_at" : "2016-07-05 15:48:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/4yJY6rFUuK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92101907&oldid=83366495",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750333762437844992",
  "text" : "Alguien desde CSIC ha editado 'Araceli Gonz\u00E1lez V\u00E1zquez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4yJY6rFUuK",
  "id" : 750333762437844992,
  "created_at" : "2016-07-05 14:21:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ahUX157kBF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92098849&oldid=92098846",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750253494926475264",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ahUX157kBF",
  "id" : 750253494926475264,
  "created_at" : "2016-07-05 09:02:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/jprEzRuC42",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92098846&oldid=92097296",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750253365288927232",
  "text" : "Alguien desde CSIC ha editado 'Supervivientes (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jprEzRuC42",
  "id" : 750253365288927232,
  "created_at" : "2016-07-05 09:01:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Ip2jyvKV5u",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92079784&oldid=92045748",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749907088399360000",
  "text" : "Alguien desde CSIC ha editado 'S\u00E1lvame diario' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ip2jyvKV5u",
  "id" : 749907088399360000,
  "created_at" : "2016-07-04 10:05:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/3BwlRoZhMZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92024341&oldid=85871073",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748844508947767296",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:\u00C7' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3BwlRoZhMZ",
  "id" : 748844508947767296,
  "created_at" : "2016-07-01 11:43:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/hSb1HCazKA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92023727&oldid=92023662",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748826382445211648",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Antonio Oca\u00F1a Mart\u00EDnez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hSb1HCazKA",
  "id" : 748826382445211648,
  "created_at" : "2016-07-01 10:31:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/zEw6MgCrC8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92023662&oldid=82955869",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748824115654627328",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Antonio Oca\u00F1a Mart\u00EDnez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zEw6MgCrC8",
  "id" : 748824115654627328,
  "created_at" : "2016-07-01 10:22:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]