Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/U1gu7wOFRP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92003615&oldid=92003605",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748475123963990016",
  "text" : "Alguien desde CSIC ha editado 'MasterChef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/U1gu7wOFRP",
  "id" : 748475123963990016,
  "created_at" : "2016-06-30 11:15:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/vSFyi78zqg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=92003605&oldid=92002020",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748474674959556608",
  "text" : "Alguien desde CSIC ha editado 'MasterChef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vSFyi78zqg",
  "id" : 748474674959556608,
  "created_at" : "2016-06-30 11:14:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/zeMivHul8m",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=727611979&oldid=716158595",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748351411725938688",
  "text" : "Alguien desde CSIC ha editado 'Thermal insulation' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zeMivHul8m",
  "id" : 748351411725938688,
  "created_at" : "2016-06-30 03:04:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/TVwvTUdrVt",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=727203535&oldid=727202952",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747384126110633984",
  "text" : "Alguien desde RedIRIS ha editado 'User:Valeriavd&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TVwvTUdrVt",
  "id" : 747384126110633984,
  "created_at" : "2016-06-27 11:00:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/2kRqcSADGC",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=727203137&oldid=727203118",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747383000783011840",
  "text" : "Alguien desde RedIRIS ha editado 'User:Valeriavd&amp;#x2F;sandbox' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2kRqcSADGC",
  "id" : 747383000783011840,
  "created_at" : "2016-06-27 10:56:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Cl7HaGlrzA",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=727203118&oldid=722049642",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747382941773357056",
  "text" : "Alguien desde RedIRIS ha editado 'User:Valeriavd&amp;#x2F;sandbox' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Cl7HaGlrzA",
  "id" : 747382941773357056,
  "created_at" : "2016-06-27 10:55:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/MdNBzVp52g",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=727202952&oldid=727202900",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747382470056738816",
  "text" : "Alguien desde RedIRIS ha editado 'User:Valeriavd&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MdNBzVp52g",
  "id" : 747382470056738816,
  "created_at" : "2016-06-27 10:54:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/0N4TyWglny",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=727202900&oldid=727192876",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747382316859801600",
  "text" : "Alguien desde RedIRIS ha editado 'User:Valeriavd&amp;#x2F;sandbox&amp;#x2F;References' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0N4TyWglny",
  "id" : 747382316859801600,
  "created_at" : "2016-06-27 10:53:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/fgysuW0Y6H",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91869590&oldid=91869348",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745883907904634880",
  "text" : "Alguien desde CSIC ha editado 'MasterChef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fgysuW0Y6H",
  "id" : 745883907904634880,
  "created_at" : "2016-06-23 07:39:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/sVs22aiLdM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91834189&oldid=91834178",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745274937800331264",
  "text" : "Alguien desde CSIC ha editado 'Ley de Bragg' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sVs22aiLdM",
  "id" : 745274937800331264,
  "created_at" : "2016-06-21 15:19:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/n9I2Oles4k",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91834178&oldid=91834160",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745274795831472129",
  "text" : "Alguien desde CSIC ha editado 'Ley de Bragg' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/n9I2Oles4k",
  "id" : 745274795831472129,
  "created_at" : "2016-06-21 15:18:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/hGLIWOyzfY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91834160&oldid=86119234",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745274576389681152",
  "text" : "Alguien desde CSIC ha editado 'Ley de Bragg' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hGLIWOyzfY",
  "id" : 745274576389681152,
  "created_at" : "2016-06-21 15:18:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9euzCczakk",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=726340609&oldid=723120668",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745273676317233152",
  "text" : "Alguien desde CSIC ha editado 'Bragg&amp;#39;s law' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9euzCczakk",
  "id" : 745273676317233152,
  "created_at" : "2016-06-21 15:14:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/yY55BjeeLX",
      "expanded_url" : "https:\/\/ar.wikipedia.org\/w\/index.php?diff=20249642&oldid=20107441",
      "display_url" : "ar.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745257412437905408",
  "text" : "Alguien desde RedIRIS ha editado '\u062C\u0628\u0644 \u0627\u0644\u0634\u064A\u062E' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/yY55BjeeLX",
  "id" : 745257412437905408,
  "created_at" : "2016-06-21 14:09:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9jE6pDPjVI",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=127119250&oldid=125361593&rcid=192870594",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743560415808978944",
  "text" : "Alguien desde RedIRIS ha editado 'Bilad el-Cham' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9jE6pDPjVI",
  "id" : 743560415808978944,
  "created_at" : "2016-06-16 21:46:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Cq0JRsJKqm",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5498710&oldid=3175286",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743500318848204808",
  "text" : "Alguien desde RedIRIS ha editado 'Jon Barberena' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Cq0JRsJKqm",
  "id" : 743500318848204808,
  "created_at" : "2016-06-16 17:47:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/UGARFqfhOs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91710696&oldid=87395701",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743084666102616064",
  "text" : "Alguien desde RedIRIS ha editado 'Structure from motion' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UGARFqfhOs",
  "id" : 743084666102616064,
  "created_at" : "2016-06-15 14:16:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/wbnKNkTwEs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91710133&oldid=91634082",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743072238925144065",
  "text" : "Alguien desde CSIC ha editado 'Conexi\u00F3n estrella tri\u00E1ngulo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wbnKNkTwEs",
  "id" : 743072238925144065,
  "created_at" : "2016-06-15 13:26:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/FtxUQeUYvO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91709190&oldid=89039681",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743046054917120000",
  "text" : "Alguien desde RedIRIS ha editado 'Thomas F. Wilson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FtxUQeUYvO",
  "id" : 743046054917120000,
  "created_at" : "2016-06-15 11:42:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/9gceEv6gcU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91665956&oldid=91614589",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742288224119328768",
  "text" : "Alguien desde RedIRIS ha editado 'Progresi\u00F3n geom\u00E9trica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9gceEv6gcU",
  "id" : 742288224119328768,
  "created_at" : "2016-06-13 09:31:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/BsizLc6Imq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91606767&oldid=91606753",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741193799628673024",
  "text" : "Alguien desde RedIRIS ha editado 'Sergio Ramos' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BsizLc6Imq",
  "id" : 741193799628673024,
  "created_at" : "2016-06-10 09:02:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lTewm7xHiN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91606717&oldid=91606598",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741192378585886720",
  "text" : "Alguien desde RedIRIS ha editado 'Sergio Ramos' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lTewm7xHiN",
  "id" : 741192378585886720,
  "created_at" : "2016-06-10 08:56:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Il6j8QmrVy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91606245&oldid=86400646",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741175345320189952",
  "text" : "Alguien desde CSIC ha editado 'ARN ribosomal 16S' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Il6j8QmrVy",
  "id" : 741175345320189952,
  "created_at" : "2016-06-10 07:49:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/AoYGsC2sZu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91566934&oldid=91526039",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740523951013658624",
  "text" : "Alguien desde RedIRIS ha editado 'Mequinenza' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AoYGsC2sZu",
  "id" : 740523951013658624,
  "created_at" : "2016-06-08 12:40:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/GOXv9DZLaz",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=724277522&oldid=721563848",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740431518670196737",
  "text" : "Alguien desde RedIRIS ha editado 'Violin Sonata No. 9 (Beethoven)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GOXv9DZLaz",
  "id" : 740431518670196737,
  "created_at" : "2016-06-08 06:33:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/A2XEfU7Xss",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=724196259&oldid=715222162",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740254569876312065",
  "text" : "Alguien desde RedIRIS ha editado 'Octave band' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A2XEfU7Xss",
  "id" : 740254569876312065,
  "created_at" : "2016-06-07 18:50:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ouYLbQYo4O",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91549981&oldid=91549952",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740228867747655680",
  "text" : "Alguien desde RedIRIS ha editado 'Partes por bill\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ouYLbQYo4O",
  "id" : 740228867747655680,
  "created_at" : "2016-06-07 17:08:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/2a4N9G1mJf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91549952&oldid=91549794",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740228627384668160",
  "text" : "Alguien desde RedIRIS ha editado 'Partes por bill\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2a4N9G1mJf",
  "id" : 740228627384668160,
  "created_at" : "2016-06-07 17:07:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/7piWJp0XvK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91549794&oldid=91549770",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740226609236545541",
  "text" : "Alguien desde RedIRIS ha editado 'Partes por bill\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7piWJp0XvK",
  "id" : 740226609236545541,
  "created_at" : "2016-06-07 16:59:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/20dVxqporq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91549770&oldid=90368429",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740226339874189312",
  "text" : "Alguien desde RedIRIS ha editado 'Partes por bill\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/20dVxqporq",
  "id" : 740226339874189312,
  "created_at" : "2016-06-07 16:58:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/ftFakVlw8o",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91548133&oldid=91548116",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740206366275571712",
  "text" : "Alguien desde CSIC ha editado 'MOS 6510' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ftFakVlw8o",
  "id" : 740206366275571712,
  "created_at" : "2016-06-07 15:38:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/z7RC8NS1c6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91548116&oldid=87048450",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740206172184141824",
  "text" : "Alguien desde CSIC ha editado 'MOS 6510' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/z7RC8NS1c6",
  "id" : 740206172184141824,
  "created_at" : "2016-06-07 15:37:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Por5GWtDJF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91543147&oldid=91543138",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740093106125672448",
  "text" : "Alguien desde RedIRIS ha editado 'Espacio de estados' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Por5GWtDJF",
  "id" : 740093106125672448,
  "created_at" : "2016-06-07 08:08:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/CWxDR2whL3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91543138&oldid=86701945",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740092903733788672",
  "text" : "Alguien desde RedIRIS ha editado 'Espacio de estados' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CWxDR2whL3",
  "id" : 740092903733788672,
  "created_at" : "2016-06-07 08:07:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/71eL9t0f90",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=126830577&oldid=125939108&rcid=191096234",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739839533999624196",
  "text" : "Alguien desde CSIC ha editado 'Christophe Berdos' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/71eL9t0f90",
  "id" : 739839533999624196,
  "created_at" : "2016-06-06 15:21:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/GoeDHBgpoj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=91485402&rcid=123330936",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739111262504771584",
  "text" : "Alguien desde RedIRIS ha editado 'Alfaritis' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GoeDHBgpoj",
  "id" : 739111262504771584,
  "created_at" : "2016-06-04 15:07:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/pG9MPUBYA0",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91463162&oldid=91463157",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738642800556802048",
  "text" : "Alguien desde CSIC ha editado 'Rainbow' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pG9MPUBYA0",
  "id" : 738642800556802048,
  "created_at" : "2016-06-03 08:05:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/9b2hlFbuJ3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91463157&oldid=91394197",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738642563134042112",
  "text" : "Alguien desde CSIC ha editado 'Rainbow' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9b2hlFbuJ3",
  "id" : 738642563134042112,
  "created_at" : "2016-06-03 08:04:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/TjyrRsoAIx",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5484440&oldid=5484439",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738622443263168513",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Bautista Bengoetxea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TjyrRsoAIx",
  "id" : 738622443263168513,
  "created_at" : "2016-06-03 06:44:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/vYQEmvfX9S",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5484439&oldid=5484438",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738621971550740480",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Bautista Bengoetxea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vYQEmvfX9S",
  "id" : 738621971550740480,
  "created_at" : "2016-06-03 06:42:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/AxlOEwM2l6",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5484438&oldid=5413361",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738621623532556288",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Bautista Bengoetxea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AxlOEwM2l6",
  "id" : 738621623532556288,
  "created_at" : "2016-06-03 06:41:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/xEb1l5ymPF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91446795&oldid=87431814",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738365287670616065",
  "text" : "Alguien desde RedIRIS ha editado 'Discusi\u00F3n:Gobierno de Navarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xEb1l5ymPF",
  "id" : 738365287670616065,
  "created_at" : "2016-06-02 13:42:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/snNkRauskX",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17045475&oldid=14361850&rcid=29283165",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738364314281775104",
  "text" : "Alguien desde CSIC ha editado 'Guillem Vives' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/snNkRauskX",
  "id" : 738364314281775104,
  "created_at" : "2016-06-02 13:39:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/5SYsKUfYHz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91424014&oldid=91256037",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737975090898448384",
  "text" : "Alguien desde RedIRIS ha editado 'Garcilaso de la Vega' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5SYsKUfYHz",
  "id" : 737975090898448384,
  "created_at" : "2016-06-01 11:52:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/9DrfIkO3Yh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91423988&oldid=91423979",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737974472746139649",
  "text" : "Alguien desde RedIRIS ha editado 'La \u00FAltima cena (Leonardo da Vinci)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9DrfIkO3Yh",
  "id" : 737974472746139649,
  "created_at" : "2016-06-01 11:49:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/1ydFAV8vdu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91423979&oldid=91300900",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737974191111168000",
  "text" : "Alguien desde RedIRIS ha editado 'La \u00FAltima cena (Leonardo da Vinci)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1ydFAV8vdu",
  "id" : 737974191111168000,
  "created_at" : "2016-06-01 11:48:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/pzm2M5ovKk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91422385&oldid=91422341",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737928160340238336",
  "text" : "Alguien desde CSIC ha editado 'Robert Siodmak' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pzm2M5ovKk",
  "id" : 737928160340238336,
  "created_at" : "2016-06-01 08:45:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/k9IP43mgUw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91422341&oldid=91422334",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737926749204451328",
  "text" : "Alguien desde CSIC ha editado 'Robert Siodmak' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/k9IP43mgUw",
  "id" : 737926749204451328,
  "created_at" : "2016-06-01 08:40:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/SI6C52Wb9n",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=91422334&oldid=81044848",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737926508778541056",
  "text" : "Alguien desde CSIC ha editado 'Robert Siodmak' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SI6C52Wb9n",
  "id" : 737926508778541056,
  "created_at" : "2016-06-01 08:39:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]