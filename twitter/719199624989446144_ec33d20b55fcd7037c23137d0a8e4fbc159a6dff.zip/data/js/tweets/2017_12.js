Grailbird.data.tweets_2017_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/2STuFQzomm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104532201&oldid=104532163",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "946423531566456833",
  "text" : "Alguien desde RedIRIS ha editado 'Michael Reiziger' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2STuFQzomm",
  "id" : 946423531566456833,
  "created_at" : "2017-12-28 16:52:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/lM3L9HOk5x",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104532163&oldid=104532118",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "946422978258046978",
  "text" : "Alguien desde RedIRIS ha editado 'Michael Reiziger' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lM3L9HOk5x",
  "id" : 946422978258046978,
  "created_at" : "2017-12-28 16:49:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/wIYmG23l89",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104532118&oldid=101902397",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "946422531619254272",
  "text" : "Alguien desde RedIRIS ha editado 'Michael Reiziger' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wIYmG23l89",
  "id" : 946422531619254272,
  "created_at" : "2017-12-28 16:48:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/rTCfps8fx2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104530949&oldid=104118123",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "946407067237183489",
  "text" : "Alguien desde RedIRIS ha editado 'Ra\u00FAl Albiol' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rTCfps8fx2",
  "id" : 946407067237183489,
  "created_at" : "2017-12-28 15:46:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Ob6POkgZyL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104526161&oldid=104114670",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "946314814644736001",
  "text" : "Alguien desde RedIRIS ha editado 'Ecuaci\u00F3n de Henderson-Hasselbalch' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ob6POkgZyL",
  "id" : 946314814644736001,
  "created_at" : "2017-12-28 09:40:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/i4R9zmMR6L",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104489853&oldid=100526478",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "945974143698243584",
  "text" : "Alguien desde RedIRIS ha editado 'Dispersi\u00F3n de Rayleigh' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/i4R9zmMR6L",
  "id" : 945974143698243584,
  "created_at" : "2017-12-27 11:06:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Q5Y6icgBap",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104343553&oldid=104343520",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943507981412589568",
  "text" : "Alguien desde CSIC ha editado 'Parque Jur\u00E1sico (franquicia)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Q5Y6icgBap",
  "id" : 943507981412589568,
  "created_at" : "2017-12-20 15:46:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/7AI2XhTgfI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104343520&oldid=104001400",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943507803406323712",
  "text" : "Alguien desde CSIC ha editado 'Parque Jur\u00E1sico (franquicia)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7AI2XhTgfI",
  "id" : 943507803406323712,
  "created_at" : "2017-12-20 15:46:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/nN9PlzrGs2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104341493&oldid=104074846",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943487550689370117",
  "text" : "Alguien desde CSIC ha editado 'Marcos Alonso Mendoza' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/nN9PlzrGs2",
  "id" : 943487550689370117,
  "created_at" : "2017-12-20 14:25:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/urfv5aeQSx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104174490&oldid=104173760",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "941723775686627328",
  "text" : "Alguien desde RedIRIS ha editado 'Camino hamiltoniano' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/urfv5aeQSx",
  "id" : 941723775686627328,
  "created_at" : "2017-12-15 17:36:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/rbHfcWN2F2",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=609636449&oldid=588781189&rcid=645007436",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "941718053452165121",
  "text" : "Alguien desde RedIRIS ha editado 'Q18543530' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rbHfcWN2F2",
  "id" : 941718053452165121,
  "created_at" : "2017-12-15 17:14:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/0ZhCMD0XMn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104173760&oldid=103797812",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "941716491413741568",
  "text" : "Alguien desde RedIRIS ha editado 'Camino hamiltoniano' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0ZhCMD0XMn",
  "id" : 941716491413741568,
  "created_at" : "2017-12-15 17:08:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/YnRfYyErSS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104122959&oldid=104122832",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940993664809095170",
  "text" : "Alguien desde RedIRIS ha editado 'Ye\u00EDsmo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YnRfYyErSS",
  "id" : 940993664809095170,
  "created_at" : "2017-12-13 17:15:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/utW3kLPdV4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104122832&oldid=103257609",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940992629927497728",
  "text" : "Alguien desde RedIRIS ha editado 'Ye\u00EDsmo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/utW3kLPdV4",
  "id" : 940992629927497728,
  "created_at" : "2017-12-13 17:11:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/9nhFzBIeFs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104121006&oldid=104120989",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940970813779562496",
  "text" : "Alguien desde CSIC ha editado 'Sopeira' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9nhFzBIeFs",
  "id" : 940970813779562496,
  "created_at" : "2017-12-13 15:44:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/2644tY28Ew",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104120989&oldid=104120974",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940970599496781829",
  "text" : "Alguien desde CSIC ha editado 'Sopeira' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2644tY28Ew",
  "id" : 940970599496781829,
  "created_at" : "2017-12-13 15:44:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/VWPp6V3QGe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104120974&oldid=103258710",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940970439249158145",
  "text" : "Alguien desde CSIC ha editado 'Sopeira' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VWPp6V3QGe",
  "id" : 940970439249158145,
  "created_at" : "2017-12-13 15:43:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/2AAK7H4RzG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104120286&oldid=104120269",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940962649797472258",
  "text" : "Alguien desde RedIRIS ha editado 'Ullar\u00F3' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2AAK7H4RzG",
  "id" : 940962649797472258,
  "created_at" : "2017-12-13 15:12:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/o55nSXHm19",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104120265&oldid=103951181",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940962384037994496",
  "text" : "Alguien desde RedIRIS ha editado 'Ullar\u00F3' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/o55nSXHm19",
  "id" : 940962384037994496,
  "created_at" : "2017-12-13 15:11:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/1COxoxz0mp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104117014&oldid=104116968",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940911858588020736",
  "text" : "Alguien desde RedIRIS ha editado 'Bitcoin' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1COxoxz0mp",
  "id" : 940911858588020736,
  "created_at" : "2017-12-13 11:50:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/DcGKC9xYrv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104116968&oldid=104104658",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940910954631622657",
  "text" : "Alguien desde RedIRIS ha editado 'Bitcoin' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DcGKC9xYrv",
  "id" : 940910954631622657,
  "created_at" : "2017-12-13 11:47:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ZIOX4hJJLr",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=815204192&oldid=799709155",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940909695170236420",
  "text" : "Alguien desde RedIRIS ha editado 'PAQ' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZIOX4hJJLr",
  "id" : 940909695170236420,
  "created_at" : "2017-12-13 11:42:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/M56WfgyDj6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104115586&oldid=103131028",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940886716080119808",
  "text" : "Alguien desde RedIRIS ha editado 'Baron\u00EDa de Ezpeleta' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/M56WfgyDj6",
  "id" : 940886716080119808,
  "created_at" : "2017-12-13 10:10:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/XfeazWAhG7",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=607942079&oldid=607942041&rcid=643312302",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940881518318309376",
  "text" : "Alguien desde RedIRIS ha editado 'Q6004582' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XfeazWAhG7",
  "id" : 940881518318309376,
  "created_at" : "2017-12-13 09:50:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/wZxsSnQhUa",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=607942041&oldid=607942029&rcid=643312264",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940881479550291968",
  "text" : "Alguien desde RedIRIS ha editado 'Q6004582' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wZxsSnQhUa",
  "id" : 940881479550291968,
  "created_at" : "2017-12-13 09:50:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/O9qX4qsTz2",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=607942029&oldid=607941701&rcid=643312252",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940881469857296390",
  "text" : "Alguien desde RedIRIS ha editado 'Q6004582' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/O9qX4qsTz2",
  "id" : 940881469857296390,
  "created_at" : "2017-12-13 09:49:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/5qN7PMVqK8",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=607941701&oldid=607941697&rcid=643311922",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940881198221492225",
  "text" : "Alguien desde RedIRIS ha editado 'Q6004582' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5qN7PMVqK8",
  "id" : 940881198221492225,
  "created_at" : "2017-12-13 09:48:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/DWBrzl69me",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=607941697&oldid=551993117&rcid=643311919",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940881196585799681",
  "text" : "Alguien desde RedIRIS ha editado 'Q6004582' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DWBrzl69me",
  "id" : 940881196585799681,
  "created_at" : "2017-12-13 09:48:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/fBDrvJmXyv",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19314783&oldid=18645744&rcid=74314800",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940522258178695168",
  "text" : "Alguien desde RedIRIS ha editado 'Miquel Roca i Benn\u00E0ssar' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fBDrvJmXyv",
  "id" : 940522258178695168,
  "created_at" : "2017-12-12 10:02:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/X71waXztRG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104072579&oldid=104072527",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940275737268850690",
  "text" : "Alguien desde RedIRIS ha editado 'Alcal\u00E1 de Henares' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/X71waXztRG",
  "id" : 940275737268850690,
  "created_at" : "2017-12-11 17:42:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/h8hPVR4lkJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104072527&oldid=104029223",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940275381810221056",
  "text" : "Alguien desde RedIRIS ha editado 'Alcal\u00E1 de Henares' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/h8hPVR4lkJ",
  "id" : 940275381810221056,
  "created_at" : "2017-12-11 17:41:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/E0hsLZ6Kvp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104068646&oldid=103614809",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940239034152112130",
  "text" : "Alguien desde RedIRIS ha editado 'Huevo (alimento)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/E0hsLZ6Kvp",
  "id" : 940239034152112130,
  "created_at" : "2017-12-11 15:17:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/x7cMmk3s2a",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104066832&oldid=102169489",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940214943403692033",
  "text" : "Alguien desde RedIRIS ha editado 'Nivel del mar' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/x7cMmk3s2a",
  "id" : 940214943403692033,
  "created_at" : "2017-12-11 13:41:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/LNNjBb7Ves",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104042773&oldid=103637128",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "939839819236237313",
  "text" : "Alguien desde RedIRIS ha editado 'Banco Bilbao Vizcaya Argentaria' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LNNjBb7Ves",
  "id" : 939839819236237313,
  "created_at" : "2017-12-10 12:50:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/1FUL8pBOM8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103944764&oldid=103399214",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "938060573132107776",
  "text" : "Alguien desde CSIC ha editado 'Instituto Cajal' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1FUL8pBOM8",
  "id" : 938060573132107776,
  "created_at" : "2017-12-05 15:00:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/DPOONELfwK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103942967&oldid=87446714",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "938026310156288000",
  "text" : "Alguien desde RedIRIS ha editado 'Refer\u00E9ndum constitucional de Egipto de 2012' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DPOONELfwK",
  "id" : 938026310156288000,
  "created_at" : "2017-12-05 12:44:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/pyDuLlGBOt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103940371&oldid=103875700",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937964378183340032",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Espa\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pyDuLlGBOt",
  "id" : 937964378183340032,
  "created_at" : "2017-12-05 08:38:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/OuCComR4n6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103914736&oldid=102990832",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937590823251791872",
  "text" : "Alguien desde RedIRIS ha editado 'Emilio Bueso' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OuCComR4n6",
  "id" : 937590823251791872,
  "created_at" : "2017-12-04 07:54:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/eWjUGQfU4f",
      "expanded_url" : "https:\/\/it.wikipedia.org\/w\/index.php?diff=92920654&oldid=91184862&rcid=231901750",
      "display_url" : "it.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936560737153159168",
  "text" : "Alguien desde CSIC ha editado 'Parco nazionale di Do\u00F1ana' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eWjUGQfU4f",
  "id" : 936560737153159168,
  "created_at" : "2017-12-01 11:40:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]