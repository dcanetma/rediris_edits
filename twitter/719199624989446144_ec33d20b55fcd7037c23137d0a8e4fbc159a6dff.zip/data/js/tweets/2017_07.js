Grailbird.data.tweets_2017_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/RFDLfM0Cra",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100829262&oldid=100829256",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "891999365329543168",
  "text" : "Alguien desde CSIC ha editado 'And\u00FAjar' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RFDLfM0Cra",
  "id" : 891999365329543168,
  "created_at" : "2017-07-31 12:29:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/35WPKqi7jW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100829256&oldid=100631001",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "891999248732094464",
  "text" : "Alguien desde CSIC ha editado 'And\u00FAjar' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/35WPKqi7jW",
  "id" : 891999248732094464,
  "created_at" : "2017-07-31 12:29:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/YTCNkevQYD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100807508&oldid=100644864",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "891559335163297792",
  "text" : "Alguien desde CSIC ha editado 'Wikiproyecto:Mujeres&amp;#x2F;Wikimujeres&amp;#x2F;Euskad' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YTCNkevQYD",
  "id" : 891559335163297792,
  "created_at" : "2017-07-30 07:21:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/UdqXLwseLM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100744932&oldid=84314476",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890493136027480064",
  "text" : "Alguien desde CSIC ha editado 'Luis Balaguer N\u00FA\u00F1ez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UdqXLwseLM",
  "id" : 890493136027480064,
  "created_at" : "2017-07-27 08:44:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/hPjOIfa0CY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100722381&oldid=64442372",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890223675571675139",
  "text" : "Alguien desde CSIC ha editado 'Hoechst (colorante)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hPjOIfa0CY",
  "id" : 890223675571675139,
  "created_at" : "2017-07-26 14:53:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/exMfsP9c2f",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100715350&oldid=100715294",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890119631737946112",
  "text" : "Alguien desde RedIRIS ha editado 'Falcon Heavy' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/exMfsP9c2f",
  "id" : 890119631737946112,
  "created_at" : "2017-07-26 08:00:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/WZhfJNSkJX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100715294&oldid=100030227",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890119359464689664",
  "text" : "Alguien desde RedIRIS ha editado 'Falcon Heavy' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WZhfJNSkJX",
  "id" : 890119359464689664,
  "created_at" : "2017-07-26 07:59:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Hyob2TImO4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100715113&oldid=100662227",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890116590607486976",
  "text" : "Alguien desde RedIRIS ha editado 'Bonnie Wright' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Hyob2TImO4",
  "id" : 890116590607486976,
  "created_at" : "2017-07-26 07:48:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/8dSa6ywKQ4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100610411&oldid=93134901",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "888400201685315585",
  "text" : "Alguien desde CSIC ha editado 'Xiphophorus maculatus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8dSa6ywKQ4",
  "id" : 888400201685315585,
  "created_at" : "2017-07-21 14:08:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/VtYIq0ED1d",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100589843&oldid=100290485",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "888038204175249414",
  "text" : "Alguien desde CSIC ha editado 'Quiralidad (qu\u00EDmica)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VtYIq0ED1d",
  "id" : 888038204175249414,
  "created_at" : "2017-07-20 14:09:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/1Gspd7X88r",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100587112&oldid=98036830",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "887968588207927297",
  "text" : "Alguien desde CSIC ha editado '\u0393' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1Gspd7X88r",
  "id" : 887968588207927297,
  "created_at" : "2017-07-20 09:33:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/9VUk42ntRF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100585174&oldid=99094586",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "887912242003554304",
  "text" : "Alguien desde CSIC ha editado 'Barco tortuga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9VUk42ntRF",
  "id" : 887912242003554304,
  "created_at" : "2017-07-20 05:49:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/0qQMFMGNJW",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18658955&oldid=17919629&rcid=55412053",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "887609609317490690",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0qQMFMGNJW",
  "id" : 887609609317490690,
  "created_at" : "2017-07-19 09:46:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/hU1JeuxzUu",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=791295257&oldid=783039202",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "887609231725264896",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco (writer)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hU1JeuxzUu",
  "id" : 887609231725264896,
  "created_at" : "2017-07-19 09:45:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/fKZeUmXtJN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100567055&oldid=100470826",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "887605654982189056",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fKZeUmXtJN",
  "id" : 887605654982189056,
  "created_at" : "2017-07-19 09:30:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/3DjXxfyf9d",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=790986506&oldid=790986361",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "886908791517843457",
  "text" : "Alguien desde CSIC ha editado 'Filip Manojlovi\u0107' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3DjXxfyf9d",
  "id" : 886908791517843457,
  "created_at" : "2017-07-17 11:21:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/iom02IbSmQ",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=790986361&oldid=790958210",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "886908367368855552",
  "text" : "Alguien desde CSIC ha editado 'Filip Manojlovi\u0107' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iom02IbSmQ",
  "id" : 886908367368855552,
  "created_at" : "2017-07-17 11:20:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xXabGlmnGz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100445684&oldid=100445646",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "885456693345353728",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xXabGlmnGz",
  "id" : 885456693345353728,
  "created_at" : "2017-07-13 11:11:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/87OJdH8egV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100445646&oldid=99498640",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "885456014602063872",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/87OJdH8egV",
  "id" : 885456014602063872,
  "created_at" : "2017-07-13 11:08:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/lHm3Th6EWw",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=789438788&oldid=748422275",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883267669675397120",
  "text" : "Alguien desde CSIC ha editado 'Lysis buffer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lHm3Th6EWw",
  "id" : 883267669675397120,
  "created_at" : "2017-07-07 10:13:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/KXaAHuKEEb",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=789092724&oldid=788500515",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "882523539060002817",
  "text" : "Alguien desde RedIRIS ha editado 'Universal asynchronous receiver&amp;#x2F;transmitter' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KXaAHuKEEb",
  "id" : 882523539060002817,
  "created_at" : "2017-07-05 08:56:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/dbgAKEHkDD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100254350&oldid=98451732",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "882239232974213121",
  "text" : "Alguien desde RedIRIS ha editado 'Oxidante' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dbgAKEHkDD",
  "id" : 882239232974213121,
  "created_at" : "2017-07-04 14:06:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/oGO53UsVAa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100254318&oldid=99316217",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "882238722804260864",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito de sodio' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oGO53UsVAa",
  "id" : 882238722804260864,
  "created_at" : "2017-07-04 14:04:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/NGXrUbeiCQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100236028&oldid=99565970",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "881906472124370945",
  "text" : "Alguien desde RedIRIS ha editado 'The Skatalites' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NGXrUbeiCQ",
  "id" : 881906472124370945,
  "created_at" : "2017-07-03 16:04:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/wPHlO8pVyf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100231433&oldid=100217705",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "881813306083815427",
  "text" : "Alguien desde CSIC ha editado '\u00C1ngel Luis Rodr\u00EDguez D\u00EDaz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wPHlO8pVyf",
  "id" : 881813306083815427,
  "created_at" : "2017-07-03 09:54:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]