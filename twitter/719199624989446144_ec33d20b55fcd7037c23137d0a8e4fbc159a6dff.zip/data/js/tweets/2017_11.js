Grailbird.data.tweets_2017_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/0MTReN8c2A",
      "expanded_url" : "https:\/\/commons.wikimedia.org\/w\/index.php?diff=270013718&oldid=269786649&rcid=1006986590",
      "display_url" : "commons.wikimedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936204925104779264",
  "text" : "Alguien desde RedIRIS ha editado 'Commons:Deletion requests&amp;#x2F;File:LA VIOLENCIA CO' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0MTReN8c2A",
  "id" : 936204925104779264,
  "created_at" : "2017-11-30 12:07:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/u13ysMoNDr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103819263&oldid=102935044",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936178384861892608",
  "text" : "Alguien desde RedIRIS ha editado 'Baeza (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/u13ysMoNDr",
  "id" : 936178384861892608,
  "created_at" : "2017-11-30 10:21:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/gTFhy2ekQj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103817328&oldid=103614366",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936149901368614912",
  "text" : "Alguien desde RedIRIS ha editado 'Arroz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gTFhy2ekQj",
  "id" : 936149901368614912,
  "created_at" : "2017-11-30 08:28:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/M4pGepGfTe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103772069&oldid=103404754",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935562680047423488",
  "text" : "Alguien desde RedIRIS ha editado 'Antonio Maestre Hern\u00E1ndez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/M4pGepGfTe",
  "id" : 935562680047423488,
  "created_at" : "2017-11-28 17:34:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/kokwfzCkyZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103767922&oldid=103767898",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935524860364771330",
  "text" : "Alguien desde RedIRIS ha editado 'Ninhidrina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kokwfzCkyZ",
  "id" : 935524860364771330,
  "created_at" : "2017-11-28 15:04:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/kyUQTDetRU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103767898&oldid=103767853",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935524506810093568",
  "text" : "Alguien desde RedIRIS ha editado 'Ninhidrina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kyUQTDetRU",
  "id" : 935524506810093568,
  "created_at" : "2017-11-28 15:03:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Oi9rlObFsT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103767853&oldid=103048154",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935523913278345218",
  "text" : "Alguien desde RedIRIS ha editado 'Ninhidrina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Oi9rlObFsT",
  "id" : 935523913278345218,
  "created_at" : "2017-11-28 15:00:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/ZRTDgfqVAg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103764417&oldid=102991563",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935477127419432960",
  "text" : "Alguien desde CSIC ha editado 'Flamenqu\u00EDn' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZRTDgfqVAg",
  "id" : 935477127419432960,
  "created_at" : "2017-11-28 11:55:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/0lzvlB7d37",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103763488&oldid=103091703",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935462477235654656",
  "text" : "Alguien desde RedIRIS ha editado 'Tript\u00F3fano' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0lzvlB7d37",
  "id" : 935462477235654656,
  "created_at" : "2017-11-28 10:56:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/KzTvUvoAOZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103763263&oldid=103675657",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935457334872215554",
  "text" : "Alguien desde RedIRIS ha editado 'La que se avecina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KzTvUvoAOZ",
  "id" : 935457334872215554,
  "created_at" : "2017-11-28 10:36:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/IwE7a8UAvm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762675&oldid=100535869",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935447604850290688",
  "text" : "Alguien desde RedIRIS ha editado 'Escala de inteligencia Stanford-Binet' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IwE7a8UAvm",
  "id" : 935447604850290688,
  "created_at" : "2017-11-28 09:57:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/84WrmIoqax",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762618&oldid=102835797",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935446331266666497",
  "text" : "Alguien desde RedIRIS ha editado 'Arginina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/84WrmIoqax",
  "id" : 935446331266666497,
  "created_at" : "2017-11-28 09:52:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/D4wlC1zG98",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762561&oldid=101964258",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935444995598938113",
  "text" : "Alguien desde RedIRIS ha editado 'Histidina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/D4wlC1zG98",
  "id" : 935444995598938113,
  "created_at" : "2017-11-28 09:47:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/TABBkD9NVt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762466&oldid=103762459",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935443220150083584",
  "text" : "Alguien desde RedIRIS ha editado 'Tirosina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TABBkD9NVt",
  "id" : 935443220150083584,
  "created_at" : "2017-11-28 09:40:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/NHSSeHXnbj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762459&oldid=99486939",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935443100708818944",
  "text" : "Alguien desde RedIRIS ha editado 'Tirosina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NHSSeHXnbj",
  "id" : 935443100708818944,
  "created_at" : "2017-11-28 09:39:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/uqvkBkejBo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762238&oldid=103762235",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935438482599809024",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uqvkBkejBo",
  "id" : 935438482599809024,
  "created_at" : "2017-11-28 09:21:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/9TbjMrCoXG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762235&oldid=103762226",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935438389645643776",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9TbjMrCoXG",
  "id" : 935438389645643776,
  "created_at" : "2017-11-28 09:21:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/6Amiz5FJvB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762226&oldid=103762216",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935438172397465602",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6Amiz5FJvB",
  "id" : 935438172397465602,
  "created_at" : "2017-11-28 09:20:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/1oBwgAb5tg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762216&oldid=103762210",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935438000716214272",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1oBwgAb5tg",
  "id" : 935438000716214272,
  "created_at" : "2017-11-28 09:19:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/kBbmCNzVCP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762210&oldid=103762208",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935437902888210432",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kBbmCNzVCP",
  "id" : 935437902888210432,
  "created_at" : "2017-11-28 09:19:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JTL0XwaVkG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103762208&oldid=103747162",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935437792791990272",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JTL0XwaVkG",
  "id" : 935437792791990272,
  "created_at" : "2017-11-28 09:18:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/0d23vxUfvS",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=812411554&oldid=785217485",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935218580387516417",
  "text" : "Alguien desde RedIRIS ha editado 'Wellesley House School' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0d23vxUfvS",
  "id" : 935218580387516417,
  "created_at" : "2017-11-27 18:47:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/wckXI0f1lH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103747293&oldid=102105711",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935217914801729536",
  "text" : "Alguien desde RedIRIS ha editado 'Colegio Nuestra Se\u00F1ora de las Maravillas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wckXI0f1lH",
  "id" : 935217914801729536,
  "created_at" : "2017-11-27 18:45:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/8yWGlx5oLq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103747162&oldid=103747053",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935216531121766401",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8yWGlx5oLq",
  "id" : 935216531121766401,
  "created_at" : "2017-11-27 18:39:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/3slKL7O5vo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103747053&oldid=103739043",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935215733096763394",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3slKL7O5vo",
  "id" : 935215733096763394,
  "created_at" : "2017-11-27 18:36:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Bh3TFZ05rw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103739064&oldid=103735712",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935125588234457089",
  "text" : "Alguien desde RedIRIS ha editado 'Pedro S\u00E1nchez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Bh3TFZ05rw",
  "id" : 935125588234457089,
  "created_at" : "2017-11-27 12:38:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/IhU4sAndxZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103739035&oldid=103739024",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935125155524866048",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IhU4sAndxZ",
  "id" : 935125155524866048,
  "created_at" : "2017-11-27 12:36:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ubYEwZkf0M",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103739024&oldid=103739016",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935124909885480960",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ubYEwZkf0M",
  "id" : 935124909885480960,
  "created_at" : "2017-11-27 12:35:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/mhTtwzC6fk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103739000&oldid=103738992",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935124503331557376",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mhTtwzC6fk",
  "id" : 935124503331557376,
  "created_at" : "2017-11-27 12:33:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/NnLV2p9IEG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738992&oldid=103738987",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935124332015226880",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NnLV2p9IEG",
  "id" : 935124332015226880,
  "created_at" : "2017-11-27 12:33:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/oS60npfVg8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738987&oldid=103738972",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935124263497060354",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oS60npfVg8",
  "id" : 935124263497060354,
  "created_at" : "2017-11-27 12:32:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/FtK3ysuBpj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738972&oldid=103738939",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935123905962037248",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FtK3ysuBpj",
  "id" : 935123905962037248,
  "created_at" : "2017-11-27 12:31:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/3Znfo8uuQu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738968&oldid=103738964",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935123829290098689",
  "text" : "Alguien desde RedIRIS ha editado 'Asturias' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3Znfo8uuQu",
  "id" : 935123829290098689,
  "created_at" : "2017-11-27 12:31:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/KlnsbAclfm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738964&oldid=103704246",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935123694908735488",
  "text" : "Alguien desde RedIRIS ha editado 'Asturias' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KlnsbAclfm",
  "id" : 935123694908735488,
  "created_at" : "2017-11-27 12:30:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/srvd0O7liO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738939&oldid=103738928",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935123213255888896",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/srvd0O7liO",
  "id" : 935123213255888896,
  "created_at" : "2017-11-27 12:28:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Fwwp6BbQc8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738928&oldid=103738919",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935123046301667329",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Fwwp6BbQc8",
  "id" : 935123046301667329,
  "created_at" : "2017-11-27 12:28:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/3x0GdDW4MO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738919&oldid=103738910",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935122936721223680",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3x0GdDW4MO",
  "id" : 935122936721223680,
  "created_at" : "2017-11-27 12:27:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ohXp10jmmV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738910&oldid=103738890",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935122694638628864",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ohXp10jmmV",
  "id" : 935122694638628864,
  "created_at" : "2017-11-27 12:26:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/FOla5Xl73N",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738890&oldid=103738874",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935122423636209664",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FOla5Xl73N",
  "id" : 935122423636209664,
  "created_at" : "2017-11-27 12:25:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/IH4ExgbsgF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738874&oldid=103379315",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935122155473383424",
  "text" : "Alguien desde RedIRIS ha editado 'Will Smith' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IH4ExgbsgF",
  "id" : 935122155473383424,
  "created_at" : "2017-11-27 12:24:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/2qJ52dzr1L",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738856&oldid=103738842",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935121883686633472",
  "text" : "Alguien desde RedIRIS ha editado 'Valencia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2qJ52dzr1L",
  "id" : 935121883686633472,
  "created_at" : "2017-11-27 12:23:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/8dg9XW4vx3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738842&oldid=103738838",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935121612617207808",
  "text" : "Alguien desde RedIRIS ha editado 'Valencia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8dg9XW4vx3",
  "id" : 935121612617207808,
  "created_at" : "2017-11-27 12:22:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/y9YGkhxxMQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103738838&oldid=103689870",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935121506912305152",
  "text" : "Alguien desde RedIRIS ha editado 'Valencia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/y9YGkhxxMQ",
  "id" : 935121506912305152,
  "created_at" : "2017-11-27 12:21:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Ve1Fxt1nNf",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=6062574&oldid=6062569",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "934370148882018304",
  "text" : "Alguien desde RedIRIS ha editado 'Deustuko Unibertsitateko Ingeniaritza Fakultatea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ve1Fxt1nNf",
  "id" : 934370148882018304,
  "created_at" : "2017-11-25 10:36:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/2pjxhgUJYI",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=6062569&oldid=5572546",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "934369742332334081",
  "text" : "Alguien desde RedIRIS ha editado 'Deustuko Unibertsitateko Ingeniaritza Fakultatea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2pjxhgUJYI",
  "id" : 934369742332334081,
  "created_at" : "2017-11-25 10:34:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/A6mSVru7RA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103664180&oldid=103663401",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933991028599730176",
  "text" : "Alguien desde RedIRIS ha editado 'La casa de papel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A6mSVru7RA",
  "id" : 933991028599730176,
  "created_at" : "2017-11-24 09:29:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/oex9prASTR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103662831&oldid=103183327",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933956393568231425",
  "text" : "Alguien desde RedIRIS ha editado 'Francina Armengol' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oex9prASTR",
  "id" : 933956393568231425,
  "created_at" : "2017-11-24 07:12:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/0QWfFDi3rF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103645795&oldid=103645785",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933749239875801090",
  "text" : "Alguien desde RedIRIS ha editado 'Arguedas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0QWfFDi3rF",
  "id" : 933749239875801090,
  "created_at" : "2017-11-23 17:29:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Jk3OFyiqbn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103645785&oldid=102553140",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933749110838120449",
  "text" : "Alguien desde RedIRIS ha editado 'Arguedas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Jk3OFyiqbn",
  "id" : 933749110838120449,
  "created_at" : "2017-11-23 17:28:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/fTF7GpzbPu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103645711&oldid=103645703",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933748352801542146",
  "text" : "Alguien desde RedIRIS ha editado 'Arr\u00F3niz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fTF7GpzbPu",
  "id" : 933748352801542146,
  "created_at" : "2017-11-23 17:25:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/bSJgAkvxCz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103645703&oldid=103645683",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933748302000148480",
  "text" : "Alguien desde RedIRIS ha editado 'Arr\u00F3niz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bSJgAkvxCz",
  "id" : 933748302000148480,
  "created_at" : "2017-11-23 17:25:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/of5LvD9XDr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103645683&oldid=103645664",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933748218889932801",
  "text" : "Alguien desde RedIRIS ha editado 'Arr\u00F3niz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/of5LvD9XDr",
  "id" : 933748218889932801,
  "created_at" : "2017-11-23 17:24:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Km6W003KSV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103645664&oldid=102882424",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933748055731593218",
  "text" : "Alguien desde RedIRIS ha editado 'Arr\u00F3niz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Km6W003KSV",
  "id" : 933748055731593218,
  "created_at" : "2017-11-23 17:24:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/AjNwDoTFud",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=811583909&oldid=778028390",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933362464653238273",
  "text" : "Alguien desde CSIC ha editado 'Transferrin receptor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AjNwDoTFud",
  "id" : 933362464653238273,
  "created_at" : "2017-11-22 15:52:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lSu5y1qQbp",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=142840027&oldid=141353264&rcid=348525930",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933353374526967809",
  "text" : "Alguien desde RedIRIS ha editado 'David Boring' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lSu5y1qQbp",
  "id" : 933353374526967809,
  "created_at" : "2017-11-22 15:16:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/WF3kri2KEm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103589761&oldid=96516732",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932987609684545536",
  "text" : "Alguien desde RedIRIS ha editado 'Cl\u00E1usula de Horn' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WF3kri2KEm",
  "id" : 932987609684545536,
  "created_at" : "2017-11-21 15:02:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/HbXSI8dmZY",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=811242204&oldid=811242159",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932569818506715136",
  "text" : "Alguien desde CSIC ha editado 'Parvularia atlantis' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HbXSI8dmZY",
  "id" : 932569818506715136,
  "created_at" : "2017-11-20 11:22:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xol4p4hQ1N",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=811242159&oldid=811173538",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932569652009603072",
  "text" : "Alguien desde CSIC ha editado 'Parvularia atlantis' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xol4p4hQ1N",
  "id" : 932569652009603072,
  "created_at" : "2017-11-20 11:21:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/ote8IRdJth",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=596354481&oldid=551895196&rcid=631709059",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932556820559822848",
  "text" : "Alguien desde RedIRIS ha editado 'Q5938235' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ote8IRdJth",
  "id" : 932556820559822848,
  "created_at" : "2017-11-20 10:30:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/WZAHuHd16Y",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103559097&oldid=102553898",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932547850843623424",
  "text" : "Alguien desde RedIRIS ha editado 'Competitividad' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WZAHuHd16Y",
  "id" : 932547850843623424,
  "created_at" : "2017-11-20 09:55:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0XZEaNlVow",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103536505&oldid=102504625",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932220129240408065",
  "text" : "Alguien desde RedIRIS ha editado 'Fertilizaci\u00F3n con hierro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0XZEaNlVow",
  "id" : 932220129240408065,
  "created_at" : "2017-11-19 12:12:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/ot1DrQ3cXr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103519151&oldid=94962579",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931948901942415360",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Universidades, colegios mayores, centros y ag' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ot1DrQ3cXr",
  "id" : 931948901942415360,
  "created_at" : "2017-11-18 18:15:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/n05LGBIklt",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=810959065&oldid=807756716",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931918718627729414",
  "text" : "Alguien desde RedIRIS ha editado 'Gabba Gabba Hey' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/n05LGBIklt",
  "id" : 931918718627729414,
  "created_at" : "2017-11-18 16:15:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Ic3zX04YmF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103483211&oldid=102454105",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931462718707650560",
  "text" : "Alguien desde CSIC ha editado 'Rodrigo Calder\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ic3zX04YmF",
  "id" : 931462718707650560,
  "created_at" : "2017-11-17 10:03:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/3T9k30mnld",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103465839&oldid=103323459",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931206068444762112",
  "text" : "Alguien desde RedIRIS ha editado 'Sergio Herrera Pir\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3T9k30mnld",
  "id" : 931206068444762112,
  "created_at" : "2017-11-16 17:03:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/QlAYn8BYZt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103455133&oldid=102921374",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931097754306215936",
  "text" : "Alguien desde RedIRIS ha editado 'Jorge Due\u00F1as' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QlAYn8BYZt",
  "id" : 931097754306215936,
  "created_at" : "2017-11-16 09:52:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/KM0uXqtSgC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103436543&oldid=103436466",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930874790486925312",
  "text" : "Alguien desde RedIRIS ha editado 'Yellow' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KM0uXqtSgC",
  "id" : 930874790486925312,
  "created_at" : "2017-11-15 19:06:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/MUxtmYN6Bh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103436459&oldid=100079891",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930873932772728833",
  "text" : "Alguien desde RedIRIS ha editado 'Yellow' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MUxtmYN6Bh",
  "id" : 930873932772728833,
  "created_at" : "2017-11-15 19:03:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/IFmQWhQABE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103428634&oldid=103223346",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930775251402874880",
  "text" : "Alguien desde RedIRIS ha editado 'Gestaci\u00F3n subrogada' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IFmQWhQABE",
  "id" : 930775251402874880,
  "created_at" : "2017-11-15 12:31:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/81plliKpac",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103428481&oldid=103425975",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930772495107526656",
  "text" : "Alguien desde RedIRIS ha editado 'AGIL' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/81plliKpac",
  "id" : 930772495107526656,
  "created_at" : "2017-11-15 12:20:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/PowIfpwquQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103426247&oldid=97827770",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930759144205889536",
  "text" : "Alguien desde RedIRIS ha editado 'Geremi Njitap' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PowIfpwquQ",
  "id" : 930759144205889536,
  "created_at" : "2017-11-15 11:27:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ihScJXdQJY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103424793&oldid=98607552",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930722102113656832",
  "text" : "Alguien desde CSIC ha editado 'Rubus idaeus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ihScJXdQJY",
  "id" : 930722102113656832,
  "created_at" : "2017-11-15 09:00:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/4dlDy1rRGI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103406868&oldid=102981503",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930477704171999232",
  "text" : "Alguien desde RedIRIS ha editado 'Airbus A350' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4dlDy1rRGI",
  "id" : 930477704171999232,
  "created_at" : "2017-11-14 16:49:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/LW6Pu3GfmI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103404745&oldid=103386722",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930456595066249216",
  "text" : "Alguien desde RedIRIS ha editado 'Antonio Maestre Hern\u00E1ndez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LW6Pu3GfmI",
  "id" : 930456595066249216,
  "created_at" : "2017-11-14 15:25:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/VW8ryqgraW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103397822&oldid=102997042",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930330982208688128",
  "text" : "Alguien desde RedIRIS ha editado 'The European Law Students&amp;#39; Association' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VW8ryqgraW",
  "id" : 930330982208688128,
  "created_at" : "2017-11-14 07:06:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/AdIoOXpCkq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103381922&oldid=103226674",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930130371819327488",
  "text" : "Alguien desde RedIRIS ha editado 'Antonio Maestre Hern\u00E1ndez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AdIoOXpCkq",
  "id" : 930130371819327488,
  "created_at" : "2017-11-13 17:48:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/x5tWyJkDz2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103373942&oldid=98476000",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930041894284988417",
  "text" : "Alguien desde CSIC ha editado 'Seneg\u00FC\u00E9' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/x5tWyJkDz2",
  "id" : 930041894284988417,
  "created_at" : "2017-11-13 11:57:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/9cbRYkZ2sL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103371709&oldid=101734883",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930006694901551105",
  "text" : "Alguien desde RedIRIS ha editado 'Santa\u00F1y' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9cbRYkZ2sL",
  "id" : 930006694901551105,
  "created_at" : "2017-11-13 09:37:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/I4EqgtEAjQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103307221&oldid=103292192",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "929023113559494662",
  "text" : "Alguien desde RedIRIS ha editado 'El Corte Ingl\u00E9s' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/I4EqgtEAjQ",
  "id" : 929023113559494662,
  "created_at" : "2017-11-10 16:29:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/ANCpQL9YuO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103304213&rcid=176709209",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928982651918307328",
  "text" : "Alguien desde RedIRIS ha editado 'Consejos Insulares de Baleares' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ANCpQL9YuO",
  "id" : 928982651918307328,
  "created_at" : "2017-11-10 13:48:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/mPtuNYECMk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103303998&rcid=176708589",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928979955567988736",
  "text" : "Alguien desde RedIRIS ha editado 'Juntas Generales del Pa\u00EDs Vasco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mPtuNYECMk",
  "id" : 928979955567988736,
  "created_at" : "2017-11-10 13:37:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/372h2NP926",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103303896&rcid=176708208",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928978450509070336",
  "text" : "Alguien desde RedIRIS ha editado 'Junta General de Vizcaya' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/372h2NP926",
  "id" : 928978450509070336,
  "created_at" : "2017-11-10 13:31:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/XfeYYFB6Br",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103303892&rcid=176708188",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928978366048456706",
  "text" : "Alguien desde RedIRIS ha editado 'Junta General de Guip\u00FAzcoa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XfeYYFB6Br",
  "id" : 928978366048456706,
  "created_at" : "2017-11-10 13:31:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/8ktRA2k8dX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103303884&rcid=176708155",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928978216282415104",
  "text" : "Alguien desde RedIRIS ha editado 'Junta General de \u00C1lava' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8ktRA2k8dX",
  "id" : 928978216282415104,
  "created_at" : "2017-11-10 13:30:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/vVGhkdu0S9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103300989&oldid=103300927",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928916784668954625",
  "text" : "Alguien desde RedIRIS ha editado 'Europa Football Club' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vVGhkdu0S9",
  "id" : 928916784668954625,
  "created_at" : "2017-11-10 09:26:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/deHy5xva2U",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103300927&oldid=101176230",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928915484766081024",
  "text" : "Alguien desde RedIRIS ha editado 'Europa Football Club' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/deHy5xva2U",
  "id" : 928915484766081024,
  "created_at" : "2017-11-10 09:21:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Qo0sfRIhYz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103278669&rcid=176660126",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928608179503685632",
  "text" : "Alguien desde RedIRIS ha editado 'Elecciones al Consejo General de Ar\u00E1n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Qo0sfRIhYz",
  "id" : 928608179503685632,
  "created_at" : "2017-11-09 13:00:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/72psKtghhu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103278659&oldid=103278633",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928608047043350529",
  "text" : "Alguien desde RedIRIS ha editado 'Elecciones en Espa\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/72psKtghhu",
  "id" : 928608047043350529,
  "created_at" : "2017-11-09 12:59:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/0pR4WtqnRN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103278641&rcid=176660054",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928607870479986688",
  "text" : "Alguien desde RedIRIS ha editado 'Elecciones a los Cabildos Insulares canarios' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0pR4WtqnRN",
  "id" : 928607870479986688,
  "created_at" : "2017-11-09 12:59:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/uxoZuZoFxH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103278633&oldid=103278591",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928607775353180160",
  "text" : "Alguien desde RedIRIS ha editado 'Elecciones en Espa\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uxoZuZoFxH",
  "id" : 928607775353180160,
  "created_at" : "2017-11-09 12:58:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/7s2ddUhZ42",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=103278603&rcid=176659959",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928607318471737345",
  "text" : "Alguien desde RedIRIS ha editado 'Elecciones a las Juntas Generales del Pa\u00EDs Vasco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7s2ddUhZ42",
  "id" : 928607318471737345,
  "created_at" : "2017-11-09 12:56:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Xp9DVY3OiT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103278591&oldid=103224712",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928606997292965888",
  "text" : "Alguien desde RedIRIS ha editado 'Elecciones en Espa\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Xp9DVY3OiT",
  "id" : 928606997292965888,
  "created_at" : "2017-11-09 12:55:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Y0jv4Nm4Bw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103277610&oldid=103277525",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928593239581618176",
  "text" : "Alguien desde RedIRIS ha editado '14 de marzo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Y0jv4Nm4Bw",
  "id" : 928593239581618176,
  "created_at" : "2017-11-09 12:00:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/95t0nYe99W",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103277525&oldid=102818602",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928592050735538176",
  "text" : "Alguien desde RedIRIS ha editado '14 de marzo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/95t0nYe99W",
  "id" : 928592050735538176,
  "created_at" : "2017-11-09 11:56:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/sBrCRjHKK7",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19153588&oldid=19153577&rcid=73201417",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928553737332908032",
  "text" : "Alguien desde RedIRIS ha editado 'Nombre e' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sBrCRjHKK7",
  "id" : 928553737332908032,
  "created_at" : "2017-11-09 09:23:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/MEuc5DKxSv",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19153577&oldid=18930522&rcid=73201374",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928552775050461185",
  "text" : "Alguien desde RedIRIS ha editado 'Nombre e' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MEuc5DKxSv",
  "id" : 928552775050461185,
  "created_at" : "2017-11-09 09:20:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/oQj4jKjvRX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103275206&oldid=103275203",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928541697503526912",
  "text" : "Alguien desde RedIRIS ha editado 'Serie convergente' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oQj4jKjvRX",
  "id" : 928541697503526912,
  "created_at" : "2017-11-09 08:36:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9lMMMSMU8U",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103275203&oldid=103260115",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928541566733570048",
  "text" : "Alguien desde RedIRIS ha editado 'Serie convergente' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9lMMMSMU8U",
  "id" : 928541566733570048,
  "created_at" : "2017-11-09 08:35:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/zAo5W27BwO",
      "expanded_url" : "https:\/\/commons.wikimedia.org\/w\/index.php?diff=266578246&oldid=253974676&rcid=998530317",
      "display_url" : "commons.wikimedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928213117573697539",
  "text" : "Alguien desde CSIC ha editado 'File:Manuel Salesa - July 2015.JPG' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zAo5W27BwO",
  "id" : 928213117573697539,
  "created_at" : "2017-11-08 10:50:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/F4CNLW9ThP",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=590623518&oldid=590623323&rcid=625970215",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928176166850256896",
  "text" : "Alguien desde RedIRIS ha editado 'Q3390901' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/F4CNLW9ThP",
  "id" : 928176166850256896,
  "created_at" : "2017-11-08 08:23:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/0KphmyMrTJ",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=590623323&oldid=588875219&rcid=625970023",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928176062642737153",
  "text" : "Alguien desde RedIRIS ha editado 'Q3390901' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0KphmyMrTJ",
  "id" : 928176062642737153,
  "created_at" : "2017-11-08 08:23:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ueQBja235S",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103224712&oldid=103159918",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927927884676829185",
  "text" : "Alguien desde RedIRIS ha editado 'Elecciones en Espa\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ueQBja235S",
  "id" : 927927884676829185,
  "created_at" : "2017-11-07 15:57:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/awx5HZnB2G",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103223866&oldid=103198716",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927918216818647040",
  "text" : "Alguien desde RedIRIS ha editado 'Antonio Maestre Hern\u00E1ndez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/awx5HZnB2G",
  "id" : 927918216818647040,
  "created_at" : "2017-11-07 15:18:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Shc9ssGwKe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103221527&oldid=103221521",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927883373623894016",
  "text" : "Alguien desde RedIRIS ha editado 'Friki' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Shc9ssGwKe",
  "id" : 927883373623894016,
  "created_at" : "2017-11-07 13:00:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/JNGcZUTB2c",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103221521&oldid=103041661",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927883247438258176",
  "text" : "Alguien desde RedIRIS ha editado 'Friki' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JNGcZUTB2c",
  "id" : 927883247438258176,
  "created_at" : "2017-11-07 12:59:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/7v2tHqvpOJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103218817&oldid=102997436",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927837657979412482",
  "text" : "Alguien desde RedIRIS ha editado 'Problema del viajante' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7v2tHqvpOJ",
  "id" : 927837657979412482,
  "created_at" : "2017-11-07 09:58:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/bsOfM2LG0O",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103202840&oldid=103165590",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927608622821060611",
  "text" : "Alguien desde RedIRIS ha editado 'Denia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bsOfM2LG0O",
  "id" : 927608622821060611,
  "created_at" : "2017-11-06 18:48:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Wumx09KmRF",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=809018163&oldid=808119609",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927584859165483008",
  "text" : "Alguien desde CSIC ha editado 'New Flemish Alliance' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Wumx09KmRF",
  "id" : 927584859165483008,
  "created_at" : "2017-11-06 17:13:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/z386XzpkPz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103198175&oldid=103039508",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927563385394384896",
  "text" : "Alguien desde RedIRIS ha editado 'Antonio Maestre Hern\u00E1ndez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/z386XzpkPz",
  "id" : 927563385394384896,
  "created_at" : "2017-11-06 15:48:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/DhzzQ8Oj2l",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808985642&oldid=808985456",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927520462560743424",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DhzzQ8Oj2l",
  "id" : 927520462560743424,
  "created_at" : "2017-11-06 12:58:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ToIv5I47Wm",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808985456&oldid=808978437",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927519997244649472",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ToIv5I47Wm",
  "id" : 927519997244649472,
  "created_at" : "2017-11-06 12:56:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/EH7tPTwcP5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103194229&oldid=97732571",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927514059368525824",
  "text" : "Alguien desde CSIC ha editado 'Neophron percnopterus majorensis' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EH7tPTwcP5",
  "id" : 927514059368525824,
  "created_at" : "2017-11-06 12:32:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Mvd7gYheg3",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808978437&oldid=808978109",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927501657512075264",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Mvd7gYheg3",
  "id" : 927501657512075264,
  "created_at" : "2017-11-06 11:43:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/uT1pkv5tJu",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808978109&oldid=808977036",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927500801504890880",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uT1pkv5tJu",
  "id" : 927500801504890880,
  "created_at" : "2017-11-06 11:39:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/WL2sHS1KsI",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808977036&oldid=808976544",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927497973952647169",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WL2sHS1KsI",
  "id" : 927497973952647169,
  "created_at" : "2017-11-06 11:28:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/IxvEjFT3Px",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808976544&oldid=808976283",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927496580680372226",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IxvEjFT3Px",
  "id" : 927496580680372226,
  "created_at" : "2017-11-06 11:23:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1WwWDJR5hV",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808976283&oldid=808976259",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927495759741759489",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1WwWDJR5hV",
  "id" : 927495759741759489,
  "created_at" : "2017-11-06 11:19:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/z1f7LvBE1Z",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808976259&oldid=808975969",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927495665533554688",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/z1f7LvBE1Z",
  "id" : 927495665533554688,
  "created_at" : "2017-11-06 11:19:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/3Db30m4BBs",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808975969&oldid=808975931",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927494804946259968",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3Db30m4BBs",
  "id" : 927494804946259968,
  "created_at" : "2017-11-06 11:16:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/eb3Hk8mKFh",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808975931&oldid=808975422",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927494682116009985",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eb3Hk8mKFh",
  "id" : 927494682116009985,
  "created_at" : "2017-11-06 11:15:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/469pjbNcrw",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808975422&oldid=780870042",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927493252202352640",
  "text" : "Alguien desde CSIC ha editado 'Ptyodactylus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/469pjbNcrw",
  "id" : 927493252202352640,
  "created_at" : "2017-11-06 11:09:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/92yNG8ApKt",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=588444380&oldid=322496068&rcid=623781708",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926543500790910977",
  "text" : "Alguien desde RedIRIS ha editado 'Q18543530' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/92yNG8ApKt",
  "id" : 926543500790910977,
  "created_at" : "2017-11-03 20:15:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/PkC9Q35nsp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103115164&oldid=101530664",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926426609267171328",
  "text" : "Alguien desde RedIRIS ha editado 'Ns (simulador)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PkC9Q35nsp",
  "id" : 926426609267171328,
  "created_at" : "2017-11-03 12:31:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/daLhXhLtXq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103093591&oldid=103093494",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926093807476764672",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/daLhXhLtXq",
  "id" : 926093807476764672,
  "created_at" : "2017-11-02 14:29:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/KIHVK0B3qr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103093494&oldid=103091458",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926092604835614721",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KIHVK0B3qr",
  "id" : 926092604835614721,
  "created_at" : "2017-11-02 14:24:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/gw7flVEXak",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103091458&oldid=103091416",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926059623580303360",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gw7flVEXak",
  "id" : 926059623580303360,
  "created_at" : "2017-11-02 12:13:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/aa0h774vFJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103091416&oldid=103088367",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926059095030992896",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aa0h774vFJ",
  "id" : 926059095030992896,
  "created_at" : "2017-11-02 12:11:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/xZbokwmcp4",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=808344982&oldid=807642825",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926016817222602752",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xZbokwmcp4",
  "id" : 926016817222602752,
  "created_at" : "2017-11-02 09:23:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/KVfigAVxCX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088367&oldid=103088339",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926003999597359104",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KVfigAVxCX",
  "id" : 926003999597359104,
  "created_at" : "2017-11-02 08:32:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/O1FKlg9Qyd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088339&oldid=103088324",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926003308363501569",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/O1FKlg9Qyd",
  "id" : 926003308363501569,
  "created_at" : "2017-11-02 08:29:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/AbqVvZ2Owa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088324&oldid=103088299",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926002945971380229",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AbqVvZ2Owa",
  "id" : 926002945971380229,
  "created_at" : "2017-11-02 08:28:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/cKDYkiBkd8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088299&oldid=103088282",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926002258369744896",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cKDYkiBkd8",
  "id" : 926002258369744896,
  "created_at" : "2017-11-02 08:25:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/27LYLiYylJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088282&oldid=103088274",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926001936779923456",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/27LYLiYylJ",
  "id" : 926001936779923456,
  "created_at" : "2017-11-02 08:24:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/XvvTtSS3ux",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088274&oldid=103088258",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926001739291127808",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XvvTtSS3ux",
  "id" : 926001739291127808,
  "created_at" : "2017-11-02 08:23:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/MfDLGFIWtl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088258&oldid=103088241",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926001235366465536",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MfDLGFIWtl",
  "id" : 926001235366465536,
  "created_at" : "2017-11-02 08:21:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Dw8gzabrO8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103088241&oldid=103009622",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926000868540977152",
  "text" : "Alguien desde RedIRIS ha editado 'Mar\u00EDa Segu\u00ED' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Dw8gzabrO8",
  "id" : 926000868540977152,
  "created_at" : "2017-11-02 08:19:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]