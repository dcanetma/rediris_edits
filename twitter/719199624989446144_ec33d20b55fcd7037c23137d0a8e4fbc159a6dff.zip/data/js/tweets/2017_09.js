Grailbird.data.tweets_2017_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/WdKYtZDnNK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102225317&oldid=101712584",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913705377774161920",
  "text" : "Alguien desde RedIRIS ha editado 'Al Gore' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WdKYtZDnNK",
  "id" : 913705377774161920,
  "created_at" : "2017-09-29 10:01:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/86LSsS5Gfa",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18863573&oldid=18497344&rcid=65581884",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913407807378132992",
  "text" : "Alguien desde RedIRIS ha editado 'Institut d&amp;#39;Investigaci\u00F3 Biom\u00E8dica de Bellvitge' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/86LSsS5Gfa",
  "id" : 913407807378132992,
  "created_at" : "2017-09-28 14:19:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/f7cAjaqUDU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102205625&oldid=99709406",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913407136914444288",
  "text" : "Alguien desde RedIRIS ha editado 'IDIBELL' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/f7cAjaqUDU",
  "id" : 913407136914444288,
  "created_at" : "2017-09-28 14:16:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/YWigDP25mB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102201447&oldid=102201436",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913333254064918528",
  "text" : "Alguien desde RedIRIS ha editado 'Diagrama de cuerpo libre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YWigDP25mB",
  "id" : 913333254064918528,
  "created_at" : "2017-09-28 09:23:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ZklXsNzloT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102201436&oldid=102201417",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913332989878243329",
  "text" : "Alguien desde RedIRIS ha editado 'Diagrama de cuerpo libre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZklXsNzloT",
  "id" : 913332989878243329,
  "created_at" : "2017-09-28 09:22:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/K5jfY0H7y4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102201417&oldid=101434112",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913332777625538560",
  "text" : "Alguien desde RedIRIS ha editado 'Diagrama de cuerpo libre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/K5jfY0H7y4",
  "id" : 913332777625538560,
  "created_at" : "2017-09-28 09:21:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/LYQBy5uXMr",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=802612374&oldid=753229006",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "912964369624989696",
  "text" : "Alguien desde CSIC ha editado 'Manuel Tu\u00F1\u00F3n de Lara' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LYQBy5uXMr",
  "id" : 912964369624989696,
  "created_at" : "2017-09-27 08:57:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/oV5eADCxjd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102157767&oldid=100005242",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "912650225260662786",
  "text" : "Alguien desde CSIC ha editado 'Nervi\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oV5eADCxjd",
  "id" : 912650225260662786,
  "created_at" : "2017-09-26 12:09:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ZLEt423nLO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102133342&oldid=101959193",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "912282037679161345",
  "text" : "Alguien desde RedIRIS ha editado 'Tratado de Versalles (1919)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZLEt423nLO",
  "id" : 912282037679161345,
  "created_at" : "2017-09-25 11:46:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ACA08oJzSg",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=565638877&oldid=561394445&rcid=600424685",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "912236277944258561",
  "text" : "Alguien desde RedIRIS ha editado 'Q16230236' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ACA08oJzSg",
  "id" : 912236277944258561,
  "created_at" : "2017-09-25 08:44:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/pgGT8z5lF8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102065765&oldid=102065724",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "911116191523065856",
  "text" : "Alguien desde RedIRIS ha editado 'Poliedro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pgGT8z5lF8",
  "id" : 911116191523065856,
  "created_at" : "2017-09-22 06:33:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/i84t8xAcip",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102065717&oldid=102030858",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "911114584999723008",
  "text" : "Alguien desde RedIRIS ha editado 'Poliedro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/i84t8xAcip",
  "id" : 911114584999723008,
  "created_at" : "2017-09-22 06:26:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/SUrWEcgOAx",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=801708343&oldid=800081648",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910810559951654912",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SUrWEcgOAx",
  "id" : 910810559951654912,
  "created_at" : "2017-09-21 10:18:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/WJ28RXSzgw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102045602&oldid=101882330",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910789305823645697",
  "text" : "Alguien desde RedIRIS ha editado 'Nuevo Testamento' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WJ28RXSzgw",
  "id" : 910789305823645697,
  "created_at" : "2017-09-21 08:54:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/gP5Fs0cDz6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101976267&oldid=101950757",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909739781176913920",
  "text" : "Alguien desde RedIRIS ha editado 'Club Atl\u00E9tico de Madrid' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gP5Fs0cDz6",
  "id" : 909739781176913920,
  "created_at" : "2017-09-18 11:24:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/NR9iRxFAqD",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=559374524&oldid=556152889&rcid=593833466",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908634999615827968",
  "text" : "Alguien desde CSIC ha editado 'Q2581521' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NR9iRxFAqD",
  "id" : 908634999615827968,
  "created_at" : "2017-09-15 10:14:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/u3rvqXm2cp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101883009&oldid=101882935",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908331909394124800",
  "text" : "Alguien desde RedIRIS ha editado 'Ciencia ficci\u00F3n peruana' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/u3rvqXm2cp",
  "id" : 908331909394124800,
  "created_at" : "2017-09-14 14:09:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/o2v9rmevMD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101882935&oldid=99989775",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908331115265630208",
  "text" : "Alguien desde RedIRIS ha editado 'Ciencia ficci\u00F3n peruana' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/o2v9rmevMD",
  "id" : 908331115265630208,
  "created_at" : "2017-09-14 14:06:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/qcdkRKwQOh",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=800589601&oldid=800588613",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908324622667579392",
  "text" : "Alguien desde RedIRIS ha editado 'Integrated Truss Structure' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qcdkRKwQOh",
  "id" : 908324622667579392,
  "created_at" : "2017-09-14 13:40:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/oo3mJ1wgos",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=800588613&oldid=798323734",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908322688376209408",
  "text" : "Alguien desde RedIRIS ha editado 'Integrated Truss Structure' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oo3mJ1wgos",
  "id" : 908322688376209408,
  "created_at" : "2017-09-14 13:32:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Z4kprrFfCE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101881882&oldid=101738597",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908318263066730496",
  "text" : "Alguien desde RedIRIS ha editado 'Nuevo Testamento' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Z4kprrFfCE",
  "id" : 908318263066730496,
  "created_at" : "2017-09-14 13:15:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/dFmbr0If7M",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101879830&oldid=101879823",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908286008927678464",
  "text" : "Alguien desde RedIRIS ha editado 'Historia de Mozambique' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dFmbr0If7M",
  "id" : 908286008927678464,
  "created_at" : "2017-09-14 11:07:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/wOMwX75s3k",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101879790&oldid=98213793",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908285444067962880",
  "text" : "Alguien desde RedIRIS ha editado 'Historia de Mozambique' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wOMwX75s3k",
  "id" : 908285444067962880,
  "created_at" : "2017-09-14 11:04:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/1bdzN4oLgP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101858931&oldid=101704125",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908006045250981888",
  "text" : "Alguien desde RedIRIS ha editado '\u00C1rea 51' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1bdzN4oLgP",
  "id" : 908006045250981888,
  "created_at" : "2017-09-13 16:34:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/4cmMnkjzzL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101856883&oldid=101803519",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907981834566455297",
  "text" : "Alguien desde CSIC ha editado 'Castell\u00F3n de la Plana' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4cmMnkjzzL",
  "id" : 907981834566455297,
  "created_at" : "2017-09-13 14:58:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/mq9ExLlZsO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101851968&oldid=101838993",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907904612237275136",
  "text" : "Alguien desde RedIRIS ha editado 'Wikipedia en espa\u00F1ol' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mq9ExLlZsO",
  "id" : 907904612237275136,
  "created_at" : "2017-09-13 09:51:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/rNkcjMKyYH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101851919&oldid=98306010",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907903350271868928",
  "text" : "Alguien desde RedIRIS ha editado 'Colegio Mayor Alcal\u00E1' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rNkcjMKyYH",
  "id" : 907903350271868928,
  "created_at" : "2017-09-13 09:46:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/S8cNjBRJUJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101851345&oldid=101567067",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907889856596062209",
  "text" : "Alguien desde RedIRIS ha editado 'Katheryn Winnick' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/S8cNjBRJUJ",
  "id" : 907889856596062209,
  "created_at" : "2017-09-13 08:53:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ncoQX4y9Pz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101850805&oldid=101293579",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907879592073089024",
  "text" : "Alguien desde CSIC ha editado 'Botaya' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ncoQX4y9Pz",
  "id" : 907879592073089024,
  "created_at" : "2017-09-13 08:12:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/B5VQ6tEFd5",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=800075480&oldid=800075136",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907200271478136832",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/B5VQ6tEFd5",
  "id" : 907200271478136832,
  "created_at" : "2017-09-11 11:12:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/oIoztXHgG8",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=800075136&oldid=800075063",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907199445690929152",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oIoztXHgG8",
  "id" : 907199445690929152,
  "created_at" : "2017-09-11 11:09:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/D1gQOoAawM",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=800075063&oldid=799237911",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907199270989770752",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/D1gQOoAawM",
  "id" : 907199270989770752,
  "created_at" : "2017-09-11 11:08:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/mJQBKE0lnf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101734181&oldid=101667449",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906196309765443584",
  "text" : "Alguien desde RedIRIS ha editado 'Notaci\u00F3n matem\u00E1tica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mJQBKE0lnf",
  "id" : 906196309765443584,
  "created_at" : "2017-09-08 16:43:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/VGVxAuLkRe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101676310&oldid=100848610",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "905357235664166912",
  "text" : "Alguien desde RedIRIS ha editado 'Mary Wollstonecraft' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VGVxAuLkRe",
  "id" : 905357235664166912,
  "created_at" : "2017-09-06 09:09:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/LMtZCP5Dlw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101676304&oldid=101675824",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "905357167317983232",
  "text" : "Alguien desde RedIRIS ha editado 'El incidente (serie de televisi\u00F3n)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LMtZCP5Dlw",
  "id" : 905357167317983232,
  "created_at" : "2017-09-06 09:09:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/qrzt28EPjL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101650740&oldid=101324525",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "905016970965344259",
  "text" : "Alguien desde RedIRIS ha editado 'Manzana Postob\u00F3n Team' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qrzt28EPjL",
  "id" : 905016970965344259,
  "created_at" : "2017-09-05 10:37:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/FF1OizXlZX",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=552091178&oldid=552091070&rcid=586226262",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904975700796559360",
  "text" : "Alguien desde RedIRIS ha editado 'Q11913494' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FF1OizXlZX",
  "id" : 904975700796559360,
  "created_at" : "2017-09-05 07:53:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/2clH9pz0uE",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=552091070&oldid=552091065&rcid=586226154",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904975637294833664",
  "text" : "Alguien desde RedIRIS ha editado 'Q11913494' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2clH9pz0uE",
  "id" : 904975637294833664,
  "created_at" : "2017-09-05 07:53:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ZGjzzSLM32",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=552091061&oldid=552090896&rcid=586226145",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904975633318633472",
  "text" : "Alguien desde RedIRIS ha editado 'Q11913494' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZGjzzSLM32",
  "id" : 904975633318633472,
  "created_at" : "2017-09-05 07:52:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Fn4s3BHTIJ",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=552091065&oldid=552091061&rcid=586226150",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904975635843559425",
  "text" : "Alguien desde RedIRIS ha editado 'Q11913494' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Fn4s3BHTIJ",
  "id" : 904975635843559425,
  "created_at" : "2017-09-05 07:52:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Uk3coUTs0Z",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=552090896&oldid=552090329&rcid=586225929",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904975521448161280",
  "text" : "Alguien desde RedIRIS ha editado 'Q11913494' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Uk3coUTs0Z",
  "id" : 904975521448161280,
  "created_at" : "2017-09-05 07:52:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/MELhlJ36IA",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=552090329&oldid=466037554&rcid=586225362",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904975271710875648",
  "text" : "Alguien desde RedIRIS ha editado 'Q11913494' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MELhlJ36IA",
  "id" : 904975271710875648,
  "created_at" : "2017-09-05 07:51:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1RQYR5XJsG",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18796073&oldid=18142849&rcid=62411950",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904974556959576064",
  "text" : "Alguien desde RedIRIS ha editado 'Centre de Medicina Regenerativa de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1RQYR5XJsG",
  "id" : 904974556959576064,
  "created_at" : "2017-09-05 07:48:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Dja3pexkkT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101649485&oldid=101649483",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904974092176121858",
  "text" : "Alguien desde RedIRIS ha editado 'Centro de Medicina Regenerativa de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Dja3pexkkT",
  "id" : 904974092176121858,
  "created_at" : "2017-09-05 07:46:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/bpTeujPu8n",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101649483&oldid=101649477",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904974025948098560",
  "text" : "Alguien desde RedIRIS ha editado 'Centro de Medicina Regenerativa de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bpTeujPu8n",
  "id" : 904974025948098560,
  "created_at" : "2017-09-05 07:46:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/IFFVG0vc80",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101649477&oldid=97410335",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904973956385529856",
  "text" : "Alguien desde RedIRIS ha editado 'Centro de Medicina Regenerativa de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IFFVG0vc80",
  "id" : 904973956385529856,
  "created_at" : "2017-09-05 07:46:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/iXgFcjqehb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101628142&oldid=101476522",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904665741261201408",
  "text" : "Alguien desde CSIC ha editado 'Flat Earth Society' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iXgFcjqehb",
  "id" : 904665741261201408,
  "created_at" : "2017-09-04 11:21:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uYYXLKS3T3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101627251&oldid=101607888",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904642102499442690",
  "text" : "Alguien desde RedIRIS ha editado 'Usuario discusi\u00F3n:Mar del Sur' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uYYXLKS3T3",
  "id" : 904642102499442690,
  "created_at" : "2017-09-04 09:47:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/kwi71np7mg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101627210&oldid=101563886",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904640173568385024",
  "text" : "Alguien desde RedIRIS ha editado 'Anna Maria Travaset' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kwi71np7mg",
  "id" : 904640173568385024,
  "created_at" : "2017-09-04 09:39:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/eeRBcVzBps",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101562954&oldid=101562941",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903539706184552448",
  "text" : "Alguien desde RedIRIS ha editado 'Retamosa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eeRBcVzBps",
  "id" : 903539706184552448,
  "created_at" : "2017-09-01 08:47:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/496F03O3c7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101562941&oldid=99045349",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903539346384572416",
  "text" : "Alguien desde RedIRIS ha editado 'Retamosa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/496F03O3c7",
  "id" : 903539346384572416,
  "created_at" : "2017-09-01 08:45:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]