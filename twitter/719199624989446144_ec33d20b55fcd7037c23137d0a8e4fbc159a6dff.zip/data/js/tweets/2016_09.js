Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1aXrTZdH18",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=741928844&oldid=714456315",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781877276870844416",
  "text" : "Alguien desde RedIRIS ha editado 'Universidad P\u00FAblica de Navarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1aXrTZdH18",
  "id" : 781877276870844416,
  "created_at" : "2016-09-30 15:24:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/GoRhUiwGCQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93979270&oldid=93979244",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781416120746115072",
  "text" : "Alguien desde RedIRIS ha editado 'Universidad P\u00FAblica de Navarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GoRhUiwGCQ",
  "id" : 781416120746115072,
  "created_at" : "2016-09-29 08:51:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/qmVH4WW15H",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93979244&oldid=93956707",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781415162049925120",
  "text" : "Alguien desde RedIRIS ha editado 'Universidad P\u00FAblica de Navarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qmVH4WW15H",
  "id" : 781415162049925120,
  "created_at" : "2016-09-29 08:47:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ieS9iFrYtE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93979070&oldid=93735159",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781408278601498624",
  "text" : "Alguien desde RedIRIS ha editado 'Chun Doo-hwan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ieS9iFrYtE",
  "id" : 781408278601498624,
  "created_at" : "2016-09-29 08:20:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/0rs5Mrnz75",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93959576&oldid=93558704",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781100895199195136",
  "text" : "Alguien desde RedIRIS ha editado 'Z1' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0rs5Mrnz75",
  "id" : 781100895199195136,
  "created_at" : "2016-09-28 11:59:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/lWFaayQtvD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93957617&oldid=92050633",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781055386333876225",
  "text" : "Alguien desde RedIRIS ha editado 'Defensa siciliana' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lWFaayQtvD",
  "id" : 781055386333876225,
  "created_at" : "2016-09-28 08:58:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/CNHXTg2pJS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93957434&oldid=93956485",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781051187906969618",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CNHXTg2pJS",
  "id" : 781051187906969618,
  "created_at" : "2016-09-28 08:41:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/eueHu1QfCj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93956485&oldid=93956469",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781022658666332162",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eueHu1QfCj",
  "id" : 781022658666332162,
  "created_at" : "2016-09-28 06:48:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/31RilyzfUn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93956469&oldid=93935721",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781022276741369856",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/31RilyzfUn",
  "id" : 781022276741369856,
  "created_at" : "2016-09-28 06:46:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ydJELAvfTq",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=741458293&oldid=741458133",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780810960164585472",
  "text" : "Alguien desde RedIRIS ha editado 'Oreste Piro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ydJELAvfTq",
  "id" : 780810960164585472,
  "created_at" : "2016-09-27 16:46:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/P0B0SJkTOX",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=741458133&oldid=720567768",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780810697991196672",
  "text" : "Alguien desde RedIRIS ha editado 'Oreste Piro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/P0B0SJkTOX",
  "id" : 780810697991196672,
  "created_at" : "2016-09-27 16:45:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/SIHh2DjzAt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93940934&oldid=93784099",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780794264657731584",
  "text" : "Alguien desde RedIRIS ha editado 'Gobierno Representativo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SIHh2DjzAt",
  "id" : 780794264657731584,
  "created_at" : "2016-09-27 15:40:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/laCx21C004",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93940088&oldid=93940073",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780783608340549632",
  "text" : "Alguien desde RedIRIS ha editado 'Phaseolus vulgaris' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/laCx21C004",
  "id" : 780783608340549632,
  "created_at" : "2016-09-27 14:58:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/hsVNNvfO9I",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93940073&oldid=93788519",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780783383773339648",
  "text" : "Alguien desde RedIRIS ha editado 'Phaseolus vulgaris' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hsVNNvfO9I",
  "id" : 780783383773339648,
  "created_at" : "2016-09-27 14:57:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Wd11UIPTyQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93935721&oldid=93935717",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780700317868589056",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Wd11UIPTyQ",
  "id" : 780700317868589056,
  "created_at" : "2016-09-27 09:27:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/aIBGT4mAcB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93935717&oldid=93935713",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780700226063572992",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aIBGT4mAcB",
  "id" : 780700226063572992,
  "created_at" : "2016-09-27 09:26:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/zPXeyZkISt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93935713&oldid=93935695",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780700153867018240",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zPXeyZkISt",
  "id" : 780700153867018240,
  "created_at" : "2016-09-27 09:26:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/0myfrLqOgg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93935695&oldid=93935665",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780699799439962112",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0myfrLqOgg",
  "id" : 780699799439962112,
  "created_at" : "2016-09-27 09:25:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/yA4w1ltmaN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93935665&oldid=93935664",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780699213558607872",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/yA4w1ltmaN",
  "id" : 780699213558607872,
  "created_at" : "2016-09-27 09:22:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Z3y0GgkzAU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93935664&oldid=93935655",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780699192306073600",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Z3y0GgkzAU",
  "id" : 780699192306073600,
  "created_at" : "2016-09-27 09:22:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Mzwosn44o8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93935655&oldid=91650108",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780698930371760128",
  "text" : "Alguien desde RedIRIS ha editado 'Escuela T\u00E9cnica Superior de Ingenier\u00EDa (ICAI)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Mzwosn44o8",
  "id" : 780698930371760128,
  "created_at" : "2016-09-27 09:21:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/AIyPkOSvcC",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=741243597&oldid=720123227",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780320275917336576",
  "text" : "Alguien desde RedIRIS ha editado 'Consejo Superior de Deportes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AIyPkOSvcC",
  "id" : 780320275917336576,
  "created_at" : "2016-09-26 08:17:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/FjWbH9tcjf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93911518&oldid=93911517",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780305315619282944",
  "text" : "Alguien desde RedIRIS ha editado 'Miguel Costa y Llobera' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FjWbH9tcjf",
  "id" : 780305315619282944,
  "created_at" : "2016-09-26 07:17:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/qpup1vNdTk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93911517&oldid=91213862",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780305166985732096",
  "text" : "Alguien desde RedIRIS ha editado 'Miguel Costa y Llobera' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qpup1vNdTk",
  "id" : 780305166985732096,
  "created_at" : "2016-09-26 07:17:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Wz6xQVi3bS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93911448&oldid=93154535",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780302558732677120",
  "text" : "Alguien desde RedIRIS ha editado 'Elizondo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Wz6xQVi3bS",
  "id" : 780302558732677120,
  "created_at" : "2016-09-26 07:06:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/A3aJVIMrFE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93854254&oldid=93055515",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779317513725378560",
  "text" : "Alguien desde RedIRIS ha editado 'Castej\u00F3n (Navarra)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A3aJVIMrFE",
  "id" : 779317513725378560,
  "created_at" : "2016-09-23 13:52:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/GNo3r7L12Q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93806488&oldid=93806475",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778531976651431936",
  "text" : "Alguien desde RedIRIS ha editado 'Ley de los rendimientos decrecientes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GNo3r7L12Q",
  "id" : 778531976651431936,
  "created_at" : "2016-09-21 09:51:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/bT096MWwcm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93806475&oldid=93806471",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778531603509309440",
  "text" : "Alguien desde RedIRIS ha editado 'Ley de los rendimientos decrecientes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bT096MWwcm",
  "id" : 778531603509309440,
  "created_at" : "2016-09-21 09:49:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/IYlaRN7qqx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93806471&oldid=93468005",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778531487968813057",
  "text" : "Alguien desde RedIRIS ha editado 'Ley de los rendimientos decrecientes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IYlaRN7qqx",
  "id" : 778531487968813057,
  "created_at" : "2016-09-21 09:49:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/xCennFicOb",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=740143478&oldid=707495176",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777797926512918528",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco (writer)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xCennFicOb",
  "id" : 777797926512918528,
  "created_at" : "2016-09-19 09:14:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/02ps4Ezg0g",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93750992&oldid=91606398",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777795729461022720",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/02ps4Ezg0g",
  "id" : 777795729461022720,
  "created_at" : "2016-09-19 09:05:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/vi7f7CLlLt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93578675&oldid=93366711",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775655341161938945",
  "text" : "Alguien desde CSIC ha editado 'Vallecas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vi7f7CLlLt",
  "id" : 775655341161938945,
  "created_at" : "2016-09-13 11:20:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/oh6JPKwooA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93577793&oldid=93432354",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775633005087948800",
  "text" : "Alguien desde RedIRIS ha editado 'Tordesillas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oh6JPKwooA",
  "id" : 775633005087948800,
  "created_at" : "2016-09-13 09:51:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/VXFKNnu3Ai",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93576152&oldid=93457892",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775587991536431104",
  "text" : "Alguien desde RedIRIS ha editado 'Cristo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VXFKNnu3Ai",
  "id" : 775587991536431104,
  "created_at" : "2016-09-13 06:52:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/hKPoiTAnCZ",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5569369&oldid=5564145",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774544637189038080",
  "text" : "Alguien desde RedIRIS ha editado 'Legaria' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hKPoiTAnCZ",
  "id" : 774544637189038080,
  "created_at" : "2016-09-10 09:46:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/umktPT4bPG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93513131&oldid=93233454",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774544077740277760",
  "text" : "Alguien desde RedIRIS ha editado 'Legaria' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/umktPT4bPG",
  "id" : 774544077740277760,
  "created_at" : "2016-09-10 09:44:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/HJBLpv5v9k",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93498926&oldid=93454117",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774269292644892672",
  "text" : "Alguien desde CSIC ha editado 'El Viso del Alcor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HJBLpv5v9k",
  "id" : 774269292644892672,
  "created_at" : "2016-09-09 15:32:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/k4OkLVMR2c",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93473781&oldid=92394025",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773836494255652864",
  "text" : "Alguien desde CSIC ha editado 'Neonicotinoide' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/k4OkLVMR2c",
  "id" : 773836494255652864,
  "created_at" : "2016-09-08 10:52:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/eNoy5wpP43",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93457389&oldid=89691170",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773544351674892288",
  "text" : "Alguien desde CSIC ha editado 'Anexo Discusi\u00F3n:Islas de Espa\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eNoy5wpP43",
  "id" : 773544351674892288,
  "created_at" : "2016-09-07 15:31:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/r4mkiHCfHI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93453356&oldid=93016416",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773461447447834625",
  "text" : "Alguien desde RedIRIS ha editado 'Unidades derivadas del Sistema Internacional' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/r4mkiHCfHI",
  "id" : 773461447447834625,
  "created_at" : "2016-09-07 10:02:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/dOruXFMN1F",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93452259&oldid=93452252",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773426802480087040",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dOruXFMN1F",
  "id" : 773426802480087040,
  "created_at" : "2016-09-07 07:44:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/WRA5RqVl1Z",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93452252&oldid=93439483",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773426643461439489",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WRA5RqVl1Z",
  "id" : 773426643461439489,
  "created_at" : "2016-09-07 07:44:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/xMS2UqyVBS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93437399&oldid=93437294",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773213920412704770",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xMS2UqyVBS",
  "id" : 773213920412704770,
  "created_at" : "2016-09-06 17:38:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/3W8SWe7Sz3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93437294&oldid=93437285",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773212716441927681",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3W8SWe7Sz3",
  "id" : 773212716441927681,
  "created_at" : "2016-09-06 17:34:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/QIMQBxwpju",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93437285&oldid=93437270",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773212598498197505",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QIMQBxwpju",
  "id" : 773212598498197505,
  "created_at" : "2016-09-06 17:33:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/IgT0q2xetJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93437270&oldid=93437135",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773212504667385856",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IgT0q2xetJ",
  "id" : 773212504667385856,
  "created_at" : "2016-09-06 17:33:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/G8evi8dKdq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93437135&oldid=93437095",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773210470471860225",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/G8evi8dKdq",
  "id" : 773210470471860225,
  "created_at" : "2016-09-06 17:25:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/V7miMfTmmP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93437095&oldid=93436686",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773209963904790528",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/V7miMfTmmP",
  "id" : 773209963904790528,
  "created_at" : "2016-09-06 17:23:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/LTI4AKt1rO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=93436694&rcid=130621826",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773203820868427776",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LTI4AKt1rO",
  "id" : 773203820868427776,
  "created_at" : "2016-09-06 16:58:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/6R8dtIzK3J",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93436686&oldid=93306525",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773203667977658369",
  "text" : "Alguien desde CSIC ha editado 'Emilio Alzugaray Goicoechea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6R8dtIzK3J",
  "id" : 773203667977658369,
  "created_at" : "2016-09-06 16:58:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/icRcF0C7Wz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93436125&oldid=93434809",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773194955938488321",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/icRcF0C7Wz",
  "id" : 773194955938488321,
  "created_at" : "2016-09-06 16:23:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/SGuhKXruDa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93435303&oldid=93435275",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773183239485874176",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SGuhKXruDa",
  "id" : 773183239485874176,
  "created_at" : "2016-09-06 15:37:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/W5fUNKvyCZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93435275&oldid=93435255",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773182991938031616",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/W5fUNKvyCZ",
  "id" : 773182991938031616,
  "created_at" : "2016-09-06 15:36:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ClWFcaFKRf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93435255&oldid=93435250",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773182820315492352",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ClWFcaFKRf",
  "id" : 773182820315492352,
  "created_at" : "2016-09-06 15:35:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/HVcB2ua9uv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93435250&oldid=93433501",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773182757396701184",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HVcB2ua9uv",
  "id" : 773182757396701184,
  "created_at" : "2016-09-06 15:35:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/NWDpAOjwOI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93435121&oldid=93434732",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773181024289390593",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NWDpAOjwOI",
  "id" : 773181024289390593,
  "created_at" : "2016-09-06 15:28:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/70pbeaOsP9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434809&oldid=93434753",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773176846716469248",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/70pbeaOsP9",
  "id" : 773176846716469248,
  "created_at" : "2016-09-06 15:11:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/jTqlAEowry",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434753&oldid=93434737",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773176241650278400",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jTqlAEowry",
  "id" : 773176241650278400,
  "created_at" : "2016-09-06 15:09:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/uu4RBjLRFC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434727&oldid=93326751",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773175867862310913",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uu4RBjLRFC",
  "id" : 773175867862310913,
  "created_at" : "2016-09-06 15:07:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/eO7HWEYv7E",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434697&oldid=93434675",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773175492736319489",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eO7HWEYv7E",
  "id" : 773175492736319489,
  "created_at" : "2016-09-06 15:06:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/82V3R5vrV1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434675&oldid=93434659",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773175262745767936",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/82V3R5vrV1",
  "id" : 773175262745767936,
  "created_at" : "2016-09-06 15:05:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/h54aJ1Q2LF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434659&oldid=93431904",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773175037935386624",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/h54aJ1Q2LF",
  "id" : 773175037935386624,
  "created_at" : "2016-09-06 15:04:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/IheYx7n2N4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434464&oldid=93434445",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773172783509536769",
  "text" : "Alguien desde CSIC ha editado 'Joaqu\u00EDn S\u00E1nchez de Toca' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IheYx7n2N4",
  "id" : 773172783509536769,
  "created_at" : "2016-09-06 14:55:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/phsTZ1VDpV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93434445&oldid=92295115",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773172551967203330",
  "text" : "Alguien desde CSIC ha editado 'Joaqu\u00EDn S\u00E1nchez de Toca' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/phsTZ1VDpV",
  "id" : 773172551967203330,
  "created_at" : "2016-09-06 14:54:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/GLTO7QNKUB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93433501&oldid=93433476",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773160513454927872",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GLTO7QNKUB",
  "id" : 773160513454927872,
  "created_at" : "2016-09-06 14:06:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/OQM7umTKBC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93433476&oldid=93433415",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773159993696747520",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OQM7umTKBC",
  "id" : 773159993696747520,
  "created_at" : "2016-09-06 14:04:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/bYuNaMbUUV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93433415&oldid=93433376",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773158798492069889",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bYuNaMbUUV",
  "id" : 773158798492069889,
  "created_at" : "2016-09-06 13:59:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Q2qwBEOB2M",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93433376&oldid=93433074",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773158225369792512",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Q2qwBEOB2M",
  "id" : 773158225369792512,
  "created_at" : "2016-09-06 13:57:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/wky58D63yh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93433074&oldid=93433055",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773153705864683520",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wky58D63yh",
  "id" : 773153705864683520,
  "created_at" : "2016-09-06 13:39:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/c5N3SdLL55",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93433055&oldid=93432955",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773153404680015872",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/c5N3SdLL55",
  "id" : 773153404680015872,
  "created_at" : "2016-09-06 13:38:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/OeGcQirwd8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93432955&oldid=93432352",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773152124767264768",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OeGcQirwd8",
  "id" : 773152124767264768,
  "created_at" : "2016-09-06 13:33:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/nasPBByS4T",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=738023562&oldid=736661128",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773150551395733504",
  "text" : "Alguien desde RedIRIS ha editado 'Age of consent' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/nasPBByS4T",
  "id" : 773150551395733504,
  "created_at" : "2016-09-06 13:27:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/3XA0cFL5Q8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93432352&oldid=93432330",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773139798592716800",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3XA0cFL5Q8",
  "id" : 773139798592716800,
  "created_at" : "2016-09-06 12:44:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/GRaEgy6nlT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93432330&oldid=93432322",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773139372514377728",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GRaEgy6nlT",
  "id" : 773139372514377728,
  "created_at" : "2016-09-06 12:42:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/O04zIxob4I",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93432322&oldid=93414421",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773139200472444932",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/O04zIxob4I",
  "id" : 773139200472444932,
  "created_at" : "2016-09-06 12:42:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/bTpPAaQTHc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93431904&oldid=93431667",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773129197648764928",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bTpPAaQTHc",
  "id" : 773129197648764928,
  "created_at" : "2016-09-06 12:02:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/C5x5XPYOH2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93431677&oldid=91132557",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773124071894708224",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Marina Vega' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/C5x5XPYOH2",
  "id" : 773124071894708224,
  "created_at" : "2016-09-06 11:41:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/1cyQmpTi1K",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93431667&oldid=93431522",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773123797880807424",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1cyQmpTi1K",
  "id" : 773123797880807424,
  "created_at" : "2016-09-06 11:40:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/SsAU6V6DKC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93431522&oldid=93431515",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773120388641554432",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SsAU6V6DKC",
  "id" : 773120388641554432,
  "created_at" : "2016-09-06 11:27:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Rl3UGcoWe7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93431515&oldid=93431488",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773120105353969664",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Rl3UGcoWe7",
  "id" : 773120105353969664,
  "created_at" : "2016-09-06 11:26:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/T4PTxCH7AN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93431482&oldid=93414367",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773119066504630272",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/T4PTxCH7AN",
  "id" : 773119066504630272,
  "created_at" : "2016-09-06 11:22:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/OBBIpes0sg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93412736&oldid=93410512",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772815982356205573",
  "text" : "Alguien desde RedIRIS ha editado 'Jairam Navas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OBBIpes0sg",
  "id" : 772815982356205573,
  "created_at" : "2016-09-05 15:17:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9QgVtmLazA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409357&oldid=93409345",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772755121755262976",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9QgVtmLazA",
  "id" : 772755121755262976,
  "created_at" : "2016-09-05 11:15:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/l6xOTo8aI1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409341&oldid=93409338",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772754793433628672",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/l6xOTo8aI1",
  "id" : 772754793433628672,
  "created_at" : "2016-09-05 11:14:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7MVPaoYDwe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409338&oldid=93409285",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772754720104513536",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7MVPaoYDwe",
  "id" : 772754720104513536,
  "created_at" : "2016-09-05 11:14:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/bFXEyAJN7E",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409313&oldid=73385948",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772754186693906432",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bFXEyAJN7E",
  "id" : 772754186693906432,
  "created_at" : "2016-09-05 11:12:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Ufp2c6Kw8M",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409285&oldid=93409273",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772753395170021376",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ufp2c6Kw8M",
  "id" : 772753395170021376,
  "created_at" : "2016-09-05 11:09:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/tHDqI5MeXa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409273&oldid=93409248",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772752957473431552",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tHDqI5MeXa",
  "id" : 772752957473431552,
  "created_at" : "2016-09-05 11:07:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/PKD1c3KjMf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409248&oldid=93409223",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772752527049777153",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PKD1c3KjMf",
  "id" : 772752527049777153,
  "created_at" : "2016-09-05 11:05:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/wL6ZgMVEYd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409215&oldid=93409177",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772751883224088576",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wL6ZgMVEYd",
  "id" : 772751883224088576,
  "created_at" : "2016-09-05 11:03:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/BYJTpsPhT5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409177&oldid=93409122",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772751140215816192",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BYJTpsPhT5",
  "id" : 772751140215816192,
  "created_at" : "2016-09-05 11:00:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/cpxEdbKywf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409167&oldid=93329574",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772750893561380865",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cpxEdbKywf",
  "id" : 772750893561380865,
  "created_at" : "2016-09-05 10:59:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/fYMaYEHsTF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93409116&oldid=93408661",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772749276363497472",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fYMaYEHsTF",
  "id" : 772749276363497472,
  "created_at" : "2016-09-05 10:52:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/EV25YThseV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93408917&oldid=80014564",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772743394246483968",
  "text" : "Alguien desde CSIC ha editado 'El Mizzian' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EV25YThseV",
  "id" : 772743394246483968,
  "created_at" : "2016-09-05 10:29:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/25mFUjL8Wc",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=373664899&oldid=373664841&rcid=390757672",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772735506178277376",
  "text" : "Alguien desde RedIRIS ha editado 'Q2256' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/25mFUjL8Wc",
  "id" : 772735506178277376,
  "created_at" : "2016-09-05 09:57:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/j2WtGfvayq",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=373664841&oldid=371763335&rcid=390757544",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772735352931057664",
  "text" : "Alguien desde RedIRIS ha editado 'Q2256' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/j2WtGfvayq",
  "id" : 772735352931057664,
  "created_at" : "2016-09-05 09:57:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/vRBFqs3Hpl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93408661&oldid=93337958",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772735085799890944",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vRBFqs3Hpl",
  "id" : 772735085799890944,
  "created_at" : "2016-09-05 09:56:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/LnLRwWjs37",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93347784&oldid=92808646",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771672399519453184",
  "text" : "Alguien desde CSIC ha editado 'James Cook' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LnLRwWjs37",
  "id" : 771672399519453184,
  "created_at" : "2016-09-02 11:33:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/aeHoR0w3aS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93332975&oldid=93326898",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771403059369021440",
  "text" : "Alguien desde CSIC ha editado 'Desastre de Annual' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aeHoR0w3aS",
  "id" : 771403059369021440,
  "created_at" : "2016-09-01 17:43:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/364Zq7FOMa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93332207&oldid=93329311",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771392936244305923",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/364Zq7FOMa",
  "id" : 771392936244305923,
  "created_at" : "2016-09-01 17:03:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/EcwXMjqey7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93329574&oldid=93329243",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771353859855876096",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EcwXMjqey7",
  "id" : 771353859855876096,
  "created_at" : "2016-09-01 14:27:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/L0raJb5cqk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93329311&oldid=93329297",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771349722472804352",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/L0raJb5cqk",
  "id" : 771349722472804352,
  "created_at" : "2016-09-01 14:11:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7WbpMLgDFa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93329297&oldid=93329282",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771349542142902272",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7WbpMLgDFa",
  "id" : 771349542142902272,
  "created_at" : "2016-09-01 14:10:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/XvTVeHr2Dm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93329282&oldid=93326447",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771349261166469120",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XvTVeHr2Dm",
  "id" : 771349261166469120,
  "created_at" : "2016-09-01 14:09:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/bMpECbSjMm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93329243&oldid=93329237",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771348740791738368",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bMpECbSjMm",
  "id" : 771348740791738368,
  "created_at" : "2016-09-01 14:07:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/WLmvnYzJQ9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93329237&oldid=93326880",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771348737314721793",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WLmvnYzJQ9",
  "id" : 771348737314721793,
  "created_at" : "2016-09-01 14:07:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/y5hKsZwwzZ",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=737216075&oldid=737215046",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771315873349046272",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/y5hKsZwwzZ",
  "id" : 771315873349046272,
  "created_at" : "2016-09-01 11:56:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/GEiiKhxlow",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=737215046&oldid=737214806",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771313661562462209",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GEiiKhxlow",
  "id" : 771313661562462209,
  "created_at" : "2016-09-01 11:48:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/FL2kifnmUO",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=737214806&oldid=737214684",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771313107322933248",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FL2kifnmUO",
  "id" : 771313107322933248,
  "created_at" : "2016-09-01 11:45:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/oOTs9r921s",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=737214681&oldid=737212056",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771312794868133888",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oOTs9r921s",
  "id" : 771312794868133888,
  "created_at" : "2016-09-01 11:44:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/M3OJbPktA1",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=737214237&oldid=574111845",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771311694509252612",
  "text" : "Alguien desde CSIC ha editado 'Talk:Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/M3OJbPktA1",
  "id" : 771311694509252612,
  "created_at" : "2016-09-01 11:40:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ruiiteRcDE",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=737212056&oldid=737211440",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771306734518435840",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ruiiteRcDE",
  "id" : 771306734518435840,
  "created_at" : "2016-09-01 11:20:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/FW5OdJjJo3",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=737211440&oldid=733635410",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771305155081834496",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FW5OdJjJo3",
  "id" : 771305155081834496,
  "created_at" : "2016-09-01 11:14:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/mF1aMxGgNE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326898&oldid=92903397",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771301799198330880",
  "text" : "Alguien desde CSIC ha editado 'Desastre de Annual' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mF1aMxGgNE",
  "id" : 771301799198330880,
  "created_at" : "2016-09-01 11:00:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/uZygQHRBko",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326880&oldid=93326779",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771301513591398400",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uZygQHRBko",
  "id" : 771301513591398400,
  "created_at" : "2016-09-01 10:59:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/DGNu2Y0huj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326779&oldid=93326726",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771299670303858689",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DGNu2Y0huj",
  "id" : 771299670303858689,
  "created_at" : "2016-09-01 10:52:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/cpW6oNEpEf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326751&oldid=47338388",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771299165859119109",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cpW6oNEpEf",
  "id" : 771299165859119109,
  "created_at" : "2016-09-01 10:50:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/acDh46cxFQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326726&oldid=93326669",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771298446145884160",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/acDh46cxFQ",
  "id" : 771298446145884160,
  "created_at" : "2016-09-01 10:47:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/dITdeA0gMh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326669&oldid=93326656",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771296906546905088",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dITdeA0gMh",
  "id" : 771296906546905088,
  "created_at" : "2016-09-01 10:41:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/LeqAykasbD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326656&oldid=93326644",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771296648886644736",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LeqAykasbD",
  "id" : 771296648886644736,
  "created_at" : "2016-09-01 10:40:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/W33YIIYQOq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326644&oldid=93326635",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771296326323675136",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/W33YIIYQOq",
  "id" : 771296326323675136,
  "created_at" : "2016-09-01 10:39:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/x2ox3BgVRM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326635&oldid=93326611",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771296139102580736",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/x2ox3BgVRM",
  "id" : 771296139102580736,
  "created_at" : "2016-09-01 10:38:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ycJBzgRHuo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326611&oldid=93326559",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771295480768827392",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ycJBzgRHuo",
  "id" : 771295480768827392,
  "created_at" : "2016-09-01 10:35:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/2Cr7mQZzgH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326559&oldid=93326535",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771294172993163264",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2Cr7mQZzgH",
  "id" : 771294172993163264,
  "created_at" : "2016-09-01 10:30:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Cptk5b77yB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326535&oldid=93326497",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771293340193226756",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Cptk5b77yB",
  "id" : 771293340193226756,
  "created_at" : "2016-09-01 10:27:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/z79SXCP9nd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326497&oldid=93326222",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771291860329500672",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/z79SXCP9nd",
  "id" : 771291860329500672,
  "created_at" : "2016-09-01 10:21:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/iRnWoEUiTA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326447&oldid=93326334",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771290622657519617",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iRnWoEUiTA",
  "id" : 771290622657519617,
  "created_at" : "2016-09-01 10:16:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/erHUvRaZA4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326334&oldid=93326240",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771287286411649024",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/erHUvRaZA4",
  "id" : 771287286411649024,
  "created_at" : "2016-09-01 10:03:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Qps4upoehG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326240&oldid=93325977",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771284858828099586",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Qps4upoehG",
  "id" : 771284858828099586,
  "created_at" : "2016-09-01 09:53:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/QqvNR0E2TH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326222&oldid=93326221",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771284358116302848",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QqvNR0E2TH",
  "id" : 771284358116302848,
  "created_at" : "2016-09-01 09:51:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/VvcrrEVmIg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326221&oldid=93326200",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771284279204671488",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VvcrrEVmIg",
  "id" : 771284279204671488,
  "created_at" : "2016-09-01 09:51:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/K0PNcLVB5u",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93326200&oldid=93325940",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771283749623500800",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/K0PNcLVB5u",
  "id" : 771283749623500800,
  "created_at" : "2016-09-01 09:49:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/4kyO27GNHb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93325977&oldid=93325947",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771278043650326528",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4kyO27GNHb",
  "id" : 771278043650326528,
  "created_at" : "2016-09-01 09:26:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ijhNDoXrrc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93325947&oldid=93325927",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771276950283415553",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ijhNDoXrrc",
  "id" : 771276950283415553,
  "created_at" : "2016-09-01 09:22:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vFQHjs7L7a",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93325940&oldid=93030218",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771276772851810304",
  "text" : "Alguien desde CSIC ha editado 'Manuel Fern\u00E1ndez Silvestre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vFQHjs7L7a",
  "id" : 771276772851810304,
  "created_at" : "2016-09-01 09:21:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/MRScXgL2MG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=93325927&oldid=92295058",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771276364393672704",
  "text" : "Alguien desde CSIC ha editado 'D\u00E1maso Berenguer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MRScXgL2MG",
  "id" : 771276364393672704,
  "created_at" : "2016-09-01 09:19:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]