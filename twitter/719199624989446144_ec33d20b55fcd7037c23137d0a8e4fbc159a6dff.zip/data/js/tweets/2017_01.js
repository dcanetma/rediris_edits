Grailbird.data.tweets_2017_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qA0hVrV0BE",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=762923323&oldid=762923171",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826414251434770432",
  "text" : "Alguien desde RedIRIS ha editado 'Zooey Deschanel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qA0hVrV0BE",
  "id" : 826414251434770432,
  "created_at" : "2017-01-31 12:58:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/2cSHZfAQ4v",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=762923171&oldid=762922873",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826413967773933568",
  "text" : "Alguien desde RedIRIS ha editado 'Zooey Deschanel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2cSHZfAQ4v",
  "id" : 826413967773933568,
  "created_at" : "2017-01-31 12:56:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/NkYibKMo5P",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96572799&oldid=96572789",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826413819077525504",
  "text" : "Alguien desde RedIRIS ha editado 'Zooey Deschanel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NkYibKMo5P",
  "id" : 826413819077525504,
  "created_at" : "2017-01-31 12:56:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/3UUqEYT59W",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96572789&oldid=96199208",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826413521399377921",
  "text" : "Alguien desde RedIRIS ha editado 'Zooey Deschanel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3UUqEYT59W",
  "id" : 826413521399377921,
  "created_at" : "2017-01-31 12:55:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/HYLQMD0yXR",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=762922873&oldid=762165887",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826413217719123969",
  "text" : "Alguien desde RedIRIS ha editado 'Zooey Deschanel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HYLQMD0yXR",
  "id" : 826413217719123969,
  "created_at" : "2017-01-31 12:53:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Tw7xMzo7K0",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96552896&oldid=96552874",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826085627347210240",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Tw7xMzo7K0",
  "id" : 826085627347210240,
  "created_at" : "2017-01-30 15:12:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Nl53lB7zWO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96552874&oldid=96552867",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826085349105483776",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Nl53lB7zWO",
  "id" : 826085349105483776,
  "created_at" : "2017-01-30 15:11:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/dTmxIFNvly",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96552867&oldid=96552836",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826085277164789761",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dTmxIFNvly",
  "id" : 826085277164789761,
  "created_at" : "2017-01-30 15:10:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/JwoZGdoxBy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96552836&oldid=96293083",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826084931566727168",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JwoZGdoxBy",
  "id" : 826084931566727168,
  "created_at" : "2017-01-30 15:09:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/OViy5nFS7Q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96551822&oldid=96551746",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826068069856473089",
  "text" : "Alguien desde RedIRIS ha editado 'Primitiva geom\u00E9trica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OViy5nFS7Q",
  "id" : 826068069856473089,
  "created_at" : "2017-01-30 14:02:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/zdzxDLJ2J5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96551746&oldid=96529149",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826066557260460032",
  "text" : "Alguien desde RedIRIS ha editado 'Primitiva geom\u00E9trica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zdzxDLJ2J5",
  "id" : 826066557260460032,
  "created_at" : "2017-01-30 13:56:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Z9WOP4VaIG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96547572&oldid=96504720",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825969590090027009",
  "text" : "Alguien desde RedIRIS ha editado 'Victoria del Reino Unido' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Z9WOP4VaIG",
  "id" : 825969590090027009,
  "created_at" : "2017-01-30 07:31:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/UpfoW8yybE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96547550&oldid=96064622",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825969152666062848",
  "text" : "Alguien desde RedIRIS ha editado 'Bel\u00E9n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UpfoW8yybE",
  "id" : 825969152666062848,
  "created_at" : "2017-01-30 07:29:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/YizdxU8dUc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96547478&oldid=96370125",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825966771144425473",
  "text" : "Alguien desde RedIRIS ha editado 'Luc\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YizdxU8dUc",
  "id" : 825966771144425473,
  "created_at" : "2017-01-30 07:19:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/IHGZrvunOX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96481519&oldid=96480812",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825015472303259648",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IHGZrvunOX",
  "id" : 825015472303259648,
  "created_at" : "2017-01-27 16:19:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/S1jlEnGrSk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96481153&oldid=96481122",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825011105244254208",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/S1jlEnGrSk",
  "id" : 825011105244254208,
  "created_at" : "2017-01-27 16:02:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/BFtP5lIrl7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96481122&oldid=96480820",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825010745603715072",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BFtP5lIrl7",
  "id" : 825010745603715072,
  "created_at" : "2017-01-27 16:01:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/opEA0GW7pq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96457392&oldid=95006849",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824619764576374785",
  "text" : "Alguien desde RedIRIS ha editado 'Coacervado' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/opEA0GW7pq",
  "id" : 824619764576374785,
  "created_at" : "2017-01-26 14:07:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/rbiTeDy0tZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455414&oldid=96228223",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824583132552822785",
  "text" : "Alguien desde RedIRIS ha editado 'Derecho' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rbiTeDy0tZ",
  "id" : 824583132552822785,
  "created_at" : "2017-01-26 11:41:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/o8amqXOWfk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455322&oldid=96333225",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824581210479493120",
  "text" : "Alguien desde RedIRIS ha editado 'Mallorca' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/o8amqXOWfk",
  "id" : 824581210479493120,
  "created_at" : "2017-01-26 11:34:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ne6FclMNGz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455299&oldid=96429518",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824580614108184578",
  "text" : "Alguien desde RedIRIS ha editado 'Pa\u00EDs Vasco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ne6FclMNGz",
  "id" : 824580614108184578,
  "created_at" : "2017-01-26 11:31:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/3zNyItFyJO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455253&oldid=96455245",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824579452361461764",
  "text" : "Alguien desde RedIRIS ha editado 'Noruega' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3zNyItFyJO",
  "id" : 824579452361461764,
  "created_at" : "2017-01-26 11:27:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/hFt2xT0fwQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455241&oldid=96455188",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824579150254141441",
  "text" : "Alguien desde RedIRIS ha editado 'Wikipedia:Tabl\u00F3n de anuncios de' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hFt2xT0fwQ",
  "id" : 824579150254141441,
  "created_at" : "2017-01-26 11:26:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/jhPeb9FTaU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455236&oldid=96453548",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824578935899955200",
  "text" : "Alguien desde RedIRIS ha editado 'El final del camino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jhPeb9FTaU",
  "id" : 824578935899955200,
  "created_at" : "2017-01-26 11:25:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/pQtu6UMDBQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455180&oldid=96332010",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824577880130781185",
  "text" : "Alguien desde RedIRIS ha editado 'Noruega' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pQtu6UMDBQ",
  "id" : 824577880130781185,
  "created_at" : "2017-01-26 11:21:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/QjDqyluGhq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96455157&oldid=95763132",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824577299970400256",
  "text" : "Alguien desde RedIRIS ha editado 'Algeciras' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QjDqyluGhq",
  "id" : 824577299970400256,
  "created_at" : "2017-01-26 11:18:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/0TYyVmrVV2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96417004&oldid=96367721",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "823906570090246146",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0TYyVmrVV2",
  "id" : 823906570090246146,
  "created_at" : "2017-01-24 14:53:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/56qaWPeUnQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96393100&oldid=96026939",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "823508360582615040",
  "text" : "Alguien desde CSIC ha editado 'Gabriela Morreale' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/56qaWPeUnQ",
  "id" : 823508360582615040,
  "created_at" : "2017-01-23 12:31:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/tV89gymbdP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96391158&oldid=95884177",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "823464358198050817",
  "text" : "Alguien desde RedIRIS ha editado 'Purines' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tV89gymbdP",
  "id" : 823464358198050817,
  "created_at" : "2017-01-23 09:36:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/iIihUv3PFk",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=761128058&oldid=660347537",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "822626664249257984",
  "text" : "Alguien desde CSIC ha editado 'Tunnel worm' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iIihUv3PFk",
  "id" : 822626664249257984,
  "created_at" : "2017-01-21 02:07:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/U8VmgLeanY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96297291&oldid=96297276",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821775436657135616",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/U8VmgLeanY",
  "id" : 821775436657135616,
  "created_at" : "2017-01-18 17:45:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/wDdqkPJNDM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96297276&oldid=96297254",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821775273842638852",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wDdqkPJNDM",
  "id" : 821775273842638852,
  "created_at" : "2017-01-18 17:44:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/NSYLxmI3SY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96297254&oldid=96297224",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821775073740779520",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NSYLxmI3SY",
  "id" : 821775073740779520,
  "created_at" : "2017-01-18 17:43:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/GwaKKdBqpd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96297224&oldid=96297177",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821774697843015682",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GwaKKdBqpd",
  "id" : 821774697843015682,
  "created_at" : "2017-01-18 17:42:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Jh9QsmoEBJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96297177&oldid=96290777",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821774229968453636",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Jh9QsmoEBJ",
  "id" : 821774229968453636,
  "created_at" : "2017-01-18 17:40:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/QJByvXiYTN",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=760705110&oldid=760681821",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821756063783518209",
  "text" : "Alguien desde RedIRIS ha editado 'Oreste Piro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QJByvXiYTN",
  "id" : 821756063783518209,
  "created_at" : "2017-01-18 16:28:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vi4m6ac3la",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96290777&oldid=96290749",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821681737386328064",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vi4m6ac3la",
  "id" : 821681737386328064,
  "created_at" : "2017-01-18 11:32:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/V6VmNSsBA5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96290749&oldid=96290747",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821680774378352640",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/V6VmNSsBA5",
  "id" : 821680774378352640,
  "created_at" : "2017-01-18 11:28:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/M2BeoR64RA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96290747&oldid=96290721",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821680686176305152",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/M2BeoR64RA",
  "id" : 821680686176305152,
  "created_at" : "2017-01-18 11:28:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/YJfMqinhgH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96290721&oldid=96290575",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821679799055872000",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YJfMqinhgH",
  "id" : 821679799055872000,
  "created_at" : "2017-01-18 11:25:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Df6GT3i8Gh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96290575&oldid=96269596",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821675304729112576",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Df6GT3i8Gh",
  "id" : 821675304729112576,
  "created_at" : "2017-01-18 11:07:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/HqQ1msRJjj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96270154&oldid=94839173",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821326398136717313",
  "text" : "Alguien desde RedIRIS ha editado 'Tragacete' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HqQ1msRJjj",
  "id" : 821326398136717313,
  "created_at" : "2017-01-17 12:00:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/s3BSVVVa4R",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96269596&oldid=96269577",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821314231899488259",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/s3BSVVVa4R",
  "id" : 821314231899488259,
  "created_at" : "2017-01-17 11:12:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/YoD4z0l0HN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96269577&oldid=96269574",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821313740725485568",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YoD4z0l0HN",
  "id" : 821313740725485568,
  "created_at" : "2017-01-17 11:10:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/pbTVC000oY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96269574&oldid=96269307",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821313659519569920",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pbTVC000oY",
  "id" : 821313659519569920,
  "created_at" : "2017-01-17 11:10:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Hwt2rSqLuY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96269307&oldid=96248077",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821306714913984512",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Hwt2rSqLuY",
  "id" : 821306714913984512,
  "created_at" : "2017-01-17 10:42:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/OjbD7bR4Qc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96252080&oldid=96128663",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821009917301706756",
  "text" : "Alguien desde RedIRIS ha editado 'Laura Bush' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OjbD7bR4Qc",
  "id" : 821009917301706756,
  "created_at" : "2017-01-16 15:03:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/4z985Dcvi8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96251998&oldid=95808497",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821009005766119424",
  "text" : "Alguien desde RedIRIS ha editado 'Joe Biden' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4z985Dcvi8",
  "id" : 821009005766119424,
  "created_at" : "2017-01-16 14:59:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/JIiMqCJjtq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96250695&oldid=96250598",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "820984790107226112",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Villalba Riquelme' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JIiMqCJjtq",
  "id" : 820984790107226112,
  "created_at" : "2017-01-16 13:23:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/9bl0qDaMMu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96250598&oldid=96192102",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "820982916419387392",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Villalba Riquelme' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9bl0qDaMMu",
  "id" : 820982916419387392,
  "created_at" : "2017-01-16 13:15:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/J77ehtVZ2e",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96248077&oldid=96248075",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "820924742261755904",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/J77ehtVZ2e",
  "id" : 820924742261755904,
  "created_at" : "2017-01-16 09:24:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vlPIRqh8dw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96248075&oldid=96248071",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "820924660309258240",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vlPIRqh8dw",
  "id" : 820924660309258240,
  "created_at" : "2017-01-16 09:24:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Wx3m40gZ3w",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96248071&oldid=96198287",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "820924586715971585",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Wx3m40gZ3w",
  "id" : 820924586715971585,
  "created_at" : "2017-01-16 09:24:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/h0G59zDcsY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96198287&oldid=96195483",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819959815959146497",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/h0G59zDcsY",
  "id" : 819959815959146497,
  "created_at" : "2017-01-13 17:30:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/z9Bpzejl5j",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96195483&oldid=96194675",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819922179609493504",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/z9Bpzejl5j",
  "id" : 819922179609493504,
  "created_at" : "2017-01-13 15:00:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/DMqdsl4tzv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194675&oldid=96194597",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819908726475866113",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DMqdsl4tzv",
  "id" : 819908726475866113,
  "created_at" : "2017-01-13 14:07:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/7DkdaKT2wz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194597&oldid=96194397",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819907179675271168",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7DkdaKT2wz",
  "id" : 819907179675271168,
  "created_at" : "2017-01-13 14:01:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/5CDsmWk0LV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194397&oldid=96194278",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819901111209459712",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5CDsmWk0LV",
  "id" : 819901111209459712,
  "created_at" : "2017-01-13 13:37:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/NGeCC98b4U",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194280&oldid=96194265",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819898407271731200",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NGeCC98b4U",
  "id" : 819898407271731200,
  "created_at" : "2017-01-13 13:26:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Bma7XrBRXk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194278&oldid=96194268",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819898381590036481",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Bma7XrBRXk",
  "id" : 819898381590036481,
  "created_at" : "2017-01-13 13:26:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/mvkKn3a1lj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194268&oldid=96192661",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819898156905365505",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mvkKn3a1lj",
  "id" : 819898156905365505,
  "created_at" : "2017-01-13 13:25:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/SEmEM5KG8G",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194265&oldid=96194234",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819898081290420224",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SEmEM5KG8G",
  "id" : 819898081290420224,
  "created_at" : "2017-01-13 13:25:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/voAG0GWef3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194234&oldid=96194200",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819897441969471488",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/voAG0GWef3",
  "id" : 819897441969471488,
  "created_at" : "2017-01-13 13:22:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/AKwMEEB7tq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194200&oldid=96194171",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819896613187555329",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AKwMEEB7tq",
  "id" : 819896613187555329,
  "created_at" : "2017-01-13 13:19:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/MYVg3hM0pU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96194171&oldid=96136154",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819895848934981633",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MYVg3hM0pU",
  "id" : 819895848934981633,
  "created_at" : "2017-01-13 13:16:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/C1gcEr1pwj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96192661&oldid=96192125",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819865915508588544",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/C1gcEr1pwj",
  "id" : 819865915508588544,
  "created_at" : "2017-01-13 11:17:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/MnjdPZRsys",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96192280&oldid=96192273",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819854404203540480",
  "text" : "Alguien desde RedIRIS ha editado 'Siniestro del transbordador espacial Challenger' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MnjdPZRsys",
  "id" : 819854404203540480,
  "created_at" : "2017-01-13 10:31:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/mibsltLi82",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96192273&oldid=95131104",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819854052603338752",
  "text" : "Alguien desde RedIRIS ha editado 'Siniestro del transbordador espacial Challenger' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mibsltLi82",
  "id" : 819854052603338752,
  "created_at" : "2017-01-13 10:30:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/fglGtHKtfo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96192125&oldid=96192118",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819848539618635777",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fglGtHKtfo",
  "id" : 819848539618635777,
  "created_at" : "2017-01-13 10:08:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/s02581NOxB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96192118&oldid=96191885",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819848342712811520",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/s02581NOxB",
  "id" : 819848342712811520,
  "created_at" : "2017-01-13 10:07:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/BKhn6tLfWB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96192102&oldid=95353956",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819847908858167301",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Villalba Riquelme' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BKhn6tLfWB",
  "id" : 819847908858167301,
  "created_at" : "2017-01-13 10:05:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/mMCIPBRPAu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96191885&oldid=96191876",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819840184225329154",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mMCIPBRPAu",
  "id" : 819840184225329154,
  "created_at" : "2017-01-13 09:35:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Iq6wZX09B0",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96191876&oldid=96191789",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819839809980166144",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Iq6wZX09B0",
  "id" : 819839809980166144,
  "created_at" : "2017-01-13 09:33:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/QymKE1HBth",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96191789&oldid=96132935",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819836860558147586",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QymKE1HBth",
  "id" : 819836860558147586,
  "created_at" : "2017-01-13 09:21:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/2tEVQxg182",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96171053&oldid=95179704",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819496851443425280",
  "text" : "Alguien desde RedIRIS ha editado 'Pilote (cimentaci\u00F3n)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2tEVQxg182",
  "id" : 819496851443425280,
  "created_at" : "2017-01-12 10:50:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/RUnX5qJJuo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96159158&oldid=96159149",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819277052113199104",
  "text" : "Alguien desde RedIRIS ha editado 'John Tyler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RUnX5qJJuo",
  "id" : 819277052113199104,
  "created_at" : "2017-01-11 20:17:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/v4lGhjzG0z",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96159149&oldid=95808450",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819276945024237568",
  "text" : "Alguien desde RedIRIS ha editado 'John Tyler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/v4lGhjzG0z",
  "id" : 819276945024237568,
  "created_at" : "2017-01-11 20:16:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/TREgmTsswd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96159095&oldid=93666800",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819276395784392710",
  "text" : "Alguien desde RedIRIS ha editado 'Henry Clay' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TREgmTsswd",
  "id" : 819276395784392710,
  "created_at" : "2017-01-11 20:14:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/TNqBjeFEI7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96156914&oldid=95718206",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819249181181218817",
  "text" : "Alguien desde RedIRIS ha editado 'Jes\u00FAs Cifuentes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TNqBjeFEI7",
  "id" : 819249181181218817,
  "created_at" : "2017-01-11 18:26:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/xioPjPqMB8",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=759508642&oldid=759507703",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819214875641708544",
  "text" : "Alguien desde RedIRIS ha editado 'Idris Elba' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xioPjPqMB8",
  "id" : 819214875641708544,
  "created_at" : "2017-01-11 16:10:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/VnOXOFozM8",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=759507703&oldid=759504012",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819213326857236482",
  "text" : "Alguien desde RedIRIS ha editado 'Idris Elba' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VnOXOFozM8",
  "id" : 819213326857236482,
  "created_at" : "2017-01-11 16:04:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/qJ92rAbR71",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96152299&oldid=96152066",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819191288268464128",
  "text" : "Alguien desde RedIRIS ha editado 'Wikipedia:Informes de error' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qJ92rAbR71",
  "id" : 819191288268464128,
  "created_at" : "2017-01-11 14:36:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/97RzLkJs0B",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=759348502&oldid=757384290",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818870227656179712",
  "text" : "Alguien desde RedIRIS ha editado 'Oreste Piro' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/97RzLkJs0B",
  "id" : 818870227656179712,
  "created_at" : "2017-01-10 17:20:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/58PfxYqEM3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132935&oldid=96132922",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818866166299029506",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/58PfxYqEM3",
  "id" : 818866166299029506,
  "created_at" : "2017-01-10 17:04:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/g2alsLzcBU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132922&oldid=96132854",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818865861184385024",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/g2alsLzcBU",
  "id" : 818865861184385024,
  "created_at" : "2017-01-10 17:03:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/97zbOyvLh8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132854&oldid=96132838",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818864720459558912",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/97zbOyvLh8",
  "id" : 818864720459558912,
  "created_at" : "2017-01-10 16:58:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ex1nYvzgu3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132838&oldid=96132827",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818864361276108800",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ex1nYvzgu3",
  "id" : 818864361276108800,
  "created_at" : "2017-01-10 16:57:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ywKjNfHk0z",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132827&oldid=96132781",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818864245165199360",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ywKjNfHk0z",
  "id" : 818864245165199360,
  "created_at" : "2017-01-10 16:57:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/DKGKmylfsK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132781&oldid=96132700",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818863529516265472",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DKGKmylfsK",
  "id" : 818863529516265472,
  "created_at" : "2017-01-10 16:54:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/9i1xdUgAhp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132700&oldid=96132580",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818862357304799236",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9i1xdUgAhp",
  "id" : 818862357304799236,
  "created_at" : "2017-01-10 16:49:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/yL4mojUzqQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96132580&oldid=96126599",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818860570678067202",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/yL4mojUzqQ",
  "id" : 818860570678067202,
  "created_at" : "2017-01-10 16:42:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/qC7SBbBFKp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96126599&oldid=96116090",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818747731380465666",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qC7SBbBFKp",
  "id" : 818747731380465666,
  "created_at" : "2017-01-10 09:14:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/y4xootqjU1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96112338&oldid=96112314",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818501120968560641",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/y4xootqjU1",
  "id" : 818501120968560641,
  "created_at" : "2017-01-09 16:54:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/z9gPwdCaJ9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96112314&oldid=96068272",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818500820752891904",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Riquelme y L\u00F3pez-Bago' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/z9gPwdCaJ9",
  "id" : 818500820752891904,
  "created_at" : "2017-01-09 16:52:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/AWNfOtkKsy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96108458&oldid=95279773",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818424346188410881",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AWNfOtkKsy",
  "id" : 818424346188410881,
  "created_at" : "2017-01-09 11:49:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/AKcTHA4Ctd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96107683&oldid=95134941",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818403783042564096",
  "text" : "Alguien desde RedIRIS ha editado 'Zao Wou-Ki' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AKcTHA4Ctd",
  "id" : 818403783042564096,
  "created_at" : "2017-01-09 10:27:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/8yiGux1Ezh",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5699752&oldid=4877868",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816960595111112704",
  "text" : "Alguien desde RedIRIS ha editado 'Patxi Salaberri Zaratiegi' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8yiGux1Ezh",
  "id" : 816960595111112704,
  "created_at" : "2017-01-05 10:52:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/kMcnsLJEsP",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5699749&oldid=5682835",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816960165157146625",
  "text" : "Alguien desde RedIRIS ha editado 'Fontes Linguae Vasconum' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kMcnsLJEsP",
  "id" : 816960165157146625,
  "created_at" : "2017-01-05 10:50:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/SnhMNDSfVP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96026338&oldid=96026289",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816941425074077696",
  "text" : "Alguien desde CSIC ha editado 'Gabriela Morreale' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SnhMNDSfVP",
  "id" : 816941425074077696,
  "created_at" : "2017-01-05 09:36:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/hsoxJ4ZgPZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96026289&oldid=95521917",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816940247900622848",
  "text" : "Alguien desde CSIC ha editado 'Gabriela Morreale' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hsoxJ4ZgPZ",
  "id" : 816940247900622848,
  "created_at" : "2017-01-05 09:31:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xUlI75wFic",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=758258834&oldid=724843482",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816604244174376960",
  "text" : "Alguien desde RedIRIS ha editado 'Dorcadion grande' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xUlI75wFic",
  "id" : 816604244174376960,
  "created_at" : "2017-01-04 11:16:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/aKgFusDvsu",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=758258372&oldid=754483834",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816602987527368704",
  "text" : "Alguien desde RedIRIS ha editado 'Near-threatened species' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aKgFusDvsu",
  "id" : 816602987527368704,
  "created_at" : "2017-01-04 11:11:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/xr6JVM4WGI",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=758258340&oldid=704518319",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816602910247317506",
  "text" : "Alguien desde RedIRIS ha editado 'Near Eastern fire salamander' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xr6JVM4WGI",
  "id" : 816602910247317506,
  "created_at" : "2017-01-04 11:11:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/eHEK39joit",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=758258298&oldid=742634424",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816602777182945280",
  "text" : "Alguien desde RedIRIS ha editado 'Opogona amphichorda' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eHEK39joit",
  "id" : 816602777182945280,
  "created_at" : "2017-01-04 11:10:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/VbDWqBMdFU",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=758258223&oldid=758191058",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816602602951634944",
  "text" : "Alguien desde RedIRIS ha editado 'Tupolev Tu-154' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VbDWqBMdFU",
  "id" : 816602602951634944,
  "created_at" : "2017-01-04 11:10:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/TkwvHxSPzY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95991270&oldid=95778015",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816339552566734849",
  "text" : "Alguien desde RedIRIS ha editado 'Circuito LC' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TkwvHxSPzY",
  "id" : 816339552566734849,
  "created_at" : "2017-01-03 17:44:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]