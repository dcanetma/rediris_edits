Grailbird.data.tweets_2018_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/GAlS4Vrevl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105286621&oldid=104795008",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958682193739448324",
  "text" : "Alguien desde CSIC ha editado 'Club Deportivo Numancia de Soria' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GAlS4Vrevl",
  "id" : 958682193739448324,
  "created_at" : "2018-01-31 12:43:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Pn4YjDnUvK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105285212&oldid=105285177",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958652679668097025",
  "text" : "Alguien desde RedIRIS ha editado 'Dictadura de Francisco Franco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Pn4YjDnUvK",
  "id" : 958652679668097025,
  "created_at" : "2018-01-31 10:46:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/FyGJ7jJ6Gu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105285177&oldid=105285107",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958651298785714176",
  "text" : "Alguien desde RedIRIS ha editado 'Dictadura de Francisco Franco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FyGJ7jJ6Gu",
  "id" : 958651298785714176,
  "created_at" : "2018-01-31 10:40:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/3MPsWPbrg8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105285107&oldid=105285057",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958649529129193472",
  "text" : "Alguien desde RedIRIS ha editado 'Dictadura de Francisco Franco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3MPsWPbrg8",
  "id" : 958649529129193472,
  "created_at" : "2018-01-31 10:33:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/2y8ofM3QNY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105285057&oldid=105284996",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958648251158351872",
  "text" : "Alguien desde RedIRIS ha editado 'Dictadura de Francisco Franco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2y8ofM3QNY",
  "id" : 958648251158351872,
  "created_at" : "2018-01-31 10:28:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/egtZiI6mnk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105284996&oldid=105284913",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958646624829558784",
  "text" : "Alguien desde RedIRIS ha editado 'Dictadura de Francisco Franco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/egtZiI6mnk",
  "id" : 958646624829558784,
  "created_at" : "2018-01-31 10:22:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/KlRoPADwRB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105284913&oldid=103222414",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958644025388601344",
  "text" : "Alguien desde RedIRIS ha editado 'Dictadura de Francisco Franco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KlRoPADwRB",
  "id" : 958644025388601344,
  "created_at" : "2018-01-31 10:12:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/tMhc2ToyhE",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=624761032&oldid=624761028&rcid=660164223",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958331776337940482",
  "text" : "Alguien desde RedIRIS ha editado 'Q1028020' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tMhc2ToyhE",
  "id" : 958331776337940482,
  "created_at" : "2018-01-30 13:31:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/eEoes8LBlJ",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=624761028&oldid=624722862&rcid=660164219",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958331772600750086",
  "text" : "Alguien desde RedIRIS ha editado 'Q1028020' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eEoes8LBlJ",
  "id" : 958331772600750086,
  "created_at" : "2018-01-30 13:31:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/EFAu9jhHbH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105231480&oldid=105231470",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "957957121018093568",
  "text" : "Alguien desde CSIC ha editado 'Sal del Himalaya' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EFAu9jhHbH",
  "id" : 957957121018093568,
  "created_at" : "2018-01-29 12:42:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/IX3ZCO0Pco",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105231470&oldid=104561776",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "957957026323329025",
  "text" : "Alguien desde CSIC ha editado 'Sal del Himalaya' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IX3ZCO0Pco",
  "id" : 957957026323329025,
  "created_at" : "2018-01-29 12:42:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/JqoXFm2Upu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105162764&oldid=104589483",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956826574900297729",
  "text" : "Alguien desde RedIRIS ha editado 'Alexander Mesa Travieso' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JqoXFm2Upu",
  "id" : 956826574900297729,
  "created_at" : "2018-01-26 09:50:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Lc8NcTNBAs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105142170&oldid=105141414",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956504473874157570",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1978' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Lc8NcTNBAs",
  "id" : 956504473874157570,
  "created_at" : "2018-01-25 12:30:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/r6m3Odsncy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105142166&oldid=105142156",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956504370207776768",
  "text" : "Alguien desde RedIRIS ha editado 'Ana Karina Manco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/r6m3Odsncy",
  "id" : 956504370207776768,
  "created_at" : "2018-01-25 12:29:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/j1KzW541Rj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105142156&oldid=104376914",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956504100492972032",
  "text" : "Alguien desde RedIRIS ha editado 'Ana Karina Manco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/j1KzW541Rj",
  "id" : 956504100492972032,
  "created_at" : "2018-01-25 12:28:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/1w4Ipfh0Hz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105141414&oldid=105141409",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956489809010266112",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1978' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1w4Ipfh0Hz",
  "id" : 956489809010266112,
  "created_at" : "2018-01-25 11:31:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/JHrcIFNmYS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105141409&oldid=105141402",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956489738340458497",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1978' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JHrcIFNmYS",
  "id" : 956489738340458497,
  "created_at" : "2018-01-25 11:31:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/UonpRk4r7w",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105141402&oldid=105141397",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956489595289468928",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1978' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UonpRk4r7w",
  "id" : 956489595289468928,
  "created_at" : "2018-01-25 11:31:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/KOmEAluHXF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105141397&oldid=105141389",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956489477689675779",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1978' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KOmEAluHXF",
  "id" : 956489477689675779,
  "created_at" : "2018-01-25 11:30:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/TrFTH85SVV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105141389&oldid=105141272",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956489303361810434",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1978' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TrFTH85SVV",
  "id" : 956489303361810434,
  "created_at" : "2018-01-25 11:29:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/DHP8NUOBYl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105141272&oldid=105124856",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956486949367353344",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1978' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DHP8NUOBYl",
  "id" : 956486949367353344,
  "created_at" : "2018-01-25 11:20:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/WHqMcZhIjJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105139291&oldid=105139273",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956440846215340032",
  "text" : "Alguien desde RedIRIS ha editado 'Carbonato de litio' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WHqMcZhIjJ",
  "id" : 956440846215340032,
  "created_at" : "2018-01-25 08:17:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/gbOLznwW5a",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105139273&oldid=103429551",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956440432879243264",
  "text" : "Alguien desde RedIRIS ha editado 'Carbonato de litio' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gbOLznwW5a",
  "id" : 956440432879243264,
  "created_at" : "2018-01-25 08:15:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Z3dZQFEurw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105116614&oldid=105060499",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956117450508169216",
  "text" : "Alguien desde RedIRIS ha editado 'Construcci\u00F3n del Estado de las autonom\u00EDas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Z3dZQFEurw",
  "id" : 956117450508169216,
  "created_at" : "2018-01-24 10:52:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/Z2Kem4Tf5U",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105116611&oldid=104970144",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956117383105667072",
  "text" : "Alguien desde RedIRIS ha editado 'Estatuto de autonom\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Z2Kem4Tf5U",
  "id" : 956117383105667072,
  "created_at" : "2018-01-24 10:52:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0jaSj48rLR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105116516&oldid=100894449",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956115207608250368",
  "text" : "Alguien desde CSIC ha editado 'Discusi\u00F3n:Cueva de Altamira' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0jaSj48rLR",
  "id" : 956115207608250368,
  "created_at" : "2018-01-24 10:43:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Di6ByuZy7W",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=622750502&oldid=622750463&rcid=658151180",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955758248916869121",
  "text" : "Alguien desde RedIRIS ha editado 'Q6109143' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Di6ByuZy7W",
  "id" : 955758248916869121,
  "created_at" : "2018-01-23 11:04:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/rYiTGQQL7l",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=622750463&oldid=622750417&rcid=658151141",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955758148719169537",
  "text" : "Alguien desde RedIRIS ha editado 'Q6109143' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rYiTGQQL7l",
  "id" : 955758148719169537,
  "created_at" : "2018-01-23 11:04:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/IikJ50zp4Q",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=622750417&oldid=281749934&rcid=658151095",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955758003667570688",
  "text" : "Alguien desde RedIRIS ha editado 'Q6109143' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IikJ50zp4Q",
  "id" : 955758003667570688,
  "created_at" : "2018-01-23 11:03:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Ow9SDP4don",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105076684&oldid=105076673",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955457015396143105",
  "text" : "Alguien desde RedIRIS ha editado 'Estupor y temblores' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ow9SDP4don",
  "id" : 955457015396143105,
  "created_at" : "2018-01-22 15:07:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xizCt1i4Vd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105076673&oldid=105076645",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955456917563899904",
  "text" : "Alguien desde RedIRIS ha editado 'Estupor y temblores' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xizCt1i4Vd",
  "id" : 955456917563899904,
  "created_at" : "2018-01-22 15:07:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/jWs4bafi5F",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105076645&oldid=104212363",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955456537681592320",
  "text" : "Alguien desde RedIRIS ha editado 'Estupor y temblores' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jWs4bafi5F",
  "id" : 955456537681592320,
  "created_at" : "2018-01-22 15:06:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Jr7iTHqZj5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=105053395&oldid=102364150",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955013741275426817",
  "text" : "Alguien desde RedIRIS ha editado 'B\u00FAsqueda en profundidad iterativa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Jr7iTHqZj5",
  "id" : 955013741275426817,
  "created_at" : "2018-01-21 09:46:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/erMx8zMTZr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104999621&oldid=104999586",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "954044919638880256",
  "text" : "Alguien desde RedIRIS ha editado 'Construcci\u00F3n del Estado de las autonom\u00EDas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/erMx8zMTZr",
  "id" : 954044919638880256,
  "created_at" : "2018-01-18 17:36:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/3QDcloAwH2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104999580&oldid=104999437",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "954044473239011328",
  "text" : "Alguien desde RedIRIS ha editado 'Construcci\u00F3n del Estado de las autonom\u00EDas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3QDcloAwH2",
  "id" : 954044473239011328,
  "created_at" : "2018-01-18 17:35:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/9YYwkVHKwn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104999437&oldid=104992311",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "954042968566063104",
  "text" : "Alguien desde RedIRIS ha editado 'Construcci\u00F3n del Estado de las autonom\u00EDas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9YYwkVHKwn",
  "id" : 954042968566063104,
  "created_at" : "2018-01-18 17:29:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/RyDqCEZA9N",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=820782587&oldid=820632728",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "953295758761058304",
  "text" : "Alguien desde RedIRIS ha editado 'List of RWBY characters' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RyDqCEZA9N",
  "id" : 953295758761058304,
  "created_at" : "2018-01-16 15:59:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/r6zVF7DwOT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104944563&oldid=104106454",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "953184897539170304",
  "text" : "Alguien desde RedIRIS ha editado 'OwnCloud' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/r6zVF7DwOT",
  "id" : 953184897539170304,
  "created_at" : "2018-01-16 08:39:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/SYjqRiMVjQ",
      "expanded_url" : "https:\/\/pt.wikipedia.org\/w\/index.php?diff=51025698&oldid=51018018&rcid=80793117",
      "display_url" : "pt.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "952932630667853825",
  "text" : "Alguien desde CSIC ha editado 'A Carrocinha' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SYjqRiMVjQ",
  "id" : 952932630667853825,
  "created_at" : "2018-01-15 15:56:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ZYmOvTpGvt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104859905&oldid=104859889",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951803686921089024",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Destinos tur\u00EDsticos mundiales' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZYmOvTpGvt",
  "id" : 951803686921089024,
  "created_at" : "2018-01-12 13:10:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/TKbGhVmwCD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104859889&oldid=104103183",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951803379331760128",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Destinos tur\u00EDsticos mundiales' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TKbGhVmwCD",
  "id" : 951803379331760128,
  "created_at" : "2018-01-12 13:09:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/MLl80c6NmI",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=819839703&oldid=792398952",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951475751651631104",
  "text" : "Alguien desde CSIC ha editado 'Environmental xenobiotic' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MLl80c6NmI",
  "id" : 951475751651631104,
  "created_at" : "2018-01-11 15:27:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QfuPmZHfUc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104836560&oldid=104820977",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951399210976505857",
  "text" : "Alguien desde CSIC ha editado '2018' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QfuPmZHfUc",
  "id" : 951399210976505857,
  "created_at" : "2018-01-11 10:23:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/PElh0FJNdH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104835434&oldid=104835257",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951371850357059585",
  "text" : "Alguien desde CSIC ha editado 'Anexo:Audiencias de MasterChef Junior (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PElh0FJNdH",
  "id" : 951371850357059585,
  "created_at" : "2018-01-11 08:34:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/xh35hKh706",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=819651019&oldid=813428168",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951111658885320705",
  "text" : "Alguien desde RedIRIS ha editado 'J\u00F8rgen Munkeby' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xh35hKh706",
  "id" : 951111658885320705,
  "created_at" : "2018-01-10 15:21:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/kjrhGN9Iwt",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?oldid=618439678&rcid=653830058",
      "display_url" : "wikidata.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951033842953007104",
  "text" : "Alguien desde CSIC ha editado 'Q47163912' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kjrhGN9Iwt",
  "id" : 951033842953007104,
  "created_at" : "2018-01-10 10:11:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/OMSF9lVPzs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104812586&oldid=103398705",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951033564245757952",
  "text" : "Alguien desde RedIRIS ha editado 'Fernando G\u00F3mez-Bezares' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OMSF9lVPzs",
  "id" : 951033564245757952,
  "created_at" : "2018-01-10 10:10:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/SVTsuSfmT1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104738792&oldid=104311538",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "949841022309294080",
  "text" : "Alguien desde CSIC ha editado 'Torremontalbo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SVTsuSfmT1",
  "id" : 949841022309294080,
  "created_at" : "2018-01-07 03:12:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ZjSNKh6iwK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104698255&oldid=102663258",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "949244501859684353",
  "text" : "Alguien desde CSIC ha editado 'Guillaume Musso' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZjSNKh6iwK",
  "id" : 949244501859684353,
  "created_at" : "2018-01-05 11:41:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ihHnXN8nF5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=104681198&oldid=104633772",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948980669912420352",
  "text" : "Alguien desde RedIRIS ha editado 'An\u00E1lisis de correspondencias m\u00FAltiples' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ihHnXN8nF5",
  "id" : 948980669912420352,
  "created_at" : "2018-01-04 18:13:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/WHs2bRrxsE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=104633567&rcid=179816009",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948225829674340353",
  "text" : "Alguien desde RedIRIS ha editado 'Discusi\u00F3n:Arco conexo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WHs2bRrxsE",
  "id" : 948225829674340353,
  "created_at" : "2018-01-02 16:13:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]