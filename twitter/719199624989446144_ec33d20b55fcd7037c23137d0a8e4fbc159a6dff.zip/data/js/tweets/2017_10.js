Grailbird.data.tweets_2017_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/tK6InS3Au4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103035390&oldid=102669171",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925388185689034752",
  "text" : "Alguien desde RedIRIS ha editado 'Antonio Maestre Hern\u00E1ndez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tK6InS3Au4",
  "id" : 925388185689034752,
  "created_at" : "2017-10-31 15:45:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/m0SJ7B1iCi",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=586753293&oldid=585972814&rcid=622088996",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925311894579286017",
  "text" : "Alguien desde RedIRIS ha editado 'Q884' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/m0SJ7B1iCi",
  "id" : 925311894579286017,
  "created_at" : "2017-10-31 10:42:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ejrHB1LXHn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=103025203&oldid=102755882",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925295346300973056",
  "text" : "Alguien desde CSIC ha editado 'Lactarius deliciosus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ejrHB1LXHn",
  "id" : 925295346300973056,
  "created_at" : "2017-10-31 09:36:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/iOeeyY9MvO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102987076&oldid=102946358",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "924982899472044033",
  "text" : "Alguien desde RedIRIS ha editado 'Club Deportivo Cantolagua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iOeeyY9MvO",
  "id" : 924982899472044033,
  "created_at" : "2017-10-30 12:54:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/dbx1GNs4rr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102908797&oldid=102908613",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923963183160848384",
  "text" : "Alguien desde RedIRIS ha editado 'S&amp;#39;Estanyol (Art\u00E1)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dbx1GNs4rr",
  "id" : 923963183160848384,
  "created_at" : "2017-10-27 17:22:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/V7d1MYGims",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=102908613&rcid=175914384",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923961452377116672",
  "text" : "Alguien desde RedIRIS ha editado 'S&amp;#39;Estanyol (Art\u00E1)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/V7d1MYGims",
  "id" : 923961452377116672,
  "created_at" : "2017-10-27 17:15:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/AuzLN4HKNt",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19072575&oldid=19060319&rcid=72776619",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923919644569808896",
  "text" : "Alguien desde RedIRIS ha editado 'Declaraci\u00F3 unilateral d&amp;#39;independ\u00E8ncia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AuzLN4HKNt",
  "id" : 923919644569808896,
  "created_at" : "2017-10-27 14:29:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/WZkX4cVQEg",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19072552&oldid=19069231&rcid=72776381",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923918334474760193",
  "text" : "Alguien desde RedIRIS ha editado 'Catalunya (desambiguaci\u00F3)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WZkX4cVQEg",
  "id" : 923918334474760193,
  "created_at" : "2017-10-27 14:24:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/OOs7eHZFYb",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=584867171&oldid=528957923&rcid=620191738",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923832539235708928",
  "text" : "Alguien desde RedIRIS ha editado 'Q1647412' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OOs7eHZFYb",
  "id" : 923832539235708928,
  "created_at" : "2017-10-27 08:43:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/AhlSYkXhbx",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19071410&oldid=19071276&rcid=72770347",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923826004635934720",
  "text" : "Alguien desde RedIRIS ha editado 'Milena Busquets' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AhlSYkXhbx",
  "id" : 923826004635934720,
  "created_at" : "2017-10-27 08:17:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/HKyVRTZktQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102854948&oldid=102747466",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923239061262913536",
  "text" : "Alguien desde RedIRIS ha editado 'Coca-Cola' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HKyVRTZktQ",
  "id" : 923239061262913536,
  "created_at" : "2017-10-25 17:25:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/mnqcB8aQHX",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583996055&oldid=583995363&rcid=619319921",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923184503677480962",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mnqcB8aQHX",
  "id" : 923184503677480962,
  "created_at" : "2017-10-25 13:48:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/TfcQXakYxV",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583995363&oldid=583994905&rcid=619319227",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923184090811174913",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TfcQXakYxV",
  "id" : 923184090811174913,
  "created_at" : "2017-10-25 13:46:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/qoJr08zvXv",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583994905&oldid=583994581&rcid=619318768",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923183822535086080",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qoJr08zvXv",
  "id" : 923183822535086080,
  "created_at" : "2017-10-25 13:45:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hdzSWxW4fW",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583994581&oldid=583994354&rcid=619318445",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923183607228829697",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hdzSWxW4fW",
  "id" : 923183607228829697,
  "created_at" : "2017-10-25 13:44:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/KMQY5kYDUp",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583994354&oldid=583994126&rcid=619318218",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923183449363623936",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KMQY5kYDUp",
  "id" : 923183449363623936,
  "created_at" : "2017-10-25 13:44:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/aZWv8vHW8T",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583994126&oldid=583993016&rcid=619317988",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923183301141106688",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aZWv8vHW8T",
  "id" : 923183301141106688,
  "created_at" : "2017-10-25 13:43:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/JPIM5DqgLq",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583993016&oldid=583992383&rcid=619316880",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923182650755559425",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JPIM5DqgLq",
  "id" : 923182650755559425,
  "created_at" : "2017-10-25 13:41:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/zGnogMmeIr",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=583992383&oldid=581011136&rcid=619316244",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923182288615231488",
  "text" : "Alguien desde RedIRIS ha editado 'Q57681' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zGnogMmeIr",
  "id" : 923182288615231488,
  "created_at" : "2017-10-25 13:39:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/E9qHYrq3EG",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=807027316&oldid=805636570",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923172236667781120",
  "text" : "Alguien desde RedIRIS ha editado 'District of Columbia v. Heller' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/E9qHYrq3EG",
  "id" : 923172236667781120,
  "created_at" : "2017-10-25 12:59:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/v59FRgBytH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102844946&oldid=101733611",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923078062174035968",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Blindspot' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/v59FRgBytH",
  "id" : 923078062174035968,
  "created_at" : "2017-10-25 06:45:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/B9RuNVX1zc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102844933&oldid=102782369",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923077661160812544",
  "text" : "Alguien desde RedIRIS ha editado 'Blindspot' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/B9RuNVX1zc",
  "id" : 923077661160812544,
  "created_at" : "2017-10-25 06:43:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/2YLy3x4nGj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102820825&oldid=102531315",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922777315792375808",
  "text" : "Alguien desde RedIRIS ha editado '18 de junio' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2YLy3x4nGj",
  "id" : 922777315792375808,
  "created_at" : "2017-10-24 10:50:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/KP8DCN2GPj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102804403&oldid=101345457",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922526850307559424",
  "text" : "Alguien desde RedIRIS ha editado 'Trak FM Pamplona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KP8DCN2GPj",
  "id" : 922526850307559424,
  "created_at" : "2017-10-23 18:15:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/5A1tSCnTKg",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=19048878&oldid=18990187&rcid=72639092",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922429743890386944",
  "text" : "Alguien desde RedIRIS ha editado 'Escut de Palma' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5A1tSCnTKg",
  "id" : 922429743890386944,
  "created_at" : "2017-10-23 11:49:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/zb2tTnRFx6",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=806646974&oldid=806190576",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922396245070614529",
  "text" : "Alguien desde CSIC ha editado 'Ichthyophonus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zb2tTnRFx6",
  "id" : 922396245070614529,
  "created_at" : "2017-10-23 09:36:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/frcoCc0IC5",
      "expanded_url" : "https:\/\/de.wikipedia.org\/w\/index.php?diff=170247216&oldid=169993844",
      "display_url" : "de.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922381323519643649",
  "text" : "Alguien desde RedIRIS ha editado 'Bipolare St\u00F6rung' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/frcoCc0IC5",
  "id" : 922381323519643649,
  "created_at" : "2017-10-23 08:36:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/a5bZof8UM0",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102792053&oldid=102792046",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922353333729419264",
  "text" : "Alguien desde RedIRIS ha editado 'Euzko Gaztedi Indarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/a5bZof8UM0",
  "id" : 922353333729419264,
  "created_at" : "2017-10-23 06:45:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/uCZDvA3xYH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102792046&oldid=102792040",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922353046604206082",
  "text" : "Alguien desde RedIRIS ha editado 'Euzko Gaztedi Indarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uCZDvA3xYH",
  "id" : 922353046604206082,
  "created_at" : "2017-10-23 06:44:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/CuJUyQS9kT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102792040&oldid=102694234",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922352918350761986",
  "text" : "Alguien desde RedIRIS ha editado 'Euzko Gaztedi Indarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CuJUyQS9kT",
  "id" : 922352918350761986,
  "created_at" : "2017-10-23 06:44:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1BucD2MOJg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102791993&oldid=102587053",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922352074087682048",
  "text" : "Alguien desde RedIRIS ha editado 'Partido Nacionalista Vasco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1BucD2MOJg",
  "id" : 922352074087682048,
  "created_at" : "2017-10-23 06:40:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/qeToi1FdoR",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=806237419&oldid=806236280",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "921425298444439552",
  "text" : "Alguien desde CSIC ha editado 'Proneural genes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qeToi1FdoR",
  "id" : 921425298444439552,
  "created_at" : "2017-10-20 17:18:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/8RtmMouJ8X",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=806236811&oldid=403726106",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "921424072302571521",
  "text" : "Alguien desde CSIC ha editado 'NeuroD' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8RtmMouJ8X",
  "id" : 921424072302571521,
  "created_at" : "2017-10-20 17:13:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ZeEsm18OPC",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=806236280&oldid=797516995",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "921422815148040192",
  "text" : "Alguien desde CSIC ha editado 'Proneural genes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZeEsm18OPC",
  "id" : 921422815148040192,
  "created_at" : "2017-10-20 17:08:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ATeiQnqrlC",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=806189565&oldid=805226265",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "921302732333572096",
  "text" : "Alguien desde RedIRIS ha editado 'James Franco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ATeiQnqrlC",
  "id" : 921302732333572096,
  "created_at" : "2017-10-20 09:11:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/LoYznRLL4g",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=806050795&oldid=805575004",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920958674880909313",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LoYznRLL4g",
  "id" : 920958674880909313,
  "created_at" : "2017-10-19 10:23:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/GiH8pymHun",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102692903&oldid=99264387",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920951095504941056",
  "text" : "Alguien desde CSIC ha editado 'Quintanar del Rey' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GiH8pymHun",
  "id" : 920951095504941056,
  "created_at" : "2017-10-19 09:53:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/33ZzvIANx3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102691142&oldid=102689201",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920905443622481920",
  "text" : "Alguien desde CSIC ha editado 'Wikipedia:Informes de error' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/33ZzvIANx3",
  "id" : 920905443622481920,
  "created_at" : "2017-10-19 06:52:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/H4lqHokYel",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671675&oldid=102671668",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920630695067873280",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/H4lqHokYel",
  "id" : 920630695067873280,
  "created_at" : "2017-10-18 12:40:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/qVeE4ytgwW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671668&oldid=102671627",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920630439156551680",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qVeE4ytgwW",
  "id" : 920630439156551680,
  "created_at" : "2017-10-18 12:39:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/zZskiUUgsD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671627&oldid=102671615",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920629731799781378",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zZskiUUgsD",
  "id" : 920629731799781378,
  "created_at" : "2017-10-18 12:36:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/uA3JIEF6fz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671615&oldid=102671592",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920629527847624704",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uA3JIEF6fz",
  "id" : 920629527847624704,
  "created_at" : "2017-10-18 12:35:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/zRUweRxQNZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671592&oldid=102671584",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920629180303400961",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zRUweRxQNZ",
  "id" : 920629180303400961,
  "created_at" : "2017-10-18 12:34:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/IAqAuuH2ga",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671584&oldid=102671560",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920629065933041664",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IAqAuuH2ga",
  "id" : 920629065933041664,
  "created_at" : "2017-10-18 12:34:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/xPokRB2AfF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671560&oldid=102671554",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920628703281012736",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xPokRB2AfF",
  "id" : 920628703281012736,
  "created_at" : "2017-10-18 12:32:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/kjFp9nPhts",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671554&oldid=102671439",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920628574247415809",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kjFp9nPhts",
  "id" : 920628574247415809,
  "created_at" : "2017-10-18 12:32:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/vu9TKApHBi",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102671439&oldid=102668714",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920626477862965248",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vu9TKApHBi",
  "id" : 920626477862965248,
  "created_at" : "2017-10-18 12:23:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/BVudOnfMDg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102669807&oldid=102418924",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920597002194444288",
  "text" : "Alguien desde CSIC ha editado 'Huesca' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BVudOnfMDg",
  "id" : 920597002194444288,
  "created_at" : "2017-10-18 10:26:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/HIA3vI0TJ5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102669770&oldid=101773298",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920596441122385920",
  "text" : "Alguien desde CSIC ha editado 'Api\u00E9s' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HIA3vI0TJ5",
  "id" : 920596441122385920,
  "created_at" : "2017-10-18 10:24:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/xQTBnoE5Ez",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102669182&oldid=102669123",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920582596773531648",
  "text" : "Alguien desde RedIRIS ha editado 'Achraf Hakimi' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xQTBnoE5Ez",
  "id" : 920582596773531648,
  "created_at" : "2017-10-18 09:29:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/oItpcRSyHM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102668985&oldid=101573748",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920578099149930496",
  "text" : "Alguien desde RedIRIS ha editado 'Time 100' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oItpcRSyHM",
  "id" : 920578099149930496,
  "created_at" : "2017-10-18 09:11:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/SFTczgwg3H",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102668964&oldid=102668956",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920577687181283328",
  "text" : "Alguien desde RedIRIS ha editado 'Achraf Hakimi' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SFTczgwg3H",
  "id" : 920577687181283328,
  "created_at" : "2017-10-18 09:09:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/3yQL8uQX44",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102668956&oldid=102668935",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920577509669957632",
  "text" : "Alguien desde RedIRIS ha editado 'Achraf Hakimi' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3yQL8uQX44",
  "id" : 920577509669957632,
  "created_at" : "2017-10-18 09:09:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/pBRzBZyGQg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102668778&oldid=102668691",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920572998083543040",
  "text" : "Alguien desde RedIRIS ha editado 'Econom\u00EDa de Mozambique' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pBRzBZyGQg",
  "id" : 920572998083543040,
  "created_at" : "2017-10-18 08:51:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/YO4fW8Sp4z",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102668691&oldid=102336068",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920571380990644224",
  "text" : "Alguien desde RedIRIS ha editado 'Econom\u00EDa de Mozambique' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YO4fW8Sp4z",
  "id" : 920571380990644224,
  "created_at" : "2017-10-18 08:44:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/lazU8GO1ew",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102668267&oldid=102667928",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920563942010839040",
  "text" : "Alguien desde RedIRIS ha editado 'MasterChef Celebrity' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lazU8GO1ew",
  "id" : 920563942010839040,
  "created_at" : "2017-10-18 08:15:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Ocik7WMWsm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667446&oldid=102667440",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920549606789910529",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ocik7WMWsm",
  "id" : 920549606789910529,
  "created_at" : "2017-10-18 07:18:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/aOUjLWI1g3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667440&oldid=102667231",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920549520710230018",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aOUjLWI1g3",
  "id" : 920549520710230018,
  "created_at" : "2017-10-18 07:18:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/q7vsEhr8YN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667231&oldid=102667184",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920545681919631360",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/q7vsEhr8YN",
  "id" : 920545681919631360,
  "created_at" : "2017-10-18 07:02:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Z020jME8ov",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667184&oldid=102667172",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920545031714459648",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Z020jME8ov",
  "id" : 920545031714459648,
  "created_at" : "2017-10-18 07:00:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/ab9D5b1Gbw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667172&oldid=102667163",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920544868463730688",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ab9D5b1Gbw",
  "id" : 920544868463730688,
  "created_at" : "2017-10-18 06:59:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/4KpUBXnQtn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667163&oldid=102667153",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920544606810284032",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4KpUBXnQtn",
  "id" : 920544606810284032,
  "created_at" : "2017-10-18 06:58:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/EAve6a0HDd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667153&oldid=98269621",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920544453080879104",
  "text" : "Alguien desde RedIRIS ha editado 'Sulfito' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EAve6a0HDd",
  "id" : 920544453080879104,
  "created_at" : "2017-10-18 06:57:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/QInUZ7kRNk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102667063&oldid=102663298",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920542478201184256",
  "text" : "Alguien desde RedIRIS ha editado 'Azufre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QInUZ7kRNk",
  "id" : 920542478201184256,
  "created_at" : "2017-10-18 06:50:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/2kc7RexRWF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102648859&oldid=98969147",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "920295613841006594",
  "text" : "Alguien desde RedIRIS ha editado '\u00C1cido sulf\u00F3nico' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2kc7RexRWF",
  "id" : 920295613841006594,
  "created_at" : "2017-10-17 14:29:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/yssvPxyXxT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102623747&oldid=99385772",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "919928750942375937",
  "text" : "Alguien desde RedIRIS ha editado 'Pilar Jurado' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/yssvPxyXxT",
  "id" : 919928750942375937,
  "created_at" : "2017-10-16 14:11:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/OR0Vob53QG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102553018&oldid=102551960",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918762381672681472",
  "text" : "Alguien desde RedIRIS ha editado 'Anna Gabriel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OR0Vob53QG",
  "id" : 918762381672681472,
  "created_at" : "2017-10-13 08:56:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/qreAdarkm2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102517178&oldid=102347408",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918161616142848000",
  "text" : "Alguien desde RedIRIS ha editado 'Ley ordinaria' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qreAdarkm2",
  "id" : 918161616142848000,
  "created_at" : "2017-10-11 17:09:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/dcboOHuRKC",
      "expanded_url" : "https:\/\/it.wikipedia.org\/w\/index.php?diff=91926474&oldid=88389748&rcid=225883773",
      "display_url" : "it.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918145314879688704",
  "text" : "Alguien desde CSIC ha editado 'Upupa antaios' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dcboOHuRKC",
  "id" : 918145314879688704,
  "created_at" : "2017-10-11 16:04:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/6wN11IywrC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102474612&oldid=102321645",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917676822099300352",
  "text" : "Alguien desde RedIRIS ha editado 'El Ministerio del Tiempo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6wN11IywrC",
  "id" : 917676822099300352,
  "created_at" : "2017-10-10 09:02:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/evNgEEmBRP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102456685&oldid=102456662",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917416649829036032",
  "text" : "Alguien desde RedIRIS ha editado 'Kermit the Frog' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/evNgEEmBRP",
  "id" : 917416649829036032,
  "created_at" : "2017-10-09 15:49:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/PU5mFluw0z",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102456662&oldid=102225300",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917416468089856000",
  "text" : "Alguien desde RedIRIS ha editado 'Kermit the Frog' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PU5mFluw0z",
  "id" : 917416468089856000,
  "created_at" : "2017-10-09 15:48:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/EseInr2LDY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102456526&oldid=102456518",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917415062536622080",
  "text" : "Alguien desde RedIRIS ha editado 'Miguel Antonio Ju\u00E1rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EseInr2LDY",
  "id" : 917415062536622080,
  "created_at" : "2017-10-09 15:42:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/TAou3E61kR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102456518&oldid=102456457",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917414977509707776",
  "text" : "Alguien desde RedIRIS ha editado 'Miguel Antonio Ju\u00E1rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TAou3E61kR",
  "id" : 917414977509707776,
  "created_at" : "2017-10-09 15:42:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/t2BUDcNuUR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102456457&oldid=102456358",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917414524839395329",
  "text" : "Alguien desde RedIRIS ha editado 'Miguel Antonio Ju\u00E1rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/t2BUDcNuUR",
  "id" : 917414524839395329,
  "created_at" : "2017-10-09 15:40:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/OzZX67Acho",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102456358&oldid=98587960",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917413909404856321",
  "text" : "Alguien desde RedIRIS ha editado 'Miguel Antonio Ju\u00E1rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OzZX67Acho",
  "id" : 917413909404856321,
  "created_at" : "2017-10-09 15:38:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/zyLYRylXvP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102453047&oldid=102398364",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917370541069275142",
  "text" : "Alguien desde CSIC ha editado 'Lynx pardinus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zyLYRylXvP",
  "id" : 917370541069275142,
  "created_at" : "2017-10-09 12:45:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/U8e3y474wR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102449504&oldid=101458919",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917292041444487168",
  "text" : "Alguien desde RedIRIS ha editado 'The European Law Students&amp;#39; Association' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/U8e3y474wR",
  "id" : 917292041444487168,
  "created_at" : "2017-10-09 07:33:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/FlL1HEAz2r",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=804471449&oldid=804471430",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917274216940163072",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FlL1HEAz2r",
  "id" : 917274216940163072,
  "created_at" : "2017-10-09 06:23:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/sAoZCT3RhV",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=804471430&oldid=804471269",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917274164419092480",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sAoZCT3RhV",
  "id" : 917274164419092480,
  "created_at" : "2017-10-09 06:22:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/fBoRwRsDxC",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=804471269&oldid=803898509",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917273684766789632",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fBoRwRsDxC",
  "id" : 917273684766789632,
  "created_at" : "2017-10-09 06:21:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/hWzp6R8TOC",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=804029531&oldid=804029447",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916203600216494080",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (synchrotron)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hWzp6R8TOC",
  "id" : 916203600216494080,
  "created_at" : "2017-10-06 07:28:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/WNR5t6WXnH",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=804029447&oldid=804029211",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916203303234654208",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (synchrotron)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WNR5t6WXnH",
  "id" : 916203303234654208,
  "created_at" : "2017-10-06 07:27:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/PMLAVCxSxb",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=804029211&oldid=764790119",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916202440051056640",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (synchrotron)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PMLAVCxSxb",
  "id" : 916202440051056640,
  "created_at" : "2017-10-06 07:24:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/r2SyNmOuiP",
      "expanded_url" : "https:\/\/ru.wikipedia.org\/w\/index.php?diff=88154036&oldid=88153996",
      "display_url" : "ru.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916202005005205505",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (\u0441\u0438\u043D\u0445\u0440\u043E\u0442\u0440\u043E\u043D)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/r2SyNmOuiP",
  "id" : 916202005005205505,
  "created_at" : "2017-10-06 07:22:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/hXNxXXI4jM",
      "expanded_url" : "https:\/\/ru.wikipedia.org\/w\/index.php?diff=88153996&oldid=88153978",
      "display_url" : "ru.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916201311292608512",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (\u0441\u0438\u043D\u0445\u0440\u043E\u0442\u0440\u043E\u043D)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hXNxXXI4jM",
  "id" : 916201311292608512,
  "created_at" : "2017-10-06 07:19:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Jo6UX7wT0u",
      "expanded_url" : "https:\/\/ru.wikipedia.org\/w\/index.php?diff=88153978&oldid=76039064",
      "display_url" : "ru.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916201064604622849",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (\u0441\u0438\u043D\u0445\u0440\u043E\u0442\u0440\u043E\u043D)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Jo6UX7wT0u",
  "id" : 916201064604622849,
  "created_at" : "2017-10-06 07:18:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/iLck0dlBbw",
      "expanded_url" : "https:\/\/de.wikipedia.org\/w\/index.php?diff=169722258&oldid=169722195",
      "display_url" : "de.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916200379741868033",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (Synchrotron)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iLck0dlBbw",
  "id" : 916200379741868033,
  "created_at" : "2017-10-06 07:16:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Yd3iYrsQkd",
      "expanded_url" : "https:\/\/de.wikipedia.org\/w\/index.php?diff=169722195&oldid=169722166",
      "display_url" : "de.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916199587731435520",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (Synchrotron)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Yd3iYrsQkd",
  "id" : 916199587731435520,
  "created_at" : "2017-10-06 07:12:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/hGcR51vc5F",
      "expanded_url" : "https:\/\/de.wikipedia.org\/w\/index.php?diff=169722166&oldid=169722144",
      "display_url" : "de.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916199271212429312",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (Synchrotron)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hGcR51vc5F",
  "id" : 916199271212429312,
  "created_at" : "2017-10-06 07:11:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/KyhWcKHpIp",
      "expanded_url" : "https:\/\/de.wikipedia.org\/w\/index.php?diff=169722144&oldid=161175088",
      "display_url" : "de.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916199038021787648",
  "text" : "Alguien desde RedIRIS ha editado 'ALBA (Synchrotron)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KyhWcKHpIp",
  "id" : 916199038021787648,
  "created_at" : "2017-10-06 07:10:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/mrnu8fHJDj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102372309&oldid=102372278",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915995933372043265",
  "text" : "Alguien desde RedIRIS ha editado 'Agresor sexual' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mrnu8fHJDj",
  "id" : 915995933372043265,
  "created_at" : "2017-10-05 17:43:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/n0nH2xkbG4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102372268&oldid=99909446",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915995439673028608",
  "text" : "Alguien desde RedIRIS ha editado 'Agresor sexual' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/n0nH2xkbG4",
  "id" : 915995439673028608,
  "created_at" : "2017-10-05 17:41:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/LeKZNsldPe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102372223&oldid=102372211",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915994967948054528",
  "text" : "Alguien desde RedIRIS ha editado 'Promiscuidad' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LeKZNsldPe",
  "id" : 915994967948054528,
  "created_at" : "2017-10-05 17:39:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Z7tz6wUc4x",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102372211&oldid=102372192",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915994840474750976",
  "text" : "Alguien desde RedIRIS ha editado 'Promiscuidad' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Z7tz6wUc4x",
  "id" : 915994840474750976,
  "created_at" : "2017-10-05 17:39:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/A3aLQwht8N",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102372192&oldid=101813528",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915994537901924352",
  "text" : "Alguien desde RedIRIS ha editado 'Promiscuidad' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A3aLQwht8N",
  "id" : 915994537901924352,
  "created_at" : "2017-10-05 17:38:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/WLnkCpX5hS",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=803888526&oldid=803888487",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915864873711652864",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WLnkCpX5hS",
  "id" : 915864873711652864,
  "created_at" : "2017-10-05 09:02:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/LRvhAFgZ9Q",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=803888487&oldid=802439156",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915864761535012869",
  "text" : "Alguien desde RedIRIS ha editado 'Xiker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LRvhAFgZ9Q",
  "id" : 915864761535012869,
  "created_at" : "2017-10-05 09:02:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/2aQSjsuIDq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102341117&oldid=102328124",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915528632780689408",
  "text" : "Alguien desde RedIRIS ha editado 'Volc\u00E1n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2aQSjsuIDq",
  "id" : 915528632780689408,
  "created_at" : "2017-10-04 10:46:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/lYuC6waQTU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102340102&oldid=102293073",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915506843404918784",
  "text" : "Alguien desde RedIRIS ha editado 'Discusi\u00F3n:Catalu\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lYuC6waQTU",
  "id" : 915506843404918784,
  "created_at" : "2017-10-04 09:20:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/BMdO1U7Eou",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102318188&oldid=102211033",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915193617051979776",
  "text" : "Alguien desde RedIRIS ha editado 'La vida moderna (programa de radio)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BMdO1U7Eou",
  "id" : 915193617051979776,
  "created_at" : "2017-10-03 12:35:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/U2Hw57w9Wh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102315127&oldid=102314317",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915131956265914369",
  "text" : "Alguien desde RedIRIS ha editado 'C. Tangana' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/U2Hw57w9Wh",
  "id" : 915131956265914369,
  "created_at" : "2017-10-03 08:30:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/6oxkkKCJsN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102293519&oldid=100608706",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "914821781915041792",
  "text" : "Alguien desde CSIC ha editado 'Pico Vi\u00F1amala' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6oxkkKCJsN",
  "id" : 914821781915041792,
  "created_at" : "2017-10-02 11:58:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/6JEuAg3dBh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=102290138&oldid=101827346",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "914757174886326272",
  "text" : "Alguien desde CSIC ha editado 'Queso de Gamon\u00E9u' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6JEuAg3dBh",
  "id" : 914757174886326272,
  "created_at" : "2017-10-02 07:41:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]