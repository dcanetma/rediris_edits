Grailbird.data.tweets_2017_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/vRTHSdjJ5K",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98004367&oldid=98004358",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847850299515703296",
  "text" : "Alguien desde CSIC ha editado 'Francisco Pi y Margall' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vRTHSdjJ5K",
  "id" : 847850299515703296,
  "created_at" : "2017-03-31 16:37:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/do2NS7Xlzc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98004353&oldid=98004349",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847850116199440384",
  "text" : "Alguien desde CSIC ha editado 'Francisco Pi y Margall' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/do2NS7Xlzc",
  "id" : 847850116199440384,
  "created_at" : "2017-03-31 16:36:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/AeeCIArzNP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=98004349&oldid=96419985",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847850038634176513",
  "text" : "Alguien desde CSIC ha editado 'Francisco Pi y Margall' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AeeCIArzNP",
  "id" : 847850038634176513,
  "created_at" : "2017-03-31 16:36:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Qm87YScLyf",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=471434647&oldid=471433113&rcid=500139736",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847819242699456512",
  "text" : "Alguien desde CSIC ha editado 'Q29054072' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Qm87YScLyf",
  "id" : 847819242699456512,
  "created_at" : "2017-03-31 14:33:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/V2FLxlnJhW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97997731&oldid=97997726",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847752876227166208",
  "text" : "Alguien desde RedIRIS ha editado 'Rock radical vasco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/V2FLxlnJhW",
  "id" : 847752876227166208,
  "created_at" : "2017-03-31 10:10:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/FykV1zq5UX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97997726&oldid=96889238",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847752732114997249",
  "text" : "Alguien desde RedIRIS ha editado 'Rock radical vasco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FykV1zq5UX",
  "id" : 847752732114997249,
  "created_at" : "2017-03-31 10:09:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/pcWRAAQgq5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97976784&oldid=97793740",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847475343992643589",
  "text" : "Alguien desde RedIRIS ha editado 'Lewis Grassic Gibbon' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pcWRAAQgq5",
  "id" : 847475343992643589,
  "created_at" : "2017-03-30 15:47:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/xiPAzEIaws",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97973694&oldid=97973688",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847432383712288769",
  "text" : "Alguien desde RedIRIS ha editado 'Pila (inform\u00E1tica)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xiPAzEIaws",
  "id" : 847432383712288769,
  "created_at" : "2017-03-30 12:56:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/4JtjdEwmxB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97973688&oldid=96917528",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847432129394884612",
  "text" : "Alguien desde RedIRIS ha editado 'Pila (inform\u00E1tica)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4JtjdEwmxB",
  "id" : 847432129394884612,
  "created_at" : "2017-03-30 12:55:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/JSv17j5XeJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97971483&oldid=97971330",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847380047509860352",
  "text" : "Alguien desde RedIRIS ha editado 'Palencia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JSv17j5XeJ",
  "id" : 847380047509860352,
  "created_at" : "2017-03-30 09:28:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/do8DoKKeiK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97971048&oldid=97875920",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847368433754816512",
  "text" : "Alguien desde RedIRIS ha editado 'Grupo ULMA' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/do8DoKKeiK",
  "id" : 847368433754816512,
  "created_at" : "2017-03-30 08:42:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/D9ujvLlLMo",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=772798949&oldid=760403936",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847053846484586496",
  "text" : "Alguien desde CSIC ha editado 'Rayleigh Medal' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/D9ujvLlLMo",
  "id" : 847053846484586496,
  "created_at" : "2017-03-29 11:52:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/k8vpsfKKQK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97946664&oldid=97946656",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847035474694852608",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/k8vpsfKKQK",
  "id" : 847035474694852608,
  "created_at" : "2017-03-29 10:39:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/1edcNYAftO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97946656&oldid=97946642",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847035361637347333",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1edcNYAftO",
  "id" : 847035361637347333,
  "created_at" : "2017-03-29 10:39:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/sG9fyvUnya",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97946642&oldid=97946625",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847035147157417984",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sG9fyvUnya",
  "id" : 847035147157417984,
  "created_at" : "2017-03-29 10:38:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Tf13n3dJ9C",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97946625&oldid=97932159",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847034720995229696",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Tf13n3dJ9C",
  "id" : 847034720995229696,
  "created_at" : "2017-03-29 10:36:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/25hDx4ZglK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97945955&oldid=97945951",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847020852696829953",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Barrera' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/25hDx4ZglK",
  "id" : 847020852696829953,
  "created_at" : "2017-03-29 09:41:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/uf7pYmsB3O",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97945951&oldid=97899725",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847020755191779331",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Barrera' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uf7pYmsB3O",
  "id" : 847020755191779331,
  "created_at" : "2017-03-29 09:40:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/pFdqElmJn1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97944601&oldid=97944593",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847000971960049664",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pFdqElmJn1",
  "id" : 847000971960049664,
  "created_at" : "2017-03-29 08:22:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/4LjEeQrq1q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97944593&oldid=97941048",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847000913835442176",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4LjEeQrq1q",
  "id" : 847000913835442176,
  "created_at" : "2017-03-29 08:22:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/cxLVVpz7ZX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97924735&oldid=97726976",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846746780201078785",
  "text" : "Alguien desde RedIRIS ha editado 'Margot Frank' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cxLVVpz7ZX",
  "id" : 846746780201078785,
  "created_at" : "2017-03-28 15:32:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/gQ9pLvEeXJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97924684&oldid=97908112",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846746020000215040",
  "text" : "Alguien desde RedIRIS ha editado 'Tifus' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gQ9pLvEeXJ",
  "id" : 846746020000215040,
  "created_at" : "2017-03-28 15:29:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/JxD7vNoZ7y",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97918972&oldid=97918957",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846661702930321409",
  "text" : "Alguien desde RedIRIS ha editado 'Susana D\u00EDaz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JxD7vNoZ7y",
  "id" : 846661702930321409,
  "created_at" : "2017-03-28 09:54:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/AAZr6752fV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97918957&oldid=97863368",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846661450307375104",
  "text" : "Alguien desde RedIRIS ha editado 'Susana D\u00EDaz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AAZr6752fV",
  "id" : 846661450307375104,
  "created_at" : "2017-03-28 09:53:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/1D09UYHQhW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97918762&oldid=95197737",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846657802319904768",
  "text" : "Alguien desde RedIRIS ha editado 'Tempo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1D09UYHQhW",
  "id" : 846657802319904768,
  "created_at" : "2017-03-28 09:38:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/GsiSXlh3Sc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97895184&oldid=97895157",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846380255371780096",
  "text" : "Alguien desde CSIC ha editado 'Instituto Cajal' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GsiSXlh3Sc",
  "id" : 846380255371780096,
  "created_at" : "2017-03-27 15:15:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/3Xk8yx1c9q",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97894401&oldid=87198091",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846371124791463937",
  "text" : "Alguien desde CSIC ha editado 'Instituto Cajal' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3Xk8yx1c9q",
  "id" : 846371124791463937,
  "created_at" : "2017-03-27 14:39:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/CssTMF29JB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97893850&oldid=97782594",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846366195691474944",
  "text" : "Alguien desde RedIRIS ha editado 'Rep\u00FAblica de China (1912-1949)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CssTMF29JB",
  "id" : 846366195691474944,
  "created_at" : "2017-03-27 14:20:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/6MdFuvoPIk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97805018&oldid=97804993",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "845244025603022848",
  "text" : "Alguien desde RedIRIS ha editado 'Conor McGregor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6MdFuvoPIk",
  "id" : 845244025603022848,
  "created_at" : "2017-03-24 12:00:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/QNCvlhYrv6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97804993&oldid=97804438",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "845243393462714368",
  "text" : "Alguien desde RedIRIS ha editado 'Conor McGregor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QNCvlhYrv6",
  "id" : 845243393462714368,
  "created_at" : "2017-03-24 11:58:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/A9aotaOVla",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97804016&oldid=97606171",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "845231589604909056",
  "text" : "Alguien desde RedIRIS ha editado 'Red neuronal artificial' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A9aotaOVla",
  "id" : 845231589604909056,
  "created_at" : "2017-03-24 11:11:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/t808ArZ6g3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=97801215&rcid=153311166",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "845195519659978752",
  "text" : "Alguien desde RedIRIS ha editado 'Usuario discusi\u00F3n:130.206.158.161' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/t808ArZ6g3",
  "id" : 845195519659978752,
  "created_at" : "2017-03-24 08:48:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ykGHODoHYf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97777222&oldid=97777201",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844886483114885121",
  "text" : "Alguien desde RedIRIS ha editado 'Bundesliga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ykGHODoHYf",
  "id" : 844886483114885121,
  "created_at" : "2017-03-23 12:20:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/4rqNUL25TH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97777193&oldid=90421195",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844886036807340034",
  "text" : "Alguien desde RedIRIS ha editado 'Bundesliga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4rqNUL25TH",
  "id" : 844886036807340034,
  "created_at" : "2017-03-23 12:18:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/T3EkrFf4z7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97775377&oldid=97775274",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844856200478973952",
  "text" : "Alguien desde RedIRIS ha editado 'Banuncias' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/T3EkrFf4z7",
  "id" : 844856200478973952,
  "created_at" : "2017-03-23 10:19:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/xUzqG69jSP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97775274&oldid=75830283",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844854908847218690",
  "text" : "Alguien desde RedIRIS ha editado 'Banuncias' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xUzqG69jSP",
  "id" : 844854908847218690,
  "created_at" : "2017-03-23 10:14:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/qnGgFdc7Xg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97750522&oldid=96599663",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844524859015266304",
  "text" : "Alguien desde RedIRIS ha editado 'Histidina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qnGgFdc7Xg",
  "id" : 844524859015266304,
  "created_at" : "2017-03-22 12:23:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/8LwJgkteGu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97748388&oldid=96081649",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844492873466830848",
  "text" : "Alguien desde RedIRIS ha editado 'Ben Feringa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8LwJgkteGu",
  "id" : 844492873466830848,
  "created_at" : "2017-03-22 10:16:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/QoY62ijPlh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97748244&oldid=97748234",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844489366793793536",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QoY62ijPlh",
  "id" : 844489366793793536,
  "created_at" : "2017-03-22 10:02:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/TNhrXQDkgl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97748234&oldid=97736214",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844489131644387328",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TNhrXQDkgl",
  "id" : 844489131644387328,
  "created_at" : "2017-03-22 10:01:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/JuKMzBZI5g",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5827005&oldid=4923144",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844130476377980929",
  "text" : "Alguien desde RedIRIS ha editado 'Jose Antonio Campos' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JuKMzBZI5g",
  "id" : 844130476377980929,
  "created_at" : "2017-03-21 10:16:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/oPrqDk4K8E",
      "expanded_url" : "https:\/\/pt.wikipedia.org\/w\/index.php?diff=48330230&oldid=44758923&rcid=73715793",
      "display_url" : "pt.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844125443766861824",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oPrqDk4K8E",
  "id" : 844125443766861824,
  "created_at" : "2017-03-21 09:56:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xwLMjcLwht",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97721680&oldid=97721597",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844123421877387264",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xwLMjcLwht",
  "id" : 844123421877387264,
  "created_at" : "2017-03-21 09:48:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Ptiy67famA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97721597&oldid=97533131",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844122079108759552",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ptiy67famA",
  "id" : 844122079108759552,
  "created_at" : "2017-03-21 09:42:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/XD3RD5L9AF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97703453&oldid=96759145",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843870092010110977",
  "text" : "Alguien desde RedIRIS ha editado 'Revoluci\u00F3n Cultural' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XD3RD5L9AF",
  "id" : 843870092010110977,
  "created_at" : "2017-03-20 17:01:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/cBqUjAMXrE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97701292&oldid=95768085",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843843791777882114",
  "text" : "Alguien desde RedIRIS ha editado 'Jos\u00E9 Carreras' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cBqUjAMXrE",
  "id" : 843843791777882114,
  "created_at" : "2017-03-20 15:16:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/99i5R4scIr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97699911&oldid=97699874",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843823449764192256",
  "text" : "Alguien desde CSIC ha editado '\u00D3scar Freire' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/99i5R4scIr",
  "id" : 843823449764192256,
  "created_at" : "2017-03-20 13:56:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/G3H7NhZZCc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97699874&oldid=97299983",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843822713009553408",
  "text" : "Alguien desde CSIC ha editado '\u00D3scar Freire' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/G3H7NhZZCc",
  "id" : 843822713009553408,
  "created_at" : "2017-03-20 13:53:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/iS96XaM6Ad",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97633622&oldid=96885147",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842801076365656064",
  "text" : "Alguien desde RedIRIS ha editado '\u00C1ngela Figuera Aymerich' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iS96XaM6Ad",
  "id" : 842801076365656064,
  "created_at" : "2017-03-17 18:13:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/N119POQe3K",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97629743&oldid=97629610",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842756231215374342",
  "text" : "Alguien desde RedIRIS ha editado 'Frisbee' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/N119POQe3K",
  "id" : 842756231215374342,
  "created_at" : "2017-03-17 15:15:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/1r1RFD4RsS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97629610&oldid=95157165",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842754230704377857",
  "text" : "Alguien desde RedIRIS ha editado 'Frisbee' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1r1RFD4RsS",
  "id" : 842754230704377857,
  "created_at" : "2017-03-17 15:07:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/PFGBl2olE7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97629551&oldid=97542997",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842753249140752384",
  "text" : "Alguien desde RedIRIS ha editado 'Associazione Calcio Milan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PFGBl2olE7",
  "id" : 842753249140752384,
  "created_at" : "2017-03-17 15:03:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/aHvFoTK3oJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97624023&oldid=96902869",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842673108771373060",
  "text" : "Alguien desde RedIRIS ha editado 'Miravalles' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aHvFoTK3oJ",
  "id" : 842673108771373060,
  "created_at" : "2017-03-17 09:44:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/46iQQKEKxr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97608161&oldid=96725186",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842425883700912128",
  "text" : "Alguien desde RedIRIS ha editado 'I\u00F1aki L\u00F3pez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/46iQQKEKxr",
  "id" : 842425883700912128,
  "created_at" : "2017-03-16 17:22:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/6mpfnxuoWt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97608059&oldid=97119296",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842424553418690561",
  "text" : "Alguien desde RedIRIS ha editado 'Corey Brewer' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6mpfnxuoWt",
  "id" : 842424553418690561,
  "created_at" : "2017-03-16 17:17:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/UNhLjgBume",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97605854&oldid=97605796",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842394828252028928",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Alcaldes de C\u00F3rdoba' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UNhLjgBume",
  "id" : 842394828252028928,
  "created_at" : "2017-03-16 15:19:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/QcfmgtP8pU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97605796&oldid=95451796",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842394143548661760",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Alcaldes de C\u00F3rdoba' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QcfmgtP8pU",
  "id" : 842394143548661760,
  "created_at" : "2017-03-16 15:16:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/VmMbbIw2nv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97601464&oldid=97600606",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842324195358978048",
  "text" : "Alguien desde CSIC ha editado 'Florentino P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VmMbbIw2nv",
  "id" : 842324195358978048,
  "created_at" : "2017-03-16 10:38:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/BfoVZE1Xuh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97583596&oldid=96395128",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842035857758556160",
  "text" : "Alguien desde RedIRIS ha editado 'Derecho a poseer armas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BfoVZE1Xuh",
  "id" : 842035857758556160,
  "created_at" : "2017-03-15 15:32:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/phCYxUtJwe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97580910&oldid=97562006",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841993718232186880",
  "text" : "Alguien desde RedIRIS ha editado 'Archaea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/phCYxUtJwe",
  "id" : 841993718232186880,
  "created_at" : "2017-03-15 12:45:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/b6ozzmKlNV",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97580421&oldid=95346697",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841985838607130624",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/b6ozzmKlNV",
  "id" : 841985838607130624,
  "created_at" : "2017-03-15 12:14:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/LlWYvzEpTZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97578208&oldid=97574166",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841946534182821892",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LlWYvzEpTZ",
  "id" : 841946534182821892,
  "created_at" : "2017-03-15 09:37:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/CoiskiXr5c",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97578186&oldid=97578132",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841946133429669891",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CoiskiXr5c",
  "id" : 841946133429669891,
  "created_at" : "2017-03-15 09:36:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/i2VaybdZ97",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97578138&oldid=97578074",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841944956109520896",
  "text" : "Alguien desde RedIRIS ha editado 'Pulsaciones (serie de televisi\u00F3n)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/i2VaybdZ97",
  "id" : 841944956109520896,
  "created_at" : "2017-03-15 09:31:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/63gYFfBXIh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97578132&oldid=97578091",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841944858227032065",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/63gYFfBXIh",
  "id" : 841944858227032065,
  "created_at" : "2017-03-15 09:31:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/txhC2nLqNZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97578102&oldid=97578006",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841944480982929408",
  "text" : "Alguien desde RedIRIS ha editado 'Betelgeuse' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/txhC2nLqNZ",
  "id" : 841944480982929408,
  "created_at" : "2017-03-15 09:29:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/8HHoMMp7Aa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97578091&oldid=97492807",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841944295514992640",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8HHoMMp7Aa",
  "id" : 841944295514992640,
  "created_at" : "2017-03-15 09:28:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/gwSagePqKl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97578006&oldid=97568983",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841941248487370753",
  "text" : "Alguien desde RedIRIS ha editado 'Betelgeuse' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gwSagePqKl",
  "id" : 841941248487370753,
  "created_at" : "2017-03-15 09:16:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/pBpAyoxRoI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97564721&oldid=94040186",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841711900547137536",
  "text" : "Alguien desde RedIRIS ha editado 'William Jennings Bryan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pBpAyoxRoI",
  "id" : 841711900547137536,
  "created_at" : "2017-03-14 18:05:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/JYJu2vXUak",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97564708&oldid=97564064",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841711749216780288",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JYJu2vXUak",
  "id" : 841711749216780288,
  "created_at" : "2017-03-14 18:04:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/QYkUhdLPag",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97563757&oldid=97563751",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841700869271891968",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QYkUhdLPag",
  "id" : 841700869271891968,
  "created_at" : "2017-03-14 17:21:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9IMVRjrsMc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97563751&oldid=97039000",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841700791937318912",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9IMVRjrsMc",
  "id" : 841700791937318912,
  "created_at" : "2017-03-14 17:21:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/xrNeNICgua",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97563344&oldid=97142304",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841696099559714816",
  "text" : "Alguien desde RedIRIS ha editado 'John Quincy Adams' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xrNeNICgua",
  "id" : 841696099559714816,
  "created_at" : "2017-03-14 17:02:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/EQmxpIhekH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97560897&oldid=96936234",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841665475641761792",
  "text" : "Alguien desde RedIRIS ha editado 'Gobierno de Espa\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EQmxpIhekH",
  "id" : 841665475641761792,
  "created_at" : "2017-03-14 15:01:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/c02cGJIZu1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97534954&oldid=94588991",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841262740140412928",
  "text" : "Alguien desde RedIRIS ha editado 'Funci\u00F3n el\u00EDptica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/c02cGJIZu1",
  "id" : 841262740140412928,
  "created_at" : "2017-03-13 12:20:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/A3ua3OVSgq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97533131&oldid=97533126",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841230790038040576",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A3ua3OVSgq",
  "id" : 841230790038040576,
  "created_at" : "2017-03-13 10:13:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/QIPkDsRj8f",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97533126&oldid=97229074",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841230642952196100",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Blanco P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QIPkDsRj8f",
  "id" : 841230642952196100,
  "created_at" : "2017-03-13 10:13:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/tEBytvN1oP",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=769597355&oldid=691862830",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "840212411521089536",
  "text" : "Alguien desde RedIRIS ha editado 'Homoclinic connection' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tEBytvN1oP",
  "id" : 840212411521089536,
  "created_at" : "2017-03-10 14:47:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/7KcS1sMKaS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97467079&oldid=95433395",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "840096826816520192",
  "text" : "Alguien desde RedIRIS ha editado 'Futbol\u00EDn' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7KcS1sMKaS",
  "id" : 840096826816520192,
  "created_at" : "2017-03-10 07:07:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/6rAOj28XgH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97449828&oldid=94167709",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839853270038364161",
  "text" : "Alguien desde RedIRIS ha editado 'Yo-Yo Ma' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6rAOj28XgH",
  "id" : 839853270038364161,
  "created_at" : "2017-03-09 14:59:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/BfWlTmDaAt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97445800&oldid=97438074",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839786332142579712",
  "text" : "Alguien desde RedIRIS ha editado 'Tom\u00E1s Roncero' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BfWlTmDaAt",
  "id" : 839786332142579712,
  "created_at" : "2017-03-09 10:33:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/IbB19gELzb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97422031&oldid=97420561",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839470281454419968",
  "text" : "Alguien desde RedIRIS ha editado 'Arduino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IbB19gELzb",
  "id" : 839470281454419968,
  "created_at" : "2017-03-08 13:38:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/DFtYAXxll7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97420303&oldid=86266887",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839453768680865792",
  "text" : "Alguien desde CSIC ha editado 'Hermandad del Santo Entierro (\u00C9cija)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DFtYAXxll7",
  "id" : 839453768680865792,
  "created_at" : "2017-03-08 12:32:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/qkwaHXeCVM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97420002&oldid=97401919",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839451046833422336",
  "text" : "Alguien desde RedIRIS ha editado 'IFamily' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qkwaHXeCVM",
  "id" : 839451046833422336,
  "created_at" : "2017-03-08 12:21:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/VW99NbZMhg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97419968&oldid=97417969",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839450682008682497",
  "text" : "Alguien desde RedIRIS ha editado 'Pulsaciones (serie de televisi\u00F3n)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VW99NbZMhg",
  "id" : 839450682008682497,
  "created_at" : "2017-03-08 12:20:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/c1VkH1F9Pk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97419956&oldid=97419925",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839450558146703360",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/c1VkH1F9Pk",
  "id" : 839450558146703360,
  "created_at" : "2017-03-08 12:19:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1VqFBTxvIo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97419925&oldid=97387907",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839450205665775616",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1VqFBTxvIo",
  "id" : 839450205665775616,
  "created_at" : "2017-03-08 12:18:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9a8TD4q1z9",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18216142&oldid=18106794&rcid=36997429",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839440707714748416",
  "text" : "Alguien desde RedIRIS ha editado 'Alfons X el Savi' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9a8TD4q1z9",
  "id" : 839440707714748416,
  "created_at" : "2017-03-08 11:40:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/WXbjjDLKUq",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5810961&oldid=5810943",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839399051359633410",
  "text" : "Alguien desde RedIRIS ha editado 'Emakume Langilearen Nazioarteko Eguna' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WXbjjDLKUq",
  "id" : 839399051359633410,
  "created_at" : "2017-03-08 08:55:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/An4HlTTyUJ",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5810943&oldid=5810937",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839390939386953728",
  "text" : "Alguien desde RedIRIS ha editado 'Emakume Langilearen Nazioarteko Eguna' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/An4HlTTyUJ",
  "id" : 839390939386953728,
  "created_at" : "2017-03-08 08:22:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/zyCp2HsuW6",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5810937&oldid=5810929",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839389479416774657",
  "text" : "Alguien desde RedIRIS ha editado 'Emakume Langilearen Nazioarteko Eguna' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zyCp2HsuW6",
  "id" : 839389479416774657,
  "created_at" : "2017-03-08 08:17:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ENqFNtkFqw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97389778&oldid=97293152",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839114259149774849",
  "text" : "Alguien desde RedIRIS ha editado 'Tragacete' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ENqFNtkFqw",
  "id" : 839114259149774849,
  "created_at" : "2017-03-07 14:03:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/XlAdvWHZTE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97387907&oldid=97252946",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839081235762855936",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XlAdvWHZTE",
  "id" : 839081235762855936,
  "created_at" : "2017-03-07 11:52:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/i9xLXEGTw9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97387498&oldid=97387488",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839073784187535360",
  "text" : "Alguien desde RedIRIS ha editado 'Zinedine Zidane' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/i9xLXEGTw9",
  "id" : 839073784187535360,
  "created_at" : "2017-03-07 11:22:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/f1Clr3Kqz5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97387488&oldid=97299854",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839073651748188160",
  "text" : "Alguien desde RedIRIS ha editado 'Zinedine Zidane' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/f1Clr3Kqz5",
  "id" : 839073651748188160,
  "created_at" : "2017-03-07 11:22:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/NlgFXeDjyo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97385287&oldid=97245702",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839019458802892800",
  "text" : "Alguien desde RedIRIS ha editado 'Guerra de los Cien A\u00F1os' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NlgFXeDjyo",
  "id" : 839019458802892800,
  "created_at" : "2017-03-07 07:46:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ETcGSYRRLV",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5809562&oldid=5809561",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838842215594094592",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Bautista Bengoetxea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ETcGSYRRLV",
  "id" : 838842215594094592,
  "created_at" : "2017-03-06 20:02:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/KyHarK0YKe",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5809561&oldid=5602293",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838841874936913921",
  "text" : "Alguien desde RedIRIS ha editado 'Juan Bautista Bengoetxea' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KyHarK0YKe",
  "id" : 838841874936913921,
  "created_at" : "2017-03-06 20:01:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/gXMhY6sTAi",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=768928740&oldid=752549409",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838781841855373312",
  "text" : "Alguien desde CSIC ha editado 'Talk:Giuseppe Lucatelli' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gXMhY6sTAi",
  "id" : 838781841855373312,
  "created_at" : "2017-03-06 16:02:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/LDTXg7PjRt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97368084&oldid=97270850",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838779165209944064",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LDTXg7PjRt",
  "id" : 838779165209944064,
  "created_at" : "2017-03-06 15:51:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/MO2YkeW30t",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97368073&oldid=97324868",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838779049367470085",
  "text" : "Alguien desde RedIRIS ha editado 'Zachary Taylor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MO2YkeW30t",
  "id" : 838779049367470085,
  "created_at" : "2017-03-06 15:51:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/aAOvmWPGDo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97367915&oldid=97367895",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838776949585678339",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aAOvmWPGDo",
  "id" : 838776949585678339,
  "created_at" : "2017-03-06 15:43:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/9pojH0WrRq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97367895&oldid=97270678",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838776754412142593",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9pojH0WrRq",
  "id" : 838776754412142593,
  "created_at" : "2017-03-06 15:42:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/s9wK8F9t2H",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97367842&oldid=97367830",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838776099983212546",
  "text" : "Alguien desde RedIRIS ha editado 'Martin Van Buren' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/s9wK8F9t2H",
  "id" : 838776099983212546,
  "created_at" : "2017-03-06 15:39:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/JHHyKZdSd1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97367830&oldid=96090479",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838775935704907776",
  "text" : "Alguien desde RedIRIS ha editado 'Martin Van Buren' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JHHyKZdSd1",
  "id" : 838775935704907776,
  "created_at" : "2017-03-06 15:39:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/tcwEHAlUep",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97365776&oldid=97365717",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838743799014752256",
  "text" : "Alguien desde RedIRIS ha editado 'Micolog\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tcwEHAlUep",
  "id" : 838743799014752256,
  "created_at" : "2017-03-06 13:31:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/cfHcKSIjJy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97365717&oldid=97169978",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838742245218086912",
  "text" : "Alguien desde RedIRIS ha editado 'Micolog\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cfHcKSIjJy",
  "id" : 838742245218086912,
  "created_at" : "2017-03-06 13:25:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Fqa4Hm64SM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97363810&oldid=96823289",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838709880919838720",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Conurbaciones en Am\u00E9rica' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Fqa4Hm64SM",
  "id" : 838709880919838720,
  "created_at" : "2017-03-06 11:16:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/OoyS38EVPE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97363193&oldid=97363123",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838695982388940800",
  "text" : "Alguien desde RedIRIS ha editado 'Laredo (Cantabria)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OoyS38EVPE",
  "id" : 838695982388940800,
  "created_at" : "2017-03-06 10:21:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/UwylmaW05d",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97363125&oldid=96194244",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838694718653464576",
  "text" : "Alguien desde RedIRIS ha editado 'El calzonazos' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UwylmaW05d",
  "id" : 838694718653464576,
  "created_at" : "2017-03-06 10:16:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/FczUBulX2Y",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97363011&oldid=97265531",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838693004630163456",
  "text" : "Alguien desde RedIRIS ha editado 'Picio' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FczUBulX2Y",
  "id" : 838693004630163456,
  "created_at" : "2017-03-06 10:09:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/MJDkxjxiw1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97362932&oldid=97362877",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838691720988602369",
  "text" : "Alguien desde RedIRIS ha editado 'Laredo (Cantabria)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MJDkxjxiw1",
  "id" : 838691720988602369,
  "created_at" : "2017-03-06 10:04:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/XrBo3jLqrR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97362832&oldid=97362776",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838690035176206336",
  "text" : "Alguien desde RedIRIS ha editado 'Laredo (Cantabria)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XrBo3jLqrR",
  "id" : 838690035176206336,
  "created_at" : "2017-03-06 09:57:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/QHp4rACdtb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97362606&oldid=97362575",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838686849140985857",
  "text" : "Alguien desde RedIRIS ha editado 'Laredo (Cantabria)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QHp4rACdtb",
  "id" : 838686849140985857,
  "created_at" : "2017-03-06 09:45:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ANOjQ0XKjZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97362534&oldid=97362516",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838685696768495616",
  "text" : "Alguien desde RedIRIS ha editado 'Laredo (Cantabria)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ANOjQ0XKjZ",
  "id" : 838685696768495616,
  "created_at" : "2017-03-06 09:40:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/DPEkktyL3L",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97362516&oldid=97263027",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838685340844060673",
  "text" : "Alguien desde RedIRIS ha editado 'Laredo (Cantabria)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DPEkktyL3L",
  "id" : 838685340844060673,
  "created_at" : "2017-03-06 09:39:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/OktBgz8XZO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97269380&oldid=97269357",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837344189423751168",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OktBgz8XZO",
  "id" : 837344189423751168,
  "created_at" : "2017-03-02 16:49:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/CA4GrXP3fo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97269357&oldid=97267371",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837343918966595585",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CA4GrXP3fo",
  "id" : 837343918966595585,
  "created_at" : "2017-03-02 16:48:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/CxzXNAldMR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97269145&oldid=94873068",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837341155264237569",
  "text" : "Alguien desde RedIRIS ha editado 'Earl Warren' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CxzXNAldMR",
  "id" : 837341155264237569,
  "created_at" : "2017-03-02 16:37:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/4ZHkm8tIAB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97267510&oldid=97266723",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837319697045544961",
  "text" : "Alguien desde RedIRIS ha editado 'Zachary Taylor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4ZHkm8tIAB",
  "id" : 837319697045544961,
  "created_at" : "2017-03-02 15:12:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/E9TgWPAdLA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97267371&oldid=97259232",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837317686510170112",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/E9TgWPAdLA",
  "id" : 837317686510170112,
  "created_at" : "2017-03-02 15:04:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/nN3aJByzkl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97266208&oldid=97193155",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837299393883668481",
  "text" : "Alguien desde CSIC ha editado 'Collectanea Botanica (revista)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/nN3aJByzkl",
  "id" : 837299393883668481,
  "created_at" : "2017-03-02 13:51:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Wks2HxSWka",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97265553&oldid=97252778",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837288111793188864",
  "text" : "Alguien desde RedIRIS ha editado 'Cruas\u00E1n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Wks2HxSWka",
  "id" : 837288111793188864,
  "created_at" : "2017-03-02 13:06:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/axZsz8Bx5V",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97265525&oldid=97265374",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837287477568229376",
  "text" : "Alguien desde RedIRIS ha editado 'Picio' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/axZsz8Bx5V",
  "id" : 837287477568229376,
  "created_at" : "2017-03-02 13:04:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Iv3s13hgc4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97262269&oldid=97262258",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837210163102765056",
  "text" : "Alguien desde RedIRIS ha editado 'Costa Blanca' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Iv3s13hgc4",
  "id" : 837210163102765056,
  "created_at" : "2017-03-02 07:57:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/pZ5H3Y8soo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97262258&oldid=94342467",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837209851788943364",
  "text" : "Alguien desde RedIRIS ha editado 'Costa Blanca' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pZ5H3Y8soo",
  "id" : 837209851788943364,
  "created_at" : "2017-03-02 07:55:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/S2F4fmWc05",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97243553&oldid=97243511",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836959935908962306",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1876' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/S2F4fmWc05",
  "id" : 836959935908962306,
  "created_at" : "2017-03-01 15:22:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/43AVGG3291",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97243511&oldid=96821075",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836959374904070145",
  "text" : "Alguien desde RedIRIS ha editado 'Constituci\u00F3n espa\u00F1ola de 1876' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/43AVGG3291",
  "id" : 836959374904070145,
  "created_at" : "2017-03-01 15:20:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/aIQCCZFdEj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97240300&oldid=97240275",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836903344291606529",
  "text" : "Alguien desde RedIRIS ha editado 'Arginina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aIQCCZFdEj",
  "id" : 836903344291606529,
  "created_at" : "2017-03-01 11:38:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/KKjuBQpWE9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97240275&oldid=97240267",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836902761753108481",
  "text" : "Alguien desde RedIRIS ha editado 'Arginina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KKjuBQpWE9",
  "id" : 836902761753108481,
  "created_at" : "2017-03-01 11:35:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/4dRIIwvclt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97240267&oldid=97240209",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836902633961029633",
  "text" : "Alguien desde RedIRIS ha editado 'Arginina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4dRIIwvclt",
  "id" : 836902633961029633,
  "created_at" : "2017-03-01 11:35:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/zUa9ZZeZzB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97240209&oldid=95985802",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836901150402228224",
  "text" : "Alguien desde RedIRIS ha editado 'Arginina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zUa9ZZeZzB",
  "id" : 836901150402228224,
  "created_at" : "2017-03-01 11:29:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/rA34mNv7Jy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97238894&oldid=97215336",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836867470547959808",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rA34mNv7Jy",
  "id" : 836867470547959808,
  "created_at" : "2017-03-01 09:15:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]