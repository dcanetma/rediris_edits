Grailbird.data.tweets_2016_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Vb2vurRTxd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95900187&oldid=95588263",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "814442658286411776",
  "text" : "Alguien desde RedIRIS ha editado 'Espa\u00F1a en la Segunda Guerra Mundial' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Vb2vurRTxd",
  "id" : 814442658286411776,
  "created_at" : "2016-12-29 12:07:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/giXcWhNVI3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842808&oldid=95842805",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813375781942521857",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/giXcWhNVI3",
  "id" : 813375781942521857,
  "created_at" : "2016-12-26 13:27:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/3ypZl9pIks",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842805&oldid=95842802",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813375684227858432",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3ypZl9pIks",
  "id" : 813375684227858432,
  "created_at" : "2016-12-26 13:27:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/5al5jQ46S2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842802&oldid=95842800",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813375608394838017",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5al5jQ46S2",
  "id" : 813375608394838017,
  "created_at" : "2016-12-26 13:27:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/kEKrCVUN6G",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842800&oldid=95842795",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813375535741026304",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kEKrCVUN6G",
  "id" : 813375535741026304,
  "created_at" : "2016-12-26 13:26:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/jeTvPNUFkI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842795&oldid=95842784",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813375445848752128",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jeTvPNUFkI",
  "id" : 813375445848752128,
  "created_at" : "2016-12-26 13:26:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fA8gLuUwFl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842784&oldid=95842769",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813375374579081216",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fA8gLuUwFl",
  "id" : 813375374579081216,
  "created_at" : "2016-12-26 13:26:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/tNtACIxLai",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842769&oldid=95842759",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813375114108616704",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tNtACIxLai",
  "id" : 813375114108616704,
  "created_at" : "2016-12-26 13:25:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/cMbvjWlPdQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842759&oldid=95842754",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813374867517165570",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cMbvjWlPdQ",
  "id" : 813374867517165570,
  "created_at" : "2016-12-26 13:24:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ro5WRbP0Fs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842754&oldid=95842750",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813374765226426368",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ro5WRbP0Fs",
  "id" : 813374765226426368,
  "created_at" : "2016-12-26 13:23:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/UAQCtpNgtn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842750&oldid=95842721",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813374686042136576",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UAQCtpNgtn",
  "id" : 813374686042136576,
  "created_at" : "2016-12-26 13:23:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/vpPcUV85Iu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95842721&oldid=95783467",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813374256314777600",
  "text" : "Alguien desde RedIRIS ha editado 'Selecci\u00F3n de f\u00FAtbol de Nicaragua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vpPcUV85Iu",
  "id" : 813374256314777600,
  "created_at" : "2016-12-26 13:21:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/KMg8HFA5DC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95792167&oldid=95792140",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812225813315719168",
  "text" : "Alguien desde RedIRIS ha editado 'V\u00EDctor Ros' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KMg8HFA5DC",
  "id" : 812225813315719168,
  "created_at" : "2016-12-23 09:18:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/KcwaKInoEA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95792140&oldid=95792134",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812224761514311680",
  "text" : "Alguien desde RedIRIS ha editado 'V\u00EDctor Ros' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KcwaKInoEA",
  "id" : 812224761514311680,
  "created_at" : "2016-12-23 09:14:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/esBgXBzOmt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95792134&oldid=95785996",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812224258336325632",
  "text" : "Alguien desde RedIRIS ha editado 'V\u00EDctor Ros' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/esBgXBzOmt",
  "id" : 812224258336325632,
  "created_at" : "2016-12-23 09:12:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/sN9Qn7R1k7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95766731&oldid=94991996",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811700844664123392",
  "text" : "Alguien desde RedIRIS ha editado 'Ex-ante' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sN9Qn7R1k7",
  "id" : 811700844664123392,
  "created_at" : "2016-12-21 22:32:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/8vDzBWH8mn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95753863&oldid=95753244",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811515552619433984",
  "text" : "Alguien desde RedIRIS ha editado 'Lo que escond\u00EDan sus ojos' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8vDzBWH8mn",
  "id" : 811515552619433984,
  "created_at" : "2016-12-21 10:15:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/NthILyGHUk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95753390&oldid=95634607",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811499298236100608",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NthILyGHUk",
  "id" : 811499298236100608,
  "created_at" : "2016-12-21 09:11:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/dUoc6EIAF7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95735687&oldid=95735670",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811241169648844801",
  "text" : "Alguien desde RedIRIS ha editado 'Decreto legislativo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dUoc6EIAF7",
  "id" : 811241169648844801,
  "created_at" : "2016-12-20 16:05:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xxDu9nGqfb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95735670&oldid=93061407",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811240888252989440",
  "text" : "Alguien desde RedIRIS ha editado 'Decreto legislativo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xxDu9nGqfb",
  "id" : 811240888252989440,
  "created_at" : "2016-12-20 16:04:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/uFD7LOwiMW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=95735438&rcid=142309704",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811237701496270848",
  "text" : "Alguien desde RedIRIS ha editado 'The Burning of the Red Lotus Temple' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uFD7LOwiMW",
  "id" : 811237701496270848,
  "created_at" : "2016-12-20 15:51:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/YGutXEco7c",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95729587&oldid=95028578",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811119186638422017",
  "text" : "Alguien desde CSIC ha editado 'Unidad de Acci\u00F3n Rural' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YGutXEco7c",
  "id" : 811119186638422017,
  "created_at" : "2016-12-20 08:00:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/hqv3t0htWO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95707402&oldid=91838075",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "810867581666082816",
  "text" : "Alguien desde RedIRIS ha editado 'Faraday Future' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hqv3t0htWO",
  "id" : 810867581666082816,
  "created_at" : "2016-12-19 15:21:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/2ikLcWDgFu",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17910311&oldid=17582505&rcid=34642507",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "810795664988839936",
  "text" : "Alguien desde CSIC ha editado 'Pirah\u00E3' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2ikLcWDgFu",
  "id" : 810795664988839936,
  "created_at" : "2016-12-19 10:35:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Q7Q2e1gWHl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95656038&oldid=95656025",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809852633255215104",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Q7Q2e1gWHl",
  "id" : 809852633255215104,
  "created_at" : "2016-12-16 20:08:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/HBhfYRSGxM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95656025&oldid=95656008",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809852504829788160",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HBhfYRSGxM",
  "id" : 809852504829788160,
  "created_at" : "2016-12-16 20:07:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/9b6yjkUmmF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95656008&oldid=95655984",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809852308997754880",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9b6yjkUmmF",
  "id" : 809852308997754880,
  "created_at" : "2016-12-16 20:06:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Q6bkxf4hny",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95655984&oldid=95655979",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809852018835722242",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Q6bkxf4hny",
  "id" : 809852018835722242,
  "created_at" : "2016-12-16 20:05:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/8VyFmwheC6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95655979&oldid=95655839",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809851941748666368",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8VyFmwheC6",
  "id" : 809851941748666368,
  "created_at" : "2016-12-16 20:05:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ehbqVkouBI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95655839&oldid=95655827",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809850091192389632",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ehbqVkouBI",
  "id" : 809850091192389632,
  "created_at" : "2016-12-16 19:58:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/EUv1E1zdW8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95655827&oldid=95655816",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809849946736365568",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EUv1E1zdW8",
  "id" : 809849946736365568,
  "created_at" : "2016-12-16 19:57:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/lXXoe6gKbc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95655816&oldid=95655802",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809849797305921537",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lXXoe6gKbc",
  "id" : 809849797305921537,
  "created_at" : "2016-12-16 19:56:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/asXLAbJWoq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95655802&oldid=95655742",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809849523791134720",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/asXLAbJWoq",
  "id" : 809849523791134720,
  "created_at" : "2016-12-16 19:55:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/nuuTP59sMt",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95655742&oldid=95627496",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809848656480321536",
  "text" : "Alguien desde RedIRIS ha editado 'Andrew Jackson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/nuuTP59sMt",
  "id" : 809848656480321536,
  "created_at" : "2016-12-16 19:52:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/oakDlSPlTg",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=755167302&oldid=750704061",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809802379528966145",
  "text" : "Alguien desde RedIRIS ha editado 'Nylon 66' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/oakDlSPlTg",
  "id" : 809802379528966145,
  "created_at" : "2016-12-16 16:48:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/YLaikDFAad",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=17888507&oldid=16862277&rcid=34555204",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809448509959245824",
  "text" : "Alguien desde RedIRIS ha editado 'Judes Iscariot' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/YLaikDFAad",
  "id" : 809448509959245824,
  "created_at" : "2016-12-15 17:22:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/aLs5KuIlNQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95632951&oldid=94950469",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809440624768405513",
  "text" : "Alguien desde RedIRIS ha editado 'Triac' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aLs5KuIlNQ",
  "id" : 809440624768405513,
  "created_at" : "2016-12-15 16:50:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/BZ3LWfTwSu",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95626840&oldid=95626822",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809335949658361856",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Velvet' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BZ3LWfTwSu",
  "id" : 809335949658361856,
  "created_at" : "2016-12-15 09:55:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/q3Tb5aZcBj",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=416570967&oldid=412882547&rcid=439907682",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809320525952589825",
  "text" : "Alguien desde CSIC ha editado 'Q5997371' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/q3Tb5aZcBj",
  "id" : 809320525952589825,
  "created_at" : "2016-12-15 08:53:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/0JkaqmkXyn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95614461&oldid=95185679",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809116519611453443",
  "text" : "Alguien desde RedIRIS ha editado 'Facundo Perezagua' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0JkaqmkXyn",
  "id" : 809116519611453443,
  "created_at" : "2016-12-14 19:23:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/LS9VCX2ZQa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95614368&oldid=82554749",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809115226780160001",
  "text" : "Alguien desde RedIRIS ha editado 'P\u00E1nico de 1837' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LS9VCX2ZQa",
  "id" : 809115226780160001,
  "created_at" : "2016-12-14 19:17:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/RJpRlzk2Y3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95605226&oldid=95605143",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808971489525567488",
  "text" : "Alguien desde RedIRIS ha editado 'MasterChef Celebrity' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RJpRlzk2Y3",
  "id" : 808971489525567488,
  "created_at" : "2016-12-14 09:46:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Yti4gG3yyw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95592597&oldid=85014546",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808733539885846528",
  "text" : "Alguien desde RedIRIS ha editado 'Trivial (matem\u00E1tica)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Yti4gG3yyw",
  "id" : 808733539885846528,
  "created_at" : "2016-12-13 18:01:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/A00fvFcv5K",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=754614181&oldid=754613994",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808707212835254272",
  "text" : "Alguien desde CSIC ha editado 'Battle of Bloody Marsh' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A00fvFcv5K",
  "id" : 808707212835254272,
  "created_at" : "2016-12-13 16:16:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/eMc1jhTrbe",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=754613994&oldid=754613079",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808706939282718720",
  "text" : "Alguien desde CSIC ha editado 'Battle of Bloody Marsh' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/eMc1jhTrbe",
  "id" : 808706939282718720,
  "created_at" : "2016-12-13 16:15:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/0mQMLLvBsd",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=754613079&oldid=751950341",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808705670895779841",
  "text" : "Alguien desde CSIC ha editado 'Battle of Bloody Marsh' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0mQMLLvBsd",
  "id" : 808705670895779841,
  "created_at" : "2016-12-13 16:10:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/nJMccW6XEN",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=754612860&oldid=754612673",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808705341135421440",
  "text" : "Alguien desde CSIC ha editado 'Invasion of Georgia (1742)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/nJMccW6XEN",
  "id" : 808705341135421440,
  "created_at" : "2016-12-13 16:09:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/D8iP6ucZtB",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=754612673&oldid=753738506",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808705081461850112",
  "text" : "Alguien desde CSIC ha editado 'Invasion of Georgia (1742)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/D8iP6ucZtB",
  "id" : 808705081461850112,
  "created_at" : "2016-12-13 16:08:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Iszjre8wJX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95566114&oldid=95557444",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808287032757915648",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Iszjre8wJX",
  "id" : 808287032757915648,
  "created_at" : "2016-12-12 12:27:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/fOJ8h8WixN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95565572&oldid=95344037",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808275099992387585",
  "text" : "Alguien desde CSIC ha editado '\u00C1cido graso omega 3' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/fOJ8h8WixN",
  "id" : 808275099992387585,
  "created_at" : "2016-12-12 11:39:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/bgvqGB3dQB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95526416&oldid=93583035",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "807520803130642432",
  "text" : "Alguien desde RedIRIS ha editado 'Legaria' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bgvqGB3dQB",
  "id" : 807520803130642432,
  "created_at" : "2016-12-10 09:42:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/TGTk7iMvaH",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5658346&oldid=5569369",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "807520049695223808",
  "text" : "Alguien desde RedIRIS ha editado 'Legaria' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TGTk7iMvaH",
  "id" : 807520049695223808,
  "created_at" : "2016-12-10 09:39:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/qLs5igU6tN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95468653&oldid=95234970",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "806447770102075392",
  "text" : "Alguien desde RedIRIS ha editado 'Discusi\u00F3n:Crist\u00F3bal Col\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qLs5igU6tN",
  "id" : 806447770102075392,
  "created_at" : "2016-12-07 10:38:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/VtmK9AHr8L",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=753469255&oldid=712962463",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "806440658399612928",
  "text" : "Alguien desde CSIC ha editado 'Silver iodide' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VtmK9AHr8L",
  "id" : 806440658399612928,
  "created_at" : "2016-12-07 10:10:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/JSuKnWSHAi",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95427204&oldid=93586510",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805737370045845504",
  "text" : "Alguien desde CSIC ha editado 'Gabriel Morales y Mendigutia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JSuKnWSHAi",
  "id" : 805737370045845504,
  "created_at" : "2016-12-05 11:35:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/SihMnjpRfk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95366321&oldid=95366319",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804622035284586496",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SihMnjpRfk",
  "id" : 804622035284586496,
  "created_at" : "2016-12-02 09:43:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/PXSrd7BaRg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95366319&oldid=95340032",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804621970943971328",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PXSrd7BaRg",
  "id" : 804621970943971328,
  "created_at" : "2016-12-02 09:43:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/tJ9Ub3nJ23",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95365876&oldid=94788120",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804607567389462528",
  "text" : "Alguien desde RedIRIS ha editado 'Carmen Vela' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tJ9Ub3nJ23",
  "id" : 804607567389462528,
  "created_at" : "2016-12-02 08:46:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/sfyppZkbVN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95348084&oldid=75147856",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804290265196494848",
  "text" : "Alguien desde RedIRIS ha editado 'Almacenamiento energ\u00E9tico en red' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sfyppZkbVN",
  "id" : 804290265196494848,
  "created_at" : "2016-12-01 11:45:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Q1bfHdH6RD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95346697&oldid=95346694",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804257263175290881",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Q1bfHdH6RD",
  "id" : 804257263175290881,
  "created_at" : "2016-12-01 09:34:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/mbRujzJQGQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95346694&oldid=95346691",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804257109235920896",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mbRujzJQGQ",
  "id" : 804257109235920896,
  "created_at" : "2016-12-01 09:33:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/WVGQsXKNa8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95346691&oldid=95346608",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804257007297527808",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WVGQsXKNa8",
  "id" : 804257007297527808,
  "created_at" : "2016-12-01 09:33:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/1jZ1K0HWJl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95346608&oldid=95346603",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804253958969708544",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1jZ1K0HWJl",
  "id" : 804253958969708544,
  "created_at" : "2016-12-01 09:21:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/lVv9MQR4iE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95346603&oldid=95346589",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804253763531898880",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lVv9MQR4iE",
  "id" : 804253763531898880,
  "created_at" : "2016-12-01 09:20:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/cTtdUdmsAU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95346589&oldid=95346580",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804253053868277760",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cTtdUdmsAU",
  "id" : 804253053868277760,
  "created_at" : "2016-12-01 09:17:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/LQCJbjxDYx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=95346580&oldid=94099819",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804252745989582848",
  "text" : "Alguien desde RedIRIS ha editado 'Carlos Merino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LQCJbjxDYx",
  "id" : 804252745989582848,
  "created_at" : "2016-12-01 09:16:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]