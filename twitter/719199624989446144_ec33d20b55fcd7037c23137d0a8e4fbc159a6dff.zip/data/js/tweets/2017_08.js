Grailbird.data.tweets_2017_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/iuWgdtXKAT",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101536803&oldid=101248019",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903215123615141888",
  "text" : "Alguien desde CSIC ha editado '19 de noviembre' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iuWgdtXKAT",
  "id" : 903215123615141888,
  "created_at" : "2017-08-31 11:17:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Bc4Y8387Sa",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101512833&oldid=101512397",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902790784101044229",
  "text" : "Alguien desde CSIC ha editado 'Wikipedia:Informes de error' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Bc4Y8387Sa",
  "id" : 902790784101044229,
  "created_at" : "2017-08-30 07:11:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/SdsBwt0OYI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101470167&oldid=101470094",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902097691576082432",
  "text" : "Alguien desde CSIC ha editado 'Juan Grijalbo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SdsBwt0OYI",
  "id" : 902097691576082432,
  "created_at" : "2017-08-28 09:17:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/lMNZ10slwg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101470094&oldid=97795764",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902094974384263168",
  "text" : "Alguien desde CSIC ha editado 'Juan Grijalbo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lMNZ10slwg",
  "id" : 902094974384263168,
  "created_at" : "2017-08-28 09:06:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/l825eDi5mb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101360341&oldid=101359851",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900706751653302273",
  "text" : "Alguien desde RedIRIS ha editado 'Par\u00EDs Saint-Germain Football Club' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/l825eDi5mb",
  "id" : 900706751653302273,
  "created_at" : "2017-08-24 13:09:58 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/bis3QVSewz",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18756403&oldid=18626130&rcid=61284792",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900602769245175810",
  "text" : "Alguien desde RedIRIS ha editado 'Albert Balcells i Gonz\u00E1lez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bis3QVSewz",
  "id" : 900602769245175810,
  "created_at" : "2017-08-24 06:16:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/JMsWz0LnMp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=101329715&oldid=101255553",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900320248548777984",
  "text" : "Alguien desde RedIRIS ha editado 'La casa de papel' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JMsWz0LnMp",
  "id" : 900320248548777984,
  "created_at" : "2017-08-23 11:34:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/xFmkFC8AUe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100872910&oldid=96152742",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892724686215409664",
  "text" : "Alguien desde RedIRIS ha editado 'Discusi\u00F3n:Sextuplete (deporte)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xFmkFC8AUe",
  "id" : 892724686215409664,
  "created_at" : "2017-08-02 12:32:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/t4tFwnxoCD",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=793377306&oldid=793371595",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892335655178686466",
  "text" : "Alguien desde RedIRIS ha editado 'Torralba and Ambrona (archaeological site)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/t4tFwnxoCD",
  "id" : 892335655178686466,
  "created_at" : "2017-08-01 10:46:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/XUuUMBuy7r",
      "expanded_url" : "https:\/\/de.wikipedia.org\/w\/index.php?diff=167773010&oldid=144802336",
      "display_url" : "de.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892335263581708288",
  "text" : "Alguien desde RedIRIS ha editado 'Torralba und Ambrona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XUuUMBuy7r",
  "id" : 892335263581708288,
  "created_at" : "2017-08-01 10:44:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/50ycS63ENa",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=793371595&oldid=793371233",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892324852383846401",
  "text" : "Alguien desde RedIRIS ha editado 'Torralba and Ambrona (archaeological site)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/50ycS63ENa",
  "id" : 892324852383846401,
  "created_at" : "2017-08-01 10:03:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/8JAJzXvwtu",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=793371233&oldid=793371116",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892324051196293121",
  "text" : "Alguien desde RedIRIS ha editado 'Torralba and Ambrona (archaeological site)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8JAJzXvwtu",
  "id" : 892324051196293121,
  "created_at" : "2017-08-01 10:00:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/SJyjWo2Vaz",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=793371116&oldid=793369853",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892323750540169216",
  "text" : "Alguien desde RedIRIS ha editado 'Torralba and Ambrona (archaeological site)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SJyjWo2Vaz",
  "id" : 892323750540169216,
  "created_at" : "2017-08-01 09:58:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Bx2q1ZqnaN",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=793369853&oldid=552744645",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892320890108743681",
  "text" : "Alguien desde RedIRIS ha editado 'Torralba and Ambrona (archaeological site)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Bx2q1ZqnaN",
  "id" : 892320890108743681,
  "created_at" : "2017-08-01 09:47:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]