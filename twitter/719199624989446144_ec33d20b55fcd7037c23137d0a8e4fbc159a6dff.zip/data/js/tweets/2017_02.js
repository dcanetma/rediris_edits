Grailbird.data.tweets_2017_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/wa05gKJ61H",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97213785&oldid=97133222",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836473524718022656",
  "text" : "Alguien desde RedIRIS ha editado 'Zaorejas' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wa05gKJ61H",
  "id" : 836473524718022656,
  "created_at" : "2017-02-28 07:10:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ki37az7MkH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97196324&oldid=97159409",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836227826160386049",
  "text" : "Alguien desde RedIRIS ha editado 'Zachary Taylor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ki37az7MkH",
  "id" : 836227826160386049,
  "created_at" : "2017-02-27 14:53:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/gDpfXEkWXZ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97194271&oldid=97194267",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836196458487513089",
  "text" : "Alguien desde CSIC ha editado 'Ciclov\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gDpfXEkWXZ",
  "id" : 836196458487513089,
  "created_at" : "2017-02-27 12:49:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/d5h1sRb6uQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97194267&oldid=97005758",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836196382008565762",
  "text" : "Alguien desde CSIC ha editado 'Ciclov\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/d5h1sRb6uQ",
  "id" : 836196382008565762,
  "created_at" : "2017-02-27 12:48:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/QAUnbRxFZN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97193155&oldid=97105847",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836175417203634178",
  "text" : "Alguien desde CSIC ha editado 'Collectanea Botanica (revista)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QAUnbRxFZN",
  "id" : 836175417203634178,
  "created_at" : "2017-02-27 11:25:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/axXQLWRK0e",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97192790&oldid=97192778",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836167058303889408",
  "text" : "Alguien desde RedIRIS ha editado 'Moonlight (pel\u00EDcula)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/axXQLWRK0e",
  "id" : 836167058303889408,
  "created_at" : "2017-02-27 10:52:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/8c2hPu4FY2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97137271&oldid=97137260",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835211921808740353",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8c2hPu4FY2",
  "id" : 835211921808740353,
  "created_at" : "2017-02-24 19:36:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/odcphN2goE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97137260&oldid=97137211",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835211763503226884",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/odcphN2goE",
  "id" : 835211763503226884,
  "created_at" : "2017-02-24 19:36:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/bvmLI568rd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97137211&oldid=97137157",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835210903998054401",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bvmLI568rd",
  "id" : 835210903998054401,
  "created_at" : "2017-02-24 19:32:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/keaqaj6Wos",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97137157&oldid=97137106",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835210105553584128",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/keaqaj6Wos",
  "id" : 835210105553584128,
  "created_at" : "2017-02-24 19:29:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/SeIVxbm4iC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97137106&oldid=97137096",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835209286951256064",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SeIVxbm4iC",
  "id" : 835209286951256064,
  "created_at" : "2017-02-24 19:26:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/jY8sVhN7TG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97137096&oldid=97137073",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835209149814296580",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jY8sVhN7TG",
  "id" : 835209149814296580,
  "created_at" : "2017-02-24 19:25:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/KxkZkqzGui",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97137073&oldid=97136725",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835208663270842368",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KxkZkqzGui",
  "id" : 835208663270842368,
  "created_at" : "2017-02-24 19:23:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/AWUfDm9BjO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97136725&oldid=97136398",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835203623336443905",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AWUfDm9BjO",
  "id" : 835203623336443905,
  "created_at" : "2017-02-24 19:03:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/NBzZwWKXpC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97136398&oldid=95534934",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835199362812755976",
  "text" : "Alguien desde RedIRIS ha editado 'Rutherford B. Hayes' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/NBzZwWKXpC",
  "id" : 835199362812755976,
  "created_at" : "2017-02-24 18:47:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/7RqCZhQwBz",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97136052&oldid=97124640",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835195025168470016",
  "text" : "Alguien desde RedIRIS ha editado 'Zachary Taylor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7RqCZhQwBz",
  "id" : 835195025168470016,
  "created_at" : "2017-02-24 18:29:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/EQaQs8s04E",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?oldid=18171542&rcid=36564042",
      "display_url" : "ca.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835084936642166784",
  "text" : "Alguien desde RedIRIS ha editado 'ELS SUSTANTIUS' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EQaQs8s04E",
  "id" : 835084936642166784,
  "created_at" : "2017-02-24 11:12:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/PzGNYR2JiW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97113568&oldid=97113434",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834831614245031936",
  "text" : "Alguien desde CSIC ha editado 'Fr\u00E9d\u00E9ric Beigbeder' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PzGNYR2JiW",
  "id" : 834831614245031936,
  "created_at" : "2017-02-23 18:25:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/5h24HBtD0G",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97111318&oldid=97109616",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834802370085261313",
  "text" : "Alguien desde RedIRIS ha editado 'Zachary Taylor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/5h24HBtD0G",
  "id" : 834802370085261313,
  "created_at" : "2017-02-23 16:29:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/iiP2UGpYYG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97111009&oldid=97110780",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834798099193352192",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iiP2UGpYYG",
  "id" : 834798099193352192,
  "created_at" : "2017-02-23 16:12:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/zmT5iwF0l8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97110780&oldid=97092310",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834795251223126016",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zmT5iwF0l8",
  "id" : 834795251223126016,
  "created_at" : "2017-02-23 16:01:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ko38yqr4HS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97110736&oldid=97110730",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834794711844012032",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ko38yqr4HS",
  "id" : 834794711844012032,
  "created_at" : "2017-02-23 15:59:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/DgjimiGhUg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97110730&oldid=97010735",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834794672409165825",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DgjimiGhUg",
  "id" : 834794672409165825,
  "created_at" : "2017-02-23 15:58:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/RAMPYctgAH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97109616&oldid=97050367",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834779545156861952",
  "text" : "Alguien desde RedIRIS ha editado 'Zachary Taylor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RAMPYctgAH",
  "id" : 834779545156861952,
  "created_at" : "2017-02-23 14:58:47 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/l3UA7Qdqbh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97109471&oldid=97109435",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834777416170082304",
  "text" : "Alguien desde RedIRIS ha editado 'Grover Cleveland' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/l3UA7Qdqbh",
  "id" : 834777416170082304,
  "created_at" : "2017-02-23 14:50:20 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/N2staPKrlo",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97109435&oldid=96906776",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834776965269819392",
  "text" : "Alguien desde RedIRIS ha editado 'Grover Cleveland' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/N2staPKrlo",
  "id" : 834776965269819392,
  "created_at" : "2017-02-23 14:48:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/0tQUkskw2i",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97107415&oldid=97107388",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834743715482783746",
  "text" : "Alguien desde RedIRIS ha editado '\u00C1ngel To\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0tQUkskw2i",
  "id" : 834743715482783746,
  "created_at" : "2017-02-23 12:36:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/vM3QcvzWAH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97107388&oldid=97107377",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834743163856224256",
  "text" : "Alguien desde RedIRIS ha editado '\u00C1ngel To\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/vM3QcvzWAH",
  "id" : 834743163856224256,
  "created_at" : "2017-02-23 12:34:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/QGDXO0Y8XS",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97107377&oldid=95289541",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834743023728750592",
  "text" : "Alguien desde RedIRIS ha editado '\u00C1ngel To\u00F1a' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QGDXO0Y8XS",
  "id" : 834743023728750592,
  "created_at" : "2017-02-23 12:33:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/pk29FN4pgw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97107299&oldid=97107010",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834741623770734592",
  "text" : "Alguien desde RedIRIS ha editado 'El final del camino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pk29FN4pgw",
  "id" : 834741623770734592,
  "created_at" : "2017-02-23 12:28:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/KRkvzouIGH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97107010&oldid=97106876",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834736950040989697",
  "text" : "Alguien desde RedIRIS ha editado 'El final del camino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KRkvzouIGH",
  "id" : 834736950040989697,
  "created_at" : "2017-02-23 12:09:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/cuub4XgFJJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97106876&oldid=96975161",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834735087224766464",
  "text" : "Alguien desde RedIRIS ha editado 'El final del camino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cuub4XgFJJ",
  "id" : 834735087224766464,
  "created_at" : "2017-02-23 12:02:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/9myqEIcGhX",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97105024&oldid=97104061",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834697350828457984",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9myqEIcGhX",
  "id" : 834697350828457984,
  "created_at" : "2017-02-23 09:32:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ZXtATOfmNI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97104901&oldid=97104898",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834693797279887360",
  "text" : "Alguien desde RedIRIS ha editado 'Testudines' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZXtATOfmNI",
  "id" : 834693797279887360,
  "created_at" : "2017-02-23 09:18:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/SZt8jq8ukb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97104898&oldid=96956818",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834693652685393921",
  "text" : "Alguien desde RedIRIS ha editado 'Testudines' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SZt8jq8ukb",
  "id" : 834693652685393921,
  "created_at" : "2017-02-23 09:17:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/S3eVEZq78m",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97092310&oldid=97092303",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834478106996011010",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/S3eVEZq78m",
  "id" : 834478106996011010,
  "created_at" : "2017-02-22 19:00:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/s2Bli782UL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97092303&oldid=97063829",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834478030718398465",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/s2Bli782UL",
  "id" : 834478030718398465,
  "created_at" : "2017-02-22 19:00:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9liryFXF2A",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97087307&oldid=97087278",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834413207930470400",
  "text" : "Alguien desde RedIRIS ha editado 'Energ\u00EDa reticular' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9liryFXF2A",
  "id" : 834413207930470400,
  "created_at" : "2017-02-22 14:43:06 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/CiQcEcRUPn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97087278&oldid=81443165",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834412533486350337",
  "text" : "Alguien desde RedIRIS ha editado 'Energ\u00EDa reticular' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CiQcEcRUPn",
  "id" : 834412533486350337,
  "created_at" : "2017-02-22 14:40:25 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/N7jasHkqpA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97083892&oldid=97082338",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834359361195671552",
  "text" : "Alguien desde RedIRIS ha editado 'Pulsaciones (serie de televisi\u00F3n)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/N7jasHkqpA",
  "id" : 834359361195671552,
  "created_at" : "2017-02-22 11:09:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/PYjEAKyaWQ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97083885&oldid=97083416",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834359254140207104",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PYjEAKyaWQ",
  "id" : 834359254140207104,
  "created_at" : "2017-02-22 11:08:42 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/JLbcTHJsFG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97083416&oldid=97061914",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834350198583336961",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JLbcTHJsFG",
  "id" : 834350198583336961,
  "created_at" : "2017-02-22 10:32:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/4DFt3AVRJp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97082143&oldid=96173951",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834310850718609408",
  "text" : "Alguien desde RedIRIS ha editado 'Bando sublevado' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4DFt3AVRJp",
  "id" : 834310850718609408,
  "created_at" : "2017-02-22 07:56:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ThWlAUchy8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97063829&oldid=97052023",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834059934643912705",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ThWlAUchy8",
  "id" : 834059934643912705,
  "created_at" : "2017-02-21 15:19:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/17n7whRi27",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97060521&oldid=88838603",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834006010553630720",
  "text" : "Alguien desde RedIRIS ha editado 'Ecuaci\u00F3n de Born-Land\u00E9' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/17n7whRi27",
  "id" : 834006010553630720,
  "created_at" : "2017-02-21 11:45:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/sDELBzrYDH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=97059625&rcid=149037627",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833995280710242304",
  "text" : "Alguien desde RedIRIS ha editado 'Discusi\u00F3n:Manuel Arce y Ochotorena' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sDELBzrYDH",
  "id" : 833995280710242304,
  "created_at" : "2017-02-21 11:02:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/OKKuOzcee1",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97058256&oldid=97034005",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833981611884572672",
  "text" : "Alguien desde CSIC ha editado 'Lourdes Ramos Rivero' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OKKuOzcee1",
  "id" : 833981611884572672,
  "created_at" : "2017-02-21 10:08:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/xxNtmxtlYy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97039000&oldid=97038964",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833702391224684544",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xxNtmxtlYy",
  "id" : 833702391224684544,
  "created_at" : "2017-02-20 15:38:34 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/VeQbUXcMFh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97038964&oldid=97028523",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833701844882956288",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/VeQbUXcMFh",
  "id" : 833701844882956288,
  "created_at" : "2017-02-20 15:36:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Kchldmesns",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97038678&oldid=97028745",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833699419556028416",
  "text" : "Alguien desde RedIRIS ha editado 'John Tyler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Kchldmesns",
  "id" : 833699419556028416,
  "created_at" : "2017-02-20 15:26:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/PdqikNNgpY",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97038657&oldid=95534898",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833699189573943296",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PdqikNNgpY",
  "id" : 833699189573943296,
  "created_at" : "2017-02-20 15:25:50 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ytH4Y5DZSE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97038567&oldid=97010651",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833698374574497792",
  "text" : "Alguien desde RedIRIS ha editado 'Millard Fillmore' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ytH4Y5DZSE",
  "id" : 833698374574497792,
  "created_at" : "2017-02-20 15:22:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/lZoJAsRg3O",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97038425&oldid=97007149",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833696830340857857",
  "text" : "Alguien desde RedIRIS ha editado 'Zachary Taylor' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lZoJAsRg3O",
  "id" : 833696830340857857,
  "created_at" : "2017-02-20 15:16:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/9R76DAKHgf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=97037719&oldid=94876158",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833687397082787840",
  "text" : "Alguien desde RedIRIS ha editado 'Regla de Ephraim-Fajans' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9R76DAKHgf",
  "id" : 833687397082787840,
  "created_at" : "2017-02-20 14:38:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ewgJTKZexz",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=766474626&oldid=766197007",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833636655286345728",
  "text" : "Alguien desde RedIRIS ha editado 'Carrefour' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ewgJTKZexz",
  "id" : 833636655286345728,
  "created_at" : "2017-02-20 11:17:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Us8c4MtfQn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96978562&oldid=96978521",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832666899410407424",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Us8c4MtfQn",
  "id" : 832666899410407424,
  "created_at" : "2017-02-17 19:03:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/JXQRDOdqSk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96978521&oldid=96978393",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832666212228165632",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JXQRDOdqSk",
  "id" : 832666212228165632,
  "created_at" : "2017-02-17 19:01:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/xKv0PgVlgi",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96978393&oldid=96978389",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832664670540476417",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xKv0PgVlgi",
  "id" : 832664670540476417,
  "created_at" : "2017-02-17 18:55:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/LyJM7N7rYn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96978389&oldid=96978329",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832664604362764289",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/LyJM7N7rYn",
  "id" : 832664604362764289,
  "created_at" : "2017-02-17 18:54:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/sbRG795bs7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96978329&oldid=96971345",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832663935530659842",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sbRG795bs7",
  "id" : 832663935530659842,
  "created_at" : "2017-02-17 18:52:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/pgy8045Iih",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96970930&oldid=96970902",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832556925996908544",
  "text" : "Alguien desde RedIRIS ha editado 'Marine Le Pen' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/pgy8045Iih",
  "id" : 832556925996908544,
  "created_at" : "2017-02-17 11:46:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/0RTHnX95UF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96970902&oldid=96956927",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832556385950978048",
  "text" : "Alguien desde RedIRIS ha editado 'Marine Le Pen' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0RTHnX95UF",
  "id" : 832556385950978048,
  "created_at" : "2017-02-17 11:44:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/F8X9AESocL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969761&oldid=92362364",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832529587385032704",
  "text" : "Alguien desde CSIC ha editado 'Idioma morlaco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/F8X9AESocL",
  "id" : 832529587385032704,
  "created_at" : "2017-02-17 09:58:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/odLc4FDiAl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969427&oldid=96969416",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832521310559420416",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/odLc4FDiAl",
  "id" : 832521310559420416,
  "created_at" : "2017-02-17 09:25:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/3x4E1r4MD8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969416&oldid=96969406",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832521026013630465",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/3x4E1r4MD8",
  "id" : 832521026013630465,
  "created_at" : "2017-02-17 09:24:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/bDvnAEBw2e",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969406&oldid=96969399",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832520780575563776",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bDvnAEBw2e",
  "id" : 832520780575563776,
  "created_at" : "2017-02-17 09:23:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/lbjQk1EUhL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969399&oldid=96969390",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832520592926601217",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lbjQk1EUhL",
  "id" : 832520592926601217,
  "created_at" : "2017-02-17 09:22:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/7wznJqVFkJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969390&oldid=96969379",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832520365175881728",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7wznJqVFkJ",
  "id" : 832520365175881728,
  "created_at" : "2017-02-17 09:21:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/1W5kXRENVC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969379&oldid=96969339",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832520110631952384",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1W5kXRENVC",
  "id" : 832520110631952384,
  "created_at" : "2017-02-17 09:20:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/hx94cAIa1W",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96969339&oldid=96958992",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832519293690605570",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hx94cAIa1W",
  "id" : 832519293690605570,
  "created_at" : "2017-02-17 09:17:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/f9PXLmhJDG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96954853&oldid=96950981",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832289241585557505",
  "text" : "Alguien desde RedIRIS ha editado 'Fernando Romay' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/f9PXLmhJDG",
  "id" : 832289241585557505,
  "created_at" : "2017-02-16 18:03:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/clVQoQIKN6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96954022&oldid=96943059",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832279685685968896",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/clVQoQIKN6",
  "id" : 832279685685968896,
  "created_at" : "2017-02-16 17:25:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/sfvdLQ5oaB",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=449719305&oldid=418933193&rcid=477189872",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832195219433123841",
  "text" : "Alguien desde RedIRIS ha editado 'Q1393782' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sfvdLQ5oaB",
  "id" : 832195219433123841,
  "created_at" : "2017-02-16 11:49:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ykP2Qmvr3g",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96947164&oldid=91982245",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832172893589086208",
  "text" : "Alguien desde RedIRIS ha editado 'Agente caotr\u00F3pico' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ykP2Qmvr3g",
  "id" : 832172893589086208,
  "created_at" : "2017-02-16 10:20:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/go0xpMIb4N",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96935597&oldid=96933562",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831962626095714304",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/go0xpMIb4N",
  "id" : 831962626095714304,
  "created_at" : "2017-02-15 20:25:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/MhnpUcMMEe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96933562&oldid=96933145",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831942500864708612",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MhnpUcMMEe",
  "id" : 831942500864708612,
  "created_at" : "2017-02-15 19:05:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/POgsql8xtf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96933145&oldid=96679333",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831938128579592197",
  "text" : "Alguien desde RedIRIS ha editado 'Franklin Pierce' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/POgsql8xtf",
  "id" : 831938128579592197,
  "created_at" : "2017-02-15 18:48:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/sGpkk4IHrJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96932928&oldid=96924543",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831935871586881538",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/sGpkk4IHrJ",
  "id" : 831935871586881538,
  "created_at" : "2017-02-15 18:39:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/bOSqnIMMfe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96932916&oldid=96932632",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831935766053937152",
  "text" : "Alguien desde RedIRIS ha editado 'John Tyler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bOSqnIMMfe",
  "id" : 831935766053937152,
  "created_at" : "2017-02-15 18:38:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JlUCktqBoj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96932632&oldid=96919114",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831933688019566592",
  "text" : "Alguien desde RedIRIS ha editado 'John Tyler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/JlUCktqBoj",
  "id" : 831933688019566592,
  "created_at" : "2017-02-15 18:30:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/KAD38qYh2R",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96932555&oldid=96924374",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831933047129985025",
  "text" : "Alguien desde RedIRIS ha editado 'Millard Fillmore' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KAD38qYh2R",
  "id" : 831933047129985025,
  "created_at" : "2017-02-15 18:27:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/ZLHJSeuNPf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96929317&oldid=96923965",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831899373818699776",
  "text" : "Alguien desde RedIRIS ha editado 'Anexo:Episodios de Pulsaciones' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZLHJSeuNPf",
  "id" : 831899373818699776,
  "created_at" : "2017-02-15 16:14:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/rhyAbG3yQI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96929309&oldid=96928014",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831899269015683072",
  "text" : "Alguien desde RedIRIS ha editado 'Pulsaciones (serie de televisi\u00F3n)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/rhyAbG3yQI",
  "id" : 831899269015683072,
  "created_at" : "2017-02-15 16:13:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/y1JzxB2DLc",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96926081&oldid=96926040",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831851367497084932",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/y1JzxB2DLc",
  "id" : 831851367497084932,
  "created_at" : "2017-02-15 13:03:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/KH2dBSzCpP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96926040&oldid=96925994",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831850785021558784",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KH2dBSzCpP",
  "id" : 831850785021558784,
  "created_at" : "2017-02-15 13:00:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ZfVwY5VFks",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96925994&oldid=96925848",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831850279029051392",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZfVwY5VFks",
  "id" : 831850279029051392,
  "created_at" : "2017-02-15 12:58:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/A7WKo17Wvs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96925848&oldid=96925845",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831848608974651393",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A7WKo17Wvs",
  "id" : 831848608974651393,
  "created_at" : "2017-02-15 12:52:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/aRz8g6qJRI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96925845&oldid=96903613",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831848507216633857",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/aRz8g6qJRI",
  "id" : 831848507216633857,
  "created_at" : "2017-02-15 12:51:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Kemgj3kmKq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96925320&oldid=96925296",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831837825221918720",
  "text" : "Alguien desde RedIRIS ha editado 'La analfabeta que era un genio de los n\u00FAmeros' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Kemgj3kmKq",
  "id" : 831837825221918720,
  "created_at" : "2017-02-15 12:09:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/bDe0RnXkxR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96925296&oldid=82082982",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831837264040886273",
  "text" : "Alguien desde RedIRIS ha editado 'La analfabeta que era un genio de los n\u00FAmeros' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bDe0RnXkxR",
  "id" : 831837264040886273,
  "created_at" : "2017-02-15 12:07:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/gk3n35qlwx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?oldid=96925076&rcid=148333528",
      "display_url" : "es.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831833399853776896",
  "text" : "Alguien desde RedIRIS ha editado 'El mat\u00F3n que so\u00F1aba con un lugar en el para\u00EDso' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gk3n35qlwx",
  "id" : 831833399853776896,
  "created_at" : "2017-02-15 11:51:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/S2PnSrzSrr",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96923223&oldid=96923220",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831787114752856064",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/S2PnSrzSrr",
  "id" : 831787114752856064,
  "created_at" : "2017-02-15 08:47:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/1js4zQdyb7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96923220&oldid=96828836",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831787000835485697",
  "text" : "Alguien desde CSIC ha editado 'Top Chef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/1js4zQdyb7",
  "id" : 831787000835485697,
  "created_at" : "2017-02-15 08:47:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/un9If8Um4N",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906830&oldid=94569611",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831536944626688003",
  "text" : "Alguien desde RedIRIS ha editado 'Tammany Hall' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/un9If8Um4N",
  "id" : 831536944626688003,
  "created_at" : "2017-02-14 16:13:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/IQACxXnXLs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906776&oldid=96906761",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831536149604737025",
  "text" : "Alguien desde RedIRIS ha editado 'Grover Cleveland' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/IQACxXnXLs",
  "id" : 831536149604737025,
  "created_at" : "2017-02-14 16:10:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/A18jHLjnbn",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906761&oldid=96685482",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831535947422560256",
  "text" : "Alguien desde RedIRIS ha editado 'Grover Cleveland' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/A18jHLjnbn",
  "id" : 831535947422560256,
  "created_at" : "2017-02-14 16:09:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/SVb0D5zQyI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906587&oldid=96906582",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831533581721800704",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SVb0D5zQyI",
  "id" : 831533581721800704,
  "created_at" : "2017-02-14 16:00:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Mp7LXZrQol",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906582&oldid=96906400",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831533508002770944",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Mp7LXZrQol",
  "id" : 831533508002770944,
  "created_at" : "2017-02-14 16:00:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/bfVPCAlKkE",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906400&oldid=96906341",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831531577003892738",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bfVPCAlKkE",
  "id" : 831531577003892738,
  "created_at" : "2017-02-14 15:52:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/TQmsE6catK",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906341&oldid=96906301",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831530977449168896",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TQmsE6catK",
  "id" : 831530977449168896,
  "created_at" : "2017-02-14 15:50:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/TyDyueAc6r",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906301&oldid=96906258",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831530536464166913",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TyDyueAc6r",
  "id" : 831530536464166913,
  "created_at" : "2017-02-14 15:48:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/EAg91jjDvO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906258&oldid=96906232",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831530109060382722",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EAg91jjDvO",
  "id" : 831530109060382722,
  "created_at" : "2017-02-14 15:46:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/KbRPkX6y9P",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96906232&oldid=96858912",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831529810467946496",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KbRPkX6y9P",
  "id" : 831529810467946496,
  "created_at" : "2017-02-14 15:45:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/9lJsi1fjdC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96903613&oldid=96903606",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831486128138092544",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9lJsi1fjdC",
  "id" : 831486128138092544,
  "created_at" : "2017-02-14 12:51:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/6e43YDl5Fw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96903606&oldid=96901489",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831486030662467584",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6e43YDl5Fw",
  "id" : 831486030662467584,
  "created_at" : "2017-02-14 12:51:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/p8YWcSlEW9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96901489&oldid=96770639",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831441070932238336",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/p8YWcSlEW9",
  "id" : 831441070932238336,
  "created_at" : "2017-02-14 09:52:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/2DBZ1sH9LE",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=764711678&oldid=763166027",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830060765474353152",
  "text" : "Alguien desde CSIC ha editado 'Novena University' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2DBZ1sH9LE",
  "id" : 830060765474353152,
  "created_at" : "2017-02-10 14:28:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/CV9NaweVqa",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=445163304&oldid=445163177&rcid=472418245",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830030861974265856",
  "text" : "Alguien desde RedIRIS ha editado 'Q23907186' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/CV9NaweVqa",
  "id" : 830030861974265856,
  "created_at" : "2017-02-10 12:29:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/w2Q8vzkwjt",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=445163177&oldid=423738577&rcid=472418116",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830030808043945984",
  "text" : "Alguien desde RedIRIS ha editado 'Q23907186' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/w2Q8vzkwjt",
  "id" : 830030808043945984,
  "created_at" : "2017-02-10 12:29:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/n6HjYnPc40",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96816983&oldid=96135593",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830025027189891072",
  "text" : "Alguien desde CSIC ha editado 'Vitaminas del grupo B' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/n6HjYnPc40",
  "id" : 830025027189891072,
  "created_at" : "2017-02-10 12:06:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/MsrMOSeXxw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96816045&oldid=96816041",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830006657933533185",
  "text" : "Alguien desde RedIRIS ha editado 'Wes Anderson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MsrMOSeXxw",
  "id" : 830006657933533185,
  "created_at" : "2017-02-10 10:53:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/kR7yRWBgpA",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96816041&oldid=96716588",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830006498931642369",
  "text" : "Alguien desde RedIRIS ha editado 'Wes Anderson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kR7yRWBgpA",
  "id" : 830006498931642369,
  "created_at" : "2017-02-10 10:52:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/FOE6mQy2sH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96815145&oldid=96756872",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829987789894721536",
  "text" : "Alguien desde CSIC ha editado 'Metodolog\u00EDa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FOE6mQy2sH",
  "id" : 829987789894721536,
  "created_at" : "2017-02-10 09:38:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/wtt6WY35he",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96796271&oldid=96796247",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829734417291735040",
  "text" : "Alguien desde CSIC ha editado 'Amigdalina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wtt6WY35he",
  "id" : 829734417291735040,
  "created_at" : "2017-02-09 16:51:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/cZj9J2RawM",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96796247&oldid=96796194",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829734224185942016",
  "text" : "Alguien desde CSIC ha editado 'Amigdalina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cZj9J2RawM",
  "id" : 829734224185942016,
  "created_at" : "2017-02-09 16:50:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/2VyPAVncnH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96796194&oldid=96796182",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829733563494981632",
  "text" : "Alguien desde CSIC ha editado 'Amigdalina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2VyPAVncnH",
  "id" : 829733563494981632,
  "created_at" : "2017-02-09 16:47:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/iNTL7tTNxf",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96796182&oldid=96204189",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829733364278185984",
  "text" : "Alguien desde CSIC ha editado 'Amigdalina' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/iNTL7tTNxf",
  "id" : 829733364278185984,
  "created_at" : "2017-02-09 16:47:04 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/WLWh7uvtri",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96791742&oldid=96791719",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829665963817725953",
  "text" : "Alguien desde RedIRIS ha editado 'El final del camino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WLWh7uvtri",
  "id" : 829665963817725953,
  "created_at" : "2017-02-09 12:19:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/ueSuR8ZHyR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96791719&oldid=96783995",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829665653166632960",
  "text" : "Alguien desde RedIRIS ha editado 'El final del camino' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ueSuR8ZHyR",
  "id" : 829665653166632960,
  "created_at" : "2017-02-09 12:18:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/frmdGkVrlP",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=764524204&oldid=764524138",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829664495052152832",
  "text" : "Alguien desde RedIRIS ha editado 'Draft:The Altius Society at Oxford' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/frmdGkVrlP",
  "id" : 829664495052152832,
  "created_at" : "2017-02-09 12:13:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/bFk77ac3R2",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?oldid=764524138&rcid=910729248",
      "display_url" : "en.wikipedia.org\/w\/index.php?ol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829664311375253504",
  "text" : "Alguien desde RedIRIS ha editado 'Draft:The Altius Society at Oxford' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bFk77ac3R2",
  "id" : 829664311375253504,
  "created_at" : "2017-02-09 12:12:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/c1Byp4Y0lW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96790988&oldid=96790984",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829650593580986368",
  "text" : "Alguien desde RedIRIS ha editado 'Julio Insa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/c1Byp4Y0lW",
  "id" : 829650593580986368,
  "created_at" : "2017-02-09 11:18:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/xQKbBgUKuj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96790984&oldid=88057036",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829650437229932544",
  "text" : "Alguien desde RedIRIS ha editado 'Julio Insa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/xQKbBgUKuj",
  "id" : 829650437229932544,
  "created_at" : "2017-02-09 11:17:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/EpP1Dy1Rpd",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96775965&oldid=96477762",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829410884460113922",
  "text" : "Alguien desde RedIRIS ha editado 'John Tyler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/EpP1Dy1Rpd",
  "id" : 829410884460113922,
  "created_at" : "2017-02-08 19:25:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9jrAyS6AOg",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96775079&oldid=96743636",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829400842696540160",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9jrAyS6AOg",
  "id" : 829400842696540160,
  "created_at" : "2017-02-08 18:45:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/co78UvvOLy",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96770639&oldid=96653451",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829350690954891265",
  "text" : "Alguien desde CSIC ha editado 'Instituto Bot\u00E1nico de Barcelona' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/co78UvvOLy",
  "id" : 829350690954891265,
  "created_at" : "2017-02-08 15:26:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/t1OGUohLUP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96752216&oldid=94322008",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829040160809635845",
  "text" : "Alguien desde RedIRIS ha editado 'Cueva de Bencomo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/t1OGUohLUP",
  "id" : 829040160809635845,
  "created_at" : "2017-02-07 18:52:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/KDbolnPqeO",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96749009&oldid=95681587",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829009044207710209",
  "text" : "Alguien desde RedIRIS ha editado 'Warren G. Harding' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KDbolnPqeO",
  "id" : 829009044207710209,
  "created_at" : "2017-02-07 16:48:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/XVBs7Dv4sx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96748632&oldid=96746919",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829006422809649152",
  "text" : "Alguien desde RedIRIS ha editado 'Calvin Coolidge' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XVBs7Dv4sx",
  "id" : 829006422809649152,
  "created_at" : "2017-02-07 16:38:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ZmGPdlzpA3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96746919&oldid=96746904",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828994986872074240",
  "text" : "Alguien desde RedIRIS ha editado 'Calvin Coolidge' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ZmGPdlzpA3",
  "id" : 828994986872074240,
  "created_at" : "2017-02-07 15:53:01 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/MpixTCfiFv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96746904&oldid=96746883",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828994742901997569",
  "text" : "Alguien desde RedIRIS ha editado 'Calvin Coolidge' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MpixTCfiFv",
  "id" : 828994742901997569,
  "created_at" : "2017-02-07 15:52:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/7CIDdjzI9l",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96746883&oldid=96746847",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828994458708500481",
  "text" : "Alguien desde RedIRIS ha editado 'Calvin Coolidge' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/7CIDdjzI9l",
  "id" : 828994458708500481,
  "created_at" : "2017-02-07 15:50:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Ajqbpez1Ke",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96746847&oldid=95808443",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828994255767076864",
  "text" : "Alguien desde RedIRIS ha editado 'Calvin Coolidge' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ajqbpez1Ke",
  "id" : 828994255767076864,
  "created_at" : "2017-02-07 15:50:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/88iT6Do9Hq",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96745685&oldid=96685142",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828986217194729473",
  "text" : "Alguien desde RedIRIS ha editado 'Millard Fillmore' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/88iT6Do9Hq",
  "id" : 828986217194729473,
  "created_at" : "2017-02-07 15:18:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/wbD5LG2hxE",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=764171705&oldid=763523710",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828961604943409153",
  "text" : "Alguien desde CSIC ha editado 'Capsaspora' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/wbD5LG2hxE",
  "id" : 828961604943409153,
  "created_at" : "2017-02-07 13:40:22 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/cCRaEXeuTU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96715509&oldid=94777403",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828611165479698432",
  "text" : "Alguien desde RedIRIS ha editado 'Aoiz' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cCRaEXeuTU",
  "id" : 828611165479698432,
  "created_at" : "2017-02-06 14:27:51 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/UENNFZXRm7",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=763984829&oldid=763103206",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828559181531725826",
  "text" : "Alguien desde CSIC ha editado 'CicCartuja' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/UENNFZXRm7",
  "id" : 828559181531725826,
  "created_at" : "2017-02-06 11:01:17 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/K3NF8ek3Vp",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661571&oldid=96661473",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827612886704996352",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/K3NF8ek3Vp",
  "id" : 827612886704996352,
  "created_at" : "2017-02-03 20:21:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/TYtIIPsFEx",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661473&oldid=96661428",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827611692209147905",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TYtIIPsFEx",
  "id" : 827611692209147905,
  "created_at" : "2017-02-03 20:16:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/kLOIhfRqol",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661428&oldid=96661251",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827611499560583168",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kLOIhfRqol",
  "id" : 827611499560583168,
  "created_at" : "2017-02-03 20:15:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/SNDQjslUJJ",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661251&oldid=96661210",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827610001468424197",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SNDQjslUJJ",
  "id" : 827610001468424197,
  "created_at" : "2017-02-03 20:09:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/41MgDYUSSL",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661210&oldid=96661195",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827609402563764225",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/41MgDYUSSL",
  "id" : 827609402563764225,
  "created_at" : "2017-02-03 20:07:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/OxRcnblTnW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661195&oldid=96661187",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827609136221282304",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/OxRcnblTnW",
  "id" : 827609136221282304,
  "created_at" : "2017-02-03 20:06:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ILMfKm4l84",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661187&oldid=96661186",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827608999906402306",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/ILMfKm4l84",
  "id" : 827608999906402306,
  "created_at" : "2017-02-03 20:05:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/mKVNq4VUXI",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661186&oldid=96661056",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827608944050835461",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mKVNq4VUXI",
  "id" : 827608944050835461,
  "created_at" : "2017-02-03 20:05:23 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/gVF8NMImE7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96661056&oldid=96660978",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827607601231826944",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/gVF8NMImE7",
  "id" : 827607601231826944,
  "created_at" : "2017-02-03 20:00:02 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9KRpZtJkrR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660978&oldid=96660800",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827606959687884800",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9KRpZtJkrR",
  "id" : 827606959687884800,
  "created_at" : "2017-02-03 19:57:30 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/2SumoxR0FW",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660800&oldid=96660790",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827605110033379328",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/2SumoxR0FW",
  "id" : 827605110033379328,
  "created_at" : "2017-02-03 19:50:09 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/8pDot9DbzH",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660790&oldid=96660621",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827605027581808640",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/8pDot9DbzH",
  "id" : 827605027581808640,
  "created_at" : "2017-02-03 19:49:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/AFNEouSGXk",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660621&oldid=96660592",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827603342826299392",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AFNEouSGXk",
  "id" : 827603342826299392,
  "created_at" : "2017-02-03 19:43:07 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/M1e0ymrgTl",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660592&oldid=96660578",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827603002785660930",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/M1e0ymrgTl",
  "id" : 827603002785660930,
  "created_at" : "2017-02-03 19:41:46 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/cJp1JkSJ8P",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660578&oldid=96660541",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827602807368851457",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cJp1JkSJ8P",
  "id" : 827602807368851457,
  "created_at" : "2017-02-03 19:41:00 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/GNPRDoGwsU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660541&oldid=96660505",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827602453268938752",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GNPRDoGwsU",
  "id" : 827602453268938752,
  "created_at" : "2017-02-03 19:39:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/KehNUHcklm",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660505&oldid=96660203",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827602073709641730",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KehNUHcklm",
  "id" : 827602073709641730,
  "created_at" : "2017-02-03 19:38:05 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/zbNGjgUxTs",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660203&oldid=96659980",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827598861896134659",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zbNGjgUxTs",
  "id" : 827598861896134659,
  "created_at" : "2017-02-03 19:25:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/PyP3Y57A1B",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96660118&oldid=96655835",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827598017037467648",
  "text" : "Alguien desde RedIRIS ha editado 'Grover Cleveland' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PyP3Y57A1B",
  "id" : 827598017037467648,
  "created_at" : "2017-02-03 19:21:57 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/R9ZGwmsYje",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659980&oldid=96659829",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827596683106254848",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/R9ZGwmsYje",
  "id" : 827596683106254848,
  "created_at" : "2017-02-03 19:16:39 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/DiQ6Ig6SbF",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659829&oldid=96659821",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827595231835148288",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/DiQ6Ig6SbF",
  "id" : 827595231835148288,
  "created_at" : "2017-02-03 19:10:53 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/RmG1wycLRh",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659821&oldid=96659804",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827595157235171328",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/RmG1wycLRh",
  "id" : 827595157235171328,
  "created_at" : "2017-02-03 19:10:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/6YkNZNZMqe",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659804&oldid=96659723",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827594812975095808",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/6YkNZNZMqe",
  "id" : 827594812975095808,
  "created_at" : "2017-02-03 19:09:14 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/hFFaPbs16E",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659723&oldid=96659687",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827593653136785413",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/hFFaPbs16E",
  "id" : 827593653136785413,
  "created_at" : "2017-02-03 19:04:37 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/uw7X9Mhr9M",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659687&oldid=96659396",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827593278530973700",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uw7X9Mhr9M",
  "id" : 827593278530973700,
  "created_at" : "2017-02-03 19:03:08 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Nk9EHHzflb",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659396&oldid=96659367",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827590049151713280",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Nk9EHHzflb",
  "id" : 827590049151713280,
  "created_at" : "2017-02-03 18:50:18 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/GjMlKePom3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96659367&oldid=96656234",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827589603565649920",
  "text" : "Alguien desde RedIRIS ha editado 'Benjamin Harrison' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/GjMlKePom3",
  "id" : 827589603565649920,
  "created_at" : "2017-02-03 18:48:32 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/SzMzT98W2w",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=763292013&oldid=761737550",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827122941481668608",
  "text" : "Alguien desde RedIRIS ha editado 'Tidal (service)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SzMzT98W2w",
  "id" : 827122941481668608,
  "created_at" : "2017-02-02 11:54:11 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/WllVaK0tHU",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=96622594&oldid=95781580",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827103322121322496",
  "text" : "Alguien desde RedIRIS ha editado 'Caza' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WllVaK0tHU",
  "id" : 827103322121322496,
  "created_at" : "2017-02-02 10:36:13 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]