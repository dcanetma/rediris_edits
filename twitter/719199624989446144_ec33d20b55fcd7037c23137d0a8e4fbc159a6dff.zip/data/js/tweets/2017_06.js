Grailbird.data.tweets_2017_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/PgFcTSKbVB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100177135&oldid=100161732",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880730214824890370",
  "text" : "Alguien desde RedIRIS ha editado 'Ley Foral del Euskera' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/PgFcTSKbVB",
  "id" : 880730214824890370,
  "created_at" : "2017-06-30 10:10:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/lHznTRtqhA",
      "expanded_url" : "https:\/\/ca.wikipedia.org\/w\/index.php?diff=18600183&oldid=1930469&rcid=51719106",
      "display_url" : "ca.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880709236736614401",
  "text" : "Alguien desde CSIC ha editado 'Discussi\u00F3:Guaiana Francesa' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/lHznTRtqhA",
  "id" : 880709236736614401,
  "created_at" : "2017-06-30 08:46:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/SO6tvuR794",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100138785&oldid=98710551",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880069336920195072",
  "text" : "Alguien desde RedIRIS ha editado 'Giorgio Parisi' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SO6tvuR794",
  "id" : 880069336920195072,
  "created_at" : "2017-06-28 14:24:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/KGdIFGEFn7",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100120295&oldid=99967936",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "879736767162839040",
  "text" : "Alguien desde CSIC ha editado 'Jerry Garcia' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/KGdIFGEFn7",
  "id" : 879736767162839040,
  "created_at" : "2017-06-27 16:22:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/WNc2BjilS2",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100093881&oldid=100086287",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "879260797091938305",
  "text" : "Alguien desde CSIC ha editado 'MasterChef (Espa\u00F1a)' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WNc2BjilS2",
  "id" : 879260797091938305,
  "created_at" : "2017-06-26 08:51:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/jrCBqgMuk0",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=787115272&oldid=786615294",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878260292693745665",
  "text" : "Alguien desde CSIC ha editado 'University of Aberdeen' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jrCBqgMuk0",
  "id" : 878260292693745665,
  "created_at" : "2017-06-23 14:35:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/bRs9e49siG",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100032502&oldid=100004083",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878205410599211009",
  "text" : "Alguien desde RedIRIS ha editado '1991' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bRs9e49siG",
  "id" : 878205410599211009,
  "created_at" : "2017-06-23 10:57:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/jEmeQ6U8VD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100031446&oldid=95845114",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878188076555685888",
  "text" : "Alguien desde RedIRIS ha editado '70 a. C.' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/jEmeQ6U8VD",
  "id" : 878188076555685888,
  "created_at" : "2017-06-23 09:48:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/AT2zW3kSYw",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=100029669&oldid=98921747",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878155813004685312",
  "text" : "Alguien desde RedIRIS ha editado 'The Stanley Parable' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/AT2zW3kSYw",
  "id" : 878155813004685312,
  "created_at" : "2017-06-23 07:40:35 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/BZaDuhjvxD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99968637&oldid=99703446",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877202433654521858",
  "text" : "Alguien desde RedIRIS ha editado 'Woodrow Wilson' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/BZaDuhjvxD",
  "id" : 877202433654521858,
  "created_at" : "2017-06-20 16:32:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/XJjQpBv9N5",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99968560&oldid=98210760",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877201594202411008",
  "text" : "Alguien desde RedIRIS ha editado 'James Buchanan' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/XJjQpBv9N5",
  "id" : 877201594202411008,
  "created_at" : "2017-06-20 16:28:52 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/4sMkcJuust",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99968502&oldid=99968497",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877200710336745472",
  "text" : "Alguien desde RedIRIS ha editado 'James Monroe' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/4sMkcJuust",
  "id" : 877200710336745472,
  "created_at" : "2017-06-20 16:25:21 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/FIYtaDYA5R",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99968497&oldid=99135825",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877200662861418496",
  "text" : "Alguien desde RedIRIS ha editado 'James Monroe' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/FIYtaDYA5R",
  "id" : 877200662861418496,
  "created_at" : "2017-06-20 16:25:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/tTN1YkfR2w",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=786581960&oldid=786522894",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877105423760928768",
  "text" : "Alguien desde CSIC ha editado 'Motorola' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/tTN1YkfR2w",
  "id" : 877105423760928768,
  "created_at" : "2017-06-20 10:06:43 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/bFwsDoDP30",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99946052&oldid=99647338",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "876822797825265668",
  "text" : "Alguien desde RedIRIS ha editado 'John Tyler' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/bFwsDoDP30",
  "id" : 876822797825265668,
  "created_at" : "2017-06-19 15:23:40 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/SCdPCchmcZ",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=502410235&oldid=487204893&rcid=533679229",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "876126178238754816",
  "text" : "Alguien desde RedIRIS ha editado 'Q603477' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SCdPCchmcZ",
  "id" : 876126178238754816,
  "created_at" : "2017-06-17 17:15:33 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Ynxiv9lezO",
      "expanded_url" : "https:\/\/eu.wikipedia.org\/w\/index.php?diff=5916646&oldid=4816388",
      "display_url" : "eu.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875732618284859393",
  "text" : "Alguien desde RedIRIS ha editado 'Wi-Fi' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ynxiv9lezO",
  "id" : 875732618284859393,
  "created_at" : "2017-06-16 15:11:41 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/SGuYNAFDWB",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=785970716&oldid=785970347",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875716491500498944",
  "text" : "Alguien desde RedIRIS ha editado 'Code talker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SGuYNAFDWB",
  "id" : 875716491500498944,
  "created_at" : "2017-06-16 14:07:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/MJUVgUGdX7",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=785970347&oldid=785969702",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875715812111376384",
  "text" : "Alguien desde RedIRIS ha editado 'Code talker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/MJUVgUGdX7",
  "id" : 875715812111376384,
  "created_at" : "2017-06-16 14:04:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Yk4gWLHYwN",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=785969702&oldid=785101019",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875714518223134720",
  "text" : "Alguien desde RedIRIS ha editado 'Code talker' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Yk4gWLHYwN",
  "id" : 875714518223134720,
  "created_at" : "2017-06-16 13:59:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/WG3msSldf0",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=785781136&oldid=778242701",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875314172300546048",
  "text" : "Alguien desde RedIRIS ha editado 'Universidad P\u00FAblica de Navarra' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/WG3msSldf0",
  "id" : 875314172300546048,
  "created_at" : "2017-06-15 11:28:55 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/HEzBPelh2j",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99861640&oldid=99861634",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875279416296955904",
  "text" : "Alguien desde RedIRIS ha editado 'Perd\u00F3name, Se\u00F1or' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HEzBPelh2j",
  "id" : 875279416296955904,
  "created_at" : "2017-06-15 09:10:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/0KitQ1lJjC",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99861634&oldid=99861627",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875279261036404736",
  "text" : "Alguien desde RedIRIS ha editado 'Perd\u00F3name, Se\u00F1or' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/0KitQ1lJjC",
  "id" : 875279261036404736,
  "created_at" : "2017-06-15 09:10:12 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/82BlxQWF3E",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99861627&oldid=99861600",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875279074155016192",
  "text" : "Alguien desde RedIRIS ha editado 'Perd\u00F3name, Se\u00F1or' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/82BlxQWF3E",
  "id" : 875279074155016192,
  "created_at" : "2017-06-15 09:09:27 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/QBeSMfDLI4",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99861470&oldid=65088383",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875273668653449216",
  "text" : "Alguien desde CSIC ha editado 'C\u00F3dice P\u00E9rez' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/QBeSMfDLI4",
  "id" : 875273668653449216,
  "created_at" : "2017-06-15 08:47:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/TgOSAgldCN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99840762&oldid=60561772",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874936821616185345",
  "text" : "Alguien desde CSIC ha editado 'Jos\u00E9 Checa Beltr\u00E1n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/TgOSAgldCN",
  "id" : 874936821616185345,
  "created_at" : "2017-06-14 10:29:28 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/9zTj9OPd7n",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=138169579&oldid=134311185&rcid=291802704",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874908397564461056",
  "text" : "Alguien desde RedIRIS ha editado 'Protection des r\u00E9seaux \u00E9lectriques' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9zTj9OPd7n",
  "id" : 874908397564461056,
  "created_at" : "2017-06-14 08:36:31 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/kmvluR1pzv",
      "expanded_url" : "https:\/\/www.wikidata.org\/w\/index.php?diff=500364571&oldid=495974289&rcid=531465401",
      "display_url" : "wikidata.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874565415279767552",
  "text" : "Alguien desde RedIRIS ha editado 'Q313512' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/kmvluR1pzv",
  "id" : 874565415279767552,
  "created_at" : "2017-06-13 09:53:38 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/dAdDxu7MHt",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=785396766&oldid=785396512",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874555340326658048",
  "text" : "Alguien desde CSIC ha editado 'Simocyon' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/dAdDxu7MHt",
  "id" : 874555340326658048,
  "created_at" : "2017-06-13 09:13:36 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/I409mm3p5v",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=785396512&oldid=784050805",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874554683477635072",
  "text" : "Alguien desde CSIC ha editado 'Simocyon' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/I409mm3p5v",
  "id" : 874554683477635072,
  "created_at" : "2017-06-13 09:10:59 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Ib3X3h4CAP",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99797215&oldid=99797178",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874274450698633216",
  "text" : "Alguien desde CSIC ha editado 'Antonio Naval\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Ib3X3h4CAP",
  "id" : 874274450698633216,
  "created_at" : "2017-06-12 14:37:26 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/SjHNDTrfKN",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99797178&oldid=99797036",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874274149451091969",
  "text" : "Alguien desde CSIC ha editado 'Antonio Naval\u00F3n' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/SjHNDTrfKN",
  "id" : 874274149451091969,
  "created_at" : "2017-06-12 14:36:15 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/t9fCK9XXk6",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99771333&oldid=99771318",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873838481285541889",
  "text" : "Alguien desde RedIRIS ha editado 'Management Information Base' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/t9fCK9XXk6",
  "id" : 873838481285541889,
  "created_at" : "2017-06-11 09:45:03 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/p9jITw38Wj",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99771318&oldid=89056448",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873838155052572672",
  "text" : "Alguien desde RedIRIS ha editado 'Management Information Base' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/p9jITw38Wj",
  "id" : 873838155052572672,
  "created_at" : "2017-06-11 09:43:45 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/mfuuBS3eId",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=138050989&oldid=138050975&rcid=289680157",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873203323821842432",
  "text" : "Alguien desde CSIC ha editado 'Je sais rien, mais je dirai tout' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/mfuuBS3eId",
  "id" : 873203323821842432,
  "created_at" : "2017-06-09 15:41:10 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/zw6bHiIllp",
      "expanded_url" : "https:\/\/fr.wikipedia.org\/w\/index.php?diff=138050975&oldid=137812922&rcid=289680095",
      "display_url" : "fr.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873203129281654786",
  "text" : "Alguien desde CSIC ha editado 'Je sais rien, mais je dirai tout' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zw6bHiIllp",
  "id" : 873203129281654786,
  "created_at" : "2017-06-09 15:40:24 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/cWY2EakaP8",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99709406&oldid=99565274",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872857333709377537",
  "text" : "Alguien desde RedIRIS ha editado 'IDIBELL' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/cWY2EakaP8",
  "id" : 872857333709377537,
  "created_at" : "2017-06-08 16:46:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9l9WYtCJF3",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99703416&oldid=99703391",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872757928113180672",
  "text" : "Alguien desde RedIRIS ha editado 'Fantastic D\u00FAo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/9l9WYtCJF3",
  "id" : 872757928113180672,
  "created_at" : "2017-06-08 10:11:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/nbyf7SVRB9",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99703391&oldid=99688883",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872757465515008000",
  "text" : "Alguien desde RedIRIS ha editado 'Fantastic D\u00FAo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/nbyf7SVRB9",
  "id" : 872757465515008000,
  "created_at" : "2017-06-08 10:09:29 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/74fgme4fwD",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99687140&oldid=99543518",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872510670872485888",
  "text" : "Alguien desde RedIRIS ha editado 'Falco' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/74fgme4fwD",
  "id" : 872510670872485888,
  "created_at" : "2017-06-07 17:48:49 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/amsZWfhztc",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=784256890&oldid=784256864",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872382860447150080",
  "text" : "Alguien desde RedIRIS ha editado 'Cytophaga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/amsZWfhztc",
  "id" : 872382860447150080,
  "created_at" : "2017-06-07 09:20:56 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/HgrDkqQ2BD",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=784256864&oldid=784256819",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872382807800250368",
  "text" : "Alguien desde RedIRIS ha editado 'Cytophaga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/HgrDkqQ2BD",
  "id" : 872382807800250368,
  "created_at" : "2017-06-07 09:20:44 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/zXmbqX2vAO",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=784256819&oldid=784256541",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872382692972797952",
  "text" : "Alguien desde RedIRIS ha editado 'Cytophaga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/zXmbqX2vAO",
  "id" : 872382692972797952,
  "created_at" : "2017-06-07 09:20:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/b6Y2WMfOLD",
      "expanded_url" : "https:\/\/en.wikipedia.org\/w\/index.php?diff=784256541&oldid=779279548",
      "display_url" : "en.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872381951029673986",
  "text" : "Alguien desde RedIRIS ha editado 'Cytophaga' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/b6Y2WMfOLD",
  "id" : 872381951029673986,
  "created_at" : "2017-06-07 09:17:19 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/qRLcQ9E1dB",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99629579&oldid=99629578",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "871642060989886464",
  "text" : "Alguien desde RedIRIS ha editado 'Nazismo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/qRLcQ9E1dB",
  "id" : 871642060989886464,
  "created_at" : "2017-06-05 08:17:16 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Lr54Yu51eR",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99629578&oldid=99614440",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "871641968576737280",
  "text" : "Alguien desde RedIRIS ha editado 'Nazismo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/Lr54Yu51eR",
  "id" : 871641968576737280,
  "created_at" : "2017-06-05 08:16:54 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/bitbucket.org\/danielcanet\/rediris_anon\/\" rel=\"nofollow\"\u003ERedIRIS_anon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/uqabhF2ZSv",
      "expanded_url" : "https:\/\/es.wikipedia.org\/w\/index.php?diff=99629533&oldid=99516591",
      "display_url" : "es.wikipedia.org\/w\/index.php?di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "871640687070130181",
  "text" : "Alguien desde RedIRIS ha editado 'Fascismo' en Wikipedia de manera an\u00F3nima https:\/\/t.co\/uqabhF2ZSv",
  "id" : 871640687070130181,
  "created_at" : "2017-06-05 08:11:48 +0000",
  "user" : {
    "name" : "RedIRIS_edits",
    "screen_name" : "RedIRIS_edits",
    "protected" : false,
    "id_str" : "719199624989446144",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719216620976152577\/T7GqBtkc_normal.jpg",
    "id" : 719199624989446144,
    "verified" : false
  }
} ]