var user_details =  {
  "screen_name" : "RedIRIS_edits",
  "location" : "Espa\u00F1a",
  "full_name" : "RedIRIS_edits",
  "bio" : "Tuitea las ediciones an\u00F3nimas en Wikipedia desde el rango de IP's de RedIRIS, la red de comunicaciones para la comunidad cient\u00EDfica y universitaria espa\u00F1ola.",
  "id" : "719199624989446144",
  "created_at" : "2016-04-10 16:25:27 +0000"
}