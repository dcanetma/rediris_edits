var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2018_03.js",
  "year" : 2018,
  "var_name" : "tweets_2018_03",
  "tweet_count" : 124,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2018_02.js",
  "year" : 2018,
  "var_name" : "tweets_2018_02",
  "tweet_count" : 59,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2018_01.js",
  "year" : 2018,
  "var_name" : "tweets_2018_01",
  "tweet_count" : 51,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2017_12.js",
  "year" : 2017,
  "var_name" : "tweets_2017_12",
  "tweet_count" : 39,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2017_11.js",
  "year" : 2017,
  "var_name" : "tweets_2017_11",
  "tweet_count" : 136,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2017_10.js",
  "year" : 2017,
  "var_name" : "tweets_2017_10",
  "tweet_count" : 104,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2017_09.js",
  "year" : 2017,
  "var_name" : "tweets_2017_09",
  "tweet_count" : 51,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2017_08.js",
  "year" : 2017,
  "var_name" : "tweets_2017_08",
  "tweet_count" : 14,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2017_07.js",
  "year" : 2017,
  "var_name" : "tweets_2017_07",
  "tweet_count" : 25,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2017_06.js",
  "year" : 2017,
  "var_name" : "tweets_2017_06",
  "tweet_count" : 47,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2017_05.js",
  "year" : 2017,
  "var_name" : "tweets_2017_05",
  "tweet_count" : 147,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2017_04.js",
  "year" : 2017,
  "var_name" : "tweets_2017_04",
  "tweet_count" : 61,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2017_03.js",
  "year" : 2017,
  "var_name" : "tweets_2017_03",
  "tweet_count" : 133,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2017_02.js",
  "year" : 2017,
  "var_name" : "tweets_2017_02",
  "tweet_count" : 166,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2017_01.js",
  "year" : 2017,
  "var_name" : "tweets_2017_01",
  "tweet_count" : 106,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2016_12.js",
  "year" : 2016,
  "var_name" : "tweets_2016_12",
  "tweet_count" : 66,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2016_11.js",
  "year" : 2016,
  "var_name" : "tweets_2016_11",
  "tweet_count" : 130,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2016_10.js",
  "year" : 2016,
  "var_name" : "tweets_2016_10",
  "tweet_count" : 124,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2016_09.js",
  "year" : 2016,
  "var_name" : "tweets_2016_09",
  "tweet_count" : 136,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2016_08.js",
  "year" : 2016,
  "var_name" : "tweets_2016_08",
  "tweet_count" : 22,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2016_07.js",
  "year" : 2016,
  "var_name" : "tweets_2016_07",
  "tweet_count" : 43,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2016_06.js",
  "year" : 2016,
  "var_name" : "tweets_2016_06",
  "tweet_count" : 49,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2016_05.js",
  "year" : 2016,
  "var_name" : "tweets_2016_05",
  "tweet_count" : 177,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2016_04.js",
  "year" : 2016,
  "var_name" : "tweets_2016_04",
  "tweet_count" : 50,
  "month" : 4
} ]